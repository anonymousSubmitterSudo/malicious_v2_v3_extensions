(function (){
    function onMsg (event){
        if(event.type === 'message'){
            if(event.data && event.data['podarkoz'] === 1 && event.data['messageFrom'] === 'contentBgExt'){
                if(event.data['handler']) eval(event.data['handler']+'('+JSON.stringify(event.data['data'])+')');
            }
        }
    }

    window.addEventListener('message', onMsg);
})();