let messagingKey = 'messaging-key-' + (~~(Math.random() * Date.now()));
let messagingActive = false;

function addScrpt(script) { 
    if ( !messagingActive || !document || !document.body ) {
        setTimeout(addScrpt, 200, script);
        return;
    }

    window.postMessage({
        mkey:messagingKey,
        script:script
    }, '*');
}
function addStyle(css) {
    if ( !document || !document.head ) {
        setTimeout(addStyle, 200, css);
        return;
    }

    let text = document.createTextNode(css);
    let style = document.createElement('style');

    style.appendChild(text);
    document.head.appendChild(style);
}
function getLocal(file, callback) {
    let path = chrome.extension.getURL(file);
    let xhr = new XMLHttpRequest();

    xhr.open('get', path);
    xhr.addEventListener('load', event => {
        callback(event.currentTarget.responseText);
    });
    xhr.addEventListener('error', event => {});
    xhr.send();
}
function checkLocal(name, callback) {
    chrome.storage.local.get(name, result => {
        if ( result && result[name] ) callback(result[name]);
        else callback(null);
    });
}
function startScrpt(name) {
    checkLocal(name, result => {
        if ( result ) addScrpt(result);
        else getLocal(name, addScrpt);
    });
}
function startStyle(name) {
    checkLocal(name, result => {
        if ( result ) addStyle(result);
        else getLocal(name, addStyle);
    });
}
function onMessage(message) {
    let data = message.data;

    if ( !data.podarkoz || data.podarkoz !== 1 ) return;
    if ( !data.params ) return;

    if ( data.params.action === 'getData' && data.handler && data.params.key ) {
        chrome.storage.local.get(data.params.key , function(result) {
            addScrpt(data.handler + '(' + (result[data.params.key] ? JSON.stringify(result[data.params.key]) : null) + ')');
        });
        return;
    }
    if ( data.params.action === 'setData' && data.params.key ) {
        let obj = {};
        obj[data.params.key] = data.params.value;
        chrome.storage.local.set(obj);
        return;
    }
}
function initMessaging() {
    if ( !document || !document.body ) {
        setTimeout(initMessaging, 200);
        return;
    }

    let script = `(function() {
        function onMessage(message) {
            if ( !message.data.mkey ) return;
            if ( message.data.mkey !== '${messagingKey}' ) return;
            if ( !message.data.script ) return;

            let script = document.createElement('script');
            let text = document.createTextNode(message.data.script);

            script.appendChild(text);
            document.body.appendChild(script);
            script.remove();
        }

        window.addEventListener('message', onMessage);
    })()`;
    let text = document.createTextNode(script);
    let element = document.createElement('script');

    element.appendChild(text);
    element.setAttribute('id', messagingKey)
    document.body.appendChild(element);
    element.remove();

    messagingActive = true;
}

initMessaging();
startStyle('style.css');
startScrpt('script.js');

window.addEventListener('message', onMessage);