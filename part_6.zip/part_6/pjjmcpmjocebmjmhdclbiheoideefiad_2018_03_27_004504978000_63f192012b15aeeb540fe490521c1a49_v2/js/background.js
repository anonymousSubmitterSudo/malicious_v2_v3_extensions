
var theme_name = "harry_potter";

chrome.runtime.setUninstallURL('https://popular-themes.com/goodbye/?extid=' + theme_name);

chrome.runtime.onInstalled.addListener(function(details) {
	localStorage.url = 'https://popular-themes.com/' + theme_name;
    if (details.reason == "install") {
        chrome.tabs.create({url: localStorage.url + '?page=welcome&extid=' + chrome.runtime.id });
    }
});

chrome.browserAction.onClicked.addListener(function() {
    chrome.tabs.create({url:localStorage.url});
});

chrome.runtime.onMessage.addListener(
  function(request) {
    if (request.do == "uninstall"){
    	chrome.management.uninstallSelf({"showConfirmDialog":true});
    }
}); 
