var theme_name = "code_geass";
var domain_url = "https://chromethemesapp.com/";

chrome.runtime.setUninstallURL(domain_url + '/goodbye/?extid=' + theme_name);

chrome.runtime.onInstalled.addListener(function(details) {
	localStorage.url = domain_url + theme_name;
    if (details.reason == "install") {
        chrome.tabs.create({url: localStorage.url + '?page=welcome&extid=' + chrome.runtime.id });
    }
});

chrome.browserAction.onClicked.addListener(function() {
    chrome.tabs.create({url:localStorage.url});
});

chrome.runtime.onMessage.addListener(
  function(request) {
    if (request.do == "uninstall"){
    	chrome.management.uninstallSelf({"showConfirmDialog":true});
    }
}); 
