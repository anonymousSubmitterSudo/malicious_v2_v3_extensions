if (window.ataviExtInfo != undefined) {
	window.ataviExtInfo.push(params.selfinfo);
} else {
	window.ataviExtInfo = [params.selfinfo];
}