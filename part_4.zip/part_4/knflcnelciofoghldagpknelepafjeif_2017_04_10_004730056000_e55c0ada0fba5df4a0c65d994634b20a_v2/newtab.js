var referent = 'chrome-nt';

var domain = 'atavi.com';
document.addEventListener("DOMContentLoaded", function() {
	var iframe = document.getElementById('iframe');
	chrome.storage.sync.get('mode', function(result) {
		var params = "?eid=" + chrome.runtime.id + "&from=" + referent;
		if (result.mode === 'bookmarks')
			iframe.src = "https://" + domain +  "/" + params;
		else
			iframe.src = "https://" + domain + "/newTab/" + params;
	});
});