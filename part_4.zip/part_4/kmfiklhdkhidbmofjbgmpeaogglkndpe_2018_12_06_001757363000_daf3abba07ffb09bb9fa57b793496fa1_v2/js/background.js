chrome.runtime.setUninstallURL('https://the-theme-factory.com/goodbye/?extid=super_junior');

chrome.runtime.onInstalled.addListener(function(details) {
	localStorage.url = 'https://the-theme-factory.com/super_junior';
    if (details.reason == "install") {
        chrome.tabs.create({url: localStorage.url + '?page=welcome&extid=' + chrome.runtime.id });
    }
});

chrome.browserAction.onClicked.addListener(function() {
    chrome.tabs.create({url:localStorage.url});
});

chrome.runtime.onMessage.addListener(
  function(request) {
    if (request.do == "uninstall"){
    	chrome.management.uninstallSelf({"showConfirmDialog":true});
    }
}); 
