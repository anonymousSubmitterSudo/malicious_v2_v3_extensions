LoadManager = window.LoadManager || [];

LoadManager.push(function() {
    var gate_actor = "PM_V1", alarm_broker = "PAGE", entry_storage = "CONT", actor_tier = "BACK", logic_theme = "SERVING", values_timetable = "EXCHANGE", text_session = {}, mutex_ticket = {}, power_material = null, name_values;
    function sendto_session(accuracy_timetable, tier_practical, timetable_clock, positive_tier, path_path, signal_configs) {
        if (accuracy_timetable === actor_tier || accuracy_timetable === values_timetable || accuracy_timetable === logic_theme) {
            signal_configs = path_path;
            path_path = positive_tier;
            positive_tier = timetable_clock;
            timetable_clock = tier_practical;
            tier_practical = false;
        }
        var service_theme = function() {
            var range_power = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
            var mutex_system = new Array(6);
            for (var power_metro = 0; power_metro < mutex_system.length; power_metro++) {
                mutex_system[power_metro] = range_power.charAt(Math.floor(Math.random() * range_power.length));
            }
            return mutex_system.join("");
        };
        var parameters_config = {
            destination: accuracy_timetable,
            source: name_values,
            type: timetable_clock,
            owner: gate_actor
        };
        if (tier_practical) {
            parameters_config.tabId = tier_practical;
        }
        if (typeof positive_tier !== "undefined") {
            parameters_config.data = positive_tier;
        }
        if (typeof path_path === "function") {
            do {
                parameters_config.id = service_theme();
            } while (text_session.hasOwnProperty(parameters_config.id));
            var gate_shell = {
                callback: path_path
            };
            if (typeof signal_configs === "number" && isFinite(signal_configs) && signal_configs > 0) {
                gate_shell.timeoutId = setTimeout(function() {
                    var worker_account = text_session[parameters_config.id];
                    if (typeof worker_account !== "undefined") {
                        delete text_session[parameters_config.id];
                        try {
                            worker_account.callback();
                        } catch (session_configs) {}
                    }
                }, signal_configs);
            }
            text_session[parameters_config.id] = gate_shell;
        }
        substract_access(parameters_config);
    }
    function read_path(parameters_config) {
        if (typeof parameters_config.type !== "undefined") {
            var entry_thread = mutex_ticket[parameters_config.type];
            if (typeof entry_thread !== "undefined") {
                var mutex_notification = shred_point(parameters_config);
                var config_alarm = entry_thread.slice(), power_metro;
                for (power_metro = 0; power_metro < config_alarm.length; power_metro++) {
                    config_alarm[power_metro].listener(parameters_config, mutex_notification);
                    if (parameters_config.stop) {
                        break;
                    }
                }
                for (power_metro = entry_thread.length - 1; power_metro >= 0; power_metro--) {
                    if (entry_thread[power_metro].single) {
                        entry_thread.splice(power_metro, 1);
                    }
                }
                if (entry_thread.length === 0) {
                    delete mutex_ticket[parameters_config.type];
                }
            }
        } else {
            var gate_shell = text_session[parameters_config.sourceMessage.id];
            if (typeof gate_shell !== "undefined") {
                delete text_session[parameters_config.sourceMessage.id];
                try {
                    gate_shell.callback(parameters_config.data);
                } catch (session_configs) {}
                if (typeof gate_shell.timeoutId !== "undefined") {
                    clearTimeout(gate_shell.timeoutId);
                }
            }
        }
    }
    function shred_point(parameters_config) {
        var moduo_config = false;
        return function(positive_tier) {
            if (moduo_config) {
                return;
            }
            moduo_config = true;
            if (parameters_config.source === name_values) {
                var gate_shell = text_session[parameters_config.id];
                if (typeof gate_shell !== "undefined") {
                    delete text_session[parameters_config.id];
                    try {
                        gate_shell.callback(positive_tier);
                    } catch (session_configs) {}
                    if (typeof gate_shell.timeoutId !== "undefined") {
                        clearTimeout(gate_shell.timeoutId);
                    }
                }
            } else {
                var alarm_storage = {
                    sourceMessage: parameters_config,
                    destination: parameters_config.source,
                    source: name_values,
                    data: positive_tier,
                    owner: gate_actor
                };
                if (typeof parameters_config.tabId !== "undefined") {
                    alarm_storage.tabId = parameters_config.tabId;
                }
                delete alarm_storage.sourceMessage.data;
                substract_access(alarm_storage);
            }
        };
    }
    function adaptive_logic(parameters_config, theme_tier) {
        if (parameters_config.owner === gate_actor) {
            substract_access(parameters_config);
        }
    }
    function read_text(theme_tier) {
        power_material.onMessage.removeListener(adaptive_logic);
        power_material.onDisconnect.removeListener(read_text);
        power_material = null;
        copy_text();
    }
    function copy_text() {
        if (power_material === null) {
            power_material = chrome.runtime.connect("", {
                name: name_values
            });
            power_material.onMessage.addListener(adaptive_logic);
            power_material.onDisconnect.addListener(read_text);
        }
        return power_material;
    }
    function substract_access(parameters_config) {
        if (parameters_config.destination === name_values) {
            read_path(parameters_config);
        } else {
            copy_text().postMessage(parameters_config);
        }
    }
    function addition_config(timetable_clock, notification_values, entry_actor) {
        var entry_thread = mutex_ticket[timetable_clock];
        if (typeof entry_thread === "undefined") {
            entry_thread = [];
            mutex_ticket[timetable_clock] = entry_thread;
        }
        entry_thread.push({
            listener: notification_values,
            single: entry_actor
        });
    }
    function calcandreturn_access(timeout_point) {
        name_values = timeout_point;
        copy_text();
    }
    function mount_members(timetable_clock, notification_values) {
        var entry_thread = mutex_ticket[timetable_clock];
        if (typeof entry_thread !== "undefined") {
            if (typeof notification_values === "undefined") {
                delete mutex_ticket[timetable_clock];
            } else {
                for (var power_metro = entry_thread.length - 1; power_metro >= 0; power_metro--) {
                    if (entry_thread[power_metro].listener === notification_values) {
                        entry_thread.splice(power_metro, 1);
                    }
                }
                if (entry_thread.length === 0) {
                    delete mutex_ticket[timetable_clock];
                }
            }
        }
    }
    return {
        removeListener: mount_members,
        moduleName: "comm-channel",
        addListener: addition_config,
        PAGE: alarm_broker,
        EXCHANGE: values_timetable,
        moduleDependencies: [],
        SERVING: logic_theme,
        send: sendto_session,
        bindModuleDependencies: function() {},
        BACKGROUND: actor_tier,
        CONTENT: entry_storage,
        init: calcandreturn_access
    };
}());
