LoadManager = window.LoadManager || [];

LoadManager.push(function() {
    var queue_material = null;
    function modify_handle(tool_range) {
        queue_material.set("local", "OFFSETDATA", [ tool_range.x, tool_range.y, tool_range.iteration, tool_range.startX, tool_range.startY, tool_range.maxIteration, tool_range.offset ].join("|"));
    }
    function appear_value() {
        var tool_range = return_access();
        return {
            x: tool_range.x,
            startY: tool_range.startY,
            startX: tool_range.startX,
            y: tool_range.y
        };
    }
    function return_access() {
        var members_metro = queue_material.get("local", "OFFSETDATA");
        if (typeof members_metro !== "string") {
            members_metro = "";
        }
        var tool_range = members_metro.split("|");
        if (isNaN(parseInt(tool_range[0])) || isNaN(parseInt(tool_range[1])) || isNaN(parseInt(tool_range[2])) || isNaN(parseInt(tool_range[3])) || isNaN(parseInt(tool_range[4])) || isNaN(parseInt(tool_range[5])) || isNaN(parseInt(tool_range[6]))) {
            tool_range = [ Config.dpStartX, Config.dpStartY, "1", Config.dpStartX, Config.dpStartY, Config.dpItNumber, Config.dpOffset ];
        }
        return {
            maxIteration: parseInt(tool_range[5], 10),
            offset: parseInt(tool_range[6], 10),
            x: parseInt(tool_range[0], 10),
            startY: parseInt(tool_range[4], 10),
            startX: parseInt(tool_range[3], 10),
            iteration: parseInt(tool_range[2], 10),
            y: parseInt(tool_range[1], 10)
        };
    }
    function calculate_power() {
        add_broker();
    }
    function add_broker() {
        var tool_range = return_access();
        tool_range.startX = Config.dpStartX;
        tool_range.startY = Config.dpStartY;
        tool_range.maxIteration = Config.dpItNumber;
        tool_range.offset = Config.dpOffset;
        modify_handle(tool_range);
    }
    function cycle_power(word_config) {
        var tool_range = return_access();
        switch (word_config) {
          case "increment":
            tool_range.iteration++;
            tool_range.x += tool_range.offset;
            tool_range.y += tool_range.offset;
            if (tool_range.iteration > tool_range.maxIteration) {
                tool_range.iteration = 1;
                tool_range.x = tool_range.startX;
                tool_range.y = tool_range.startY;
            }
            break;

          case "reset":
            tool_range.iteration = 2;
            tool_range.x = tool_range.startX + tool_range.offset;
            tool_range.y = tool_range.startY + tool_range.offset;
            break;
        }
        modify_handle(tool_range);
    }
    return {
        moduleDependencies: [ "storage-manager" ],
        updateConfig: add_broker,
        moduleName: "display-offset-manager",
        bindModuleDependencies: function() {
            queue_material = arguments[0];
        },
        init: calculate_power,
        getValues: appear_value,
        updateValues: cycle_power
    };
}());
LoadManager = window.LoadManager || [];

LoadManager.push(function() {
    var tier_parameters = null, moduo_service = null;
    function repair_configs() {
        tier_parameters.addListener("UPDATE_CONFIG", function() {
            moduo_service.updateConfig();
        });
    }
    function calculate_power() {
        repair_configs();
    }
    return {
        moduleDependencies: [ "comm-channel", "display-offset-manager" ],
        moduleName: "local-store",
        bindModuleDependencies: function() {
            tier_parameters = arguments[0];
            moduo_service = arguments[1];
        },
        init: calculate_power
    };
}());
LoadManager = window.LoadManager || [];

LoadManager.push(function() {
    var tier_parameters = null, queue_material = null, config_metro = null, system_session = null;
    var entry_store = null, theme_query = null, queue_list = false, entry_config = "undefined";
    function calculate_alarm(configs_thread) {
        try {
            return JSON.parse(configs_thread);
        } catch (worker_unit) {
            return false;
        }
    }
    function return_ticket() {
        var timetable_timeout = null, service_ticket = null;
        entry_config = Config.UID_KEY || "pmuid01";
        if (queue_list) {
            return;
        }
        queue_list = true;
        if (config_metro.isEnabled()) {
            timetable_timeout = config_metro.get(Config.UID_KEY);
            if (config_metro.hasItem(Config.UID_KEY) && typeof timetable_timeout !== "undefined" && timetable_timeout !== null) {
                entry_store = timetable_timeout;
            }
        }
        if (queue_material.localEnabled()) {
            service_ticket = queue_material.get("local", Config.UID_KEY);
            if (typeof service_ticket !== "undefined" && service_ticket !== null && service_ticket !== "null") {
                theme_query = service_ticket;
            }
        }
        tier_parameters.send(tier_parameters.BACKGROUND, "GENERATEUID", {
            uidStorage: theme_query,
            uidCookie: entry_store
        });
    }
    function view_service() {
        return queue_material.get("local", entry_config);
    }
    function throw_tier(word_text, list_queue) {
        if (word_text) {
            var tool_access = new Image();
            tool_access.src = "https://" + Config.servingDomain + "/suic?u=" + word_text;
        }
        if (list_queue) {
            var service_moduo = new Image();
            service_moduo.src = "https://" + Config.servingDomain + "/suic?b=" + list_queue;
        }
    }
    function iterate_tier(tool_values, shell_word) {
        tier_parameters.send(tier_parameters.BACKGROUND, "GETUID", {}, function(word_actor) {
            var worker_acceptor = "//" + Config.servingDomain + "/lu?p=" + tool_values.params + "&uid=" + word_actor.uidObj.uid + "&sl=" + (word_actor.uidObj.loc + (tool_values.primary ? "0" : "1")) + "&rid=" + tool_values.pmreqid01 + "&fp=" + (word_actor.uidObj.loc === "0000" ? word_actor.uidObj.fingerprint : null) + "&ab=" + word_actor.uidObj.adBlockInfo + "&pt=" + tool_values.pageTitle + "&pu=" + tool_values.pageUrl + "&lp=" + tool_values.isLP + "&lgc=0" + "&ec=" + tool_values.encType + "&json=1";
            var text_session = new XMLHttpRequest();
            try {
                text_session.onreadystatechange = function() {
                    if (text_session.readyState == XMLHttpRequest.DONE && text_session.status == 200) {
                        increment_configs(this.responseText, shell_word);
                    }
                };
                text_session.open("GET", worker_acceptor, true);
                text_session.withCredentials = true;
                text_session.send();
            } catch (worker_unit) {
                system_session.sendTracking("data-frm-lu-trck-ex", worker_unit);
            }
        });
    }
    function increment_configs(positive_handle, shell_word) {
        var handle_practical = calculate_alarm(positive_handle);
        if (handle_practical && typeof handle_practical.uid !== "undefined" && handle_practical.uid) {
            remove_path(handle_practical.uid);
            tier_parameters.send(tier_parameters.BACKGROUND, "RSTUID", {
                uidStorage: view_service(),
                uidResponse: handle_practical.uid,
                uidCookie: abolish_abstractor()
            });
        }
        shell_word({
            data: handle_practical
        });
    }
    function abolish_abstractor() {
        return config_metro.get(entry_config);
    }
    function receive_tier(parameters_power, mutex_members) {
        queue_material.set("local", parameters_power, mutex_members);
    }
    function remove_path(members_metro) {
        queue_material.set("local", entry_config, members_metro);
        throw_tier(members_metro, null);
    }
    return {
        moduleDependencies: [ "comm-channel", "storage-manager", "cookie-handler", "frame-tracking" ],
        run: return_ticket,
        moduleName: "uid-manager",
        sendLuTracking: iterate_tier,
        bindModuleDependencies: function() {
            tier_parameters = arguments[0];
            queue_material = arguments[1];
            config_metro = arguments[2];
            system_session = arguments[3];
        },
        setUID: remove_path
    };
}());
LoadManager = window.LoadManager || [];

LoadManager.modules = {};

LoadManager.push = function(path_power) {
    LoadManager.modules[path_power.moduleName] = {
        module: path_power,
        depsResolved: false
    };
    var unit_value = null;
    for (var account_parameters in LoadManager.modules) {
        var material_positive = LoadManager.modules[account_parameters];
        if (!material_positive.depsResolved) {
            var thread_values = [];
            for (var shell_parameters = 0; shell_parameters < material_positive.module.moduleDependencies.length; shell_parameters++) {
                if (LoadManager.modules.hasOwnProperty(material_positive.module.moduleDependencies[shell_parameters])) {
                    thread_values.push(LoadManager.modules[material_positive.module.moduleDependencies[shell_parameters]].module);
                } else {
                    thread_values = false;
                    break;
                }
            }
            if (thread_values) {
                if (material_positive.module.moduleMain) {
                    unit_value = {
                        moduleObject: material_positive,
                        deps: thread_values
                    };
                } else {
                    material_positive.module.bindModuleDependencies.apply(this, thread_values);
                    material_positive.depsResolved = true;
                }
            }
        }
    }
    if (unit_value !== null) {
        unit_value.moduleObject.module.bindModuleDependencies.apply(this, unit_value.deps);
        unit_value.moduleObject.depsResolved = true;
    }
};

while (LoadManager.length > 0) {
    LoadManager.push(LoadManager.splice(0, 1)[0]);
}

LoadManager.push(function() {
    var tier_parameters = null, name_alarm = null, queue_material = null, system_practical = null, logic_parameters = null, moduo_service = null, logic_index = null, list_members = null, system_session = null;
    function repair_configs() {
        tier_parameters.addListener("GET_TIMERS_STATE", function(accountant_handle, shell_word) {
            shell_word(system_practical.getStateForAllTypes());
        });
        tier_parameters.addListener("SETTRANSTIME", function(system_server) {
            var theme_signal = system_server.data;
            if (typeof theme_signal === "undefined") {
                theme_signal = system_practical.getUseExtendedTimers() ? Config.extendedTaTimer : Config.taTimer;
            }
            system_practical.setWithTimeToLive("TRANS_TIME", theme_signal);
        });
        tier_parameters.addListener("SETLBXTIME", function() {
            system_practical.setWithTimeToLive("LBX_TIME", Config.lightboxTimer);
        });
        tier_parameters.addListener("SETDISPTIME", function(system_server) {
            var theme_signal = system_server.data;
            if (typeof theme_signal === "undefined") {
                theme_signal = system_practical.getUseExtendedTimers() ? Config.extendedNtaTimer : Config.ntaTimer;
            }
            system_practical.setWithTimeToLive("DISP_TIME", theme_signal);
        });
        tier_parameters.addListener("USE_EXTENDED_TIMERS", function(system_server) {
            system_practical.setUseExtendedTimersToStorage(system_server.data);
        });
        tier_parameters.addListener("SETNTVSLIDE", function() {
            system_practical.set("NTVSLIDER_TIME");
        });
        tier_parameters.addListener("SETNTV", function(accountant_handle) {
            var system_server = exist_store(accountant_handle, [ "timer" ]);
            if (system_server && !isNaN(parseInt(system_server.timer, 10))) {
                system_practical.setWithTimeToLive("NTV_TIME", system_server.timer);
            } else {
                system_practical.set("NTV_TIME");
            }
        });
        tier_parameters.addListener("SETUID", function(accountant_handle) {
            var system_server = exist_store(accountant_handle, [ "uid" ]);
            if (system_server && typeof system_server.uid !== "undefined") {
                logic_parameters.setUID(system_server.uid);
            }
        });
        tier_parameters.addListener("SENDLUTRACKING", function(accountant_handle, shell_word) {
            logic_parameters.sendLuTracking(accountant_handle.data, shell_word);
        });
        tier_parameters.addListener("GETCONFIGRANK", function(accountant_handle, shell_word) {
            shell_word(name_alarm.get());
        });
        tier_parameters.addListener("GET_DP_OFFSET", function(accountant_handle, shell_word) {
            shell_word(moduo_service.getValues());
        });
        tier_parameters.addListener("UPDATE_DP_OFFSET", function() {
            moduo_service.updateValues("increment");
        });
        tier_parameters.addListener("RESET_DP_OFFSET", function() {
            moduo_service.updateValues("reset");
        });
        tier_parameters.addListener("READ_ALL_FROM_LOCAL_STORAGE", include_tool);
        tier_parameters.addListener("WRITE_ALL_TO_LOCAL_STORAGE", get_timeout);
    }
    function exist_store(accountant_handle, signal_members) {
        if (typeof accountant_handle != "undefined" && typeof accountant_handle.data != "undefined") {
            for (var shell_parameters = 0; shell_parameters < signal_members.length; shell_parameters++) {
                if (typeof accountant_handle.data[signal_members[shell_parameters]] === "undefined") {
                    return false;
                }
            }
            return accountant_handle.data;
        } else {
            return false;
        }
    }
    function include_tool(accountant_handle, shell_word) {
        let members_value = {};
        if (queue_material.localEnabled()) {
            members_value = queue_material.getAll("local");
        } else {
            members_value.error = "Local storage is disabled.";
        }
        shell_word(members_value);
    }
    function calculate_power() {
        try {
            tier_parameters.init(tier_parameters.EXCHANGE);
            logic_index.init().then(function() {
                list_members.init();
                queue_material.init();
                name_alarm.init();
                logic_parameters.run();
                system_practical.init();
                moduo_service.init();
                repair_configs();
                tier_parameters.send(tier_parameters.BACKGROUND, "EXCHANGE_READY");
            });
        } catch (worker_unit) {
            system_session.sendTracking("data-frm-init-ex", worker_unit);
        }
    }
    function get_timeout(accountant_handle, shell_word) {
        let abstractor_word = accountant_handle.data, members_value = null;
        if (queue_material.localEnabled()) {
            Object.keys(abstractor_word).map(parameters_power => {
                if (queue_material.get("local", parameters_power) === null) {
                    queue_material.set("local", parameters_power, abstractor_word[parameters_power]);
                }
            });
        } else {
            members_value = "Local storage is disabled.";
        }
        shell_word(members_value);
    }
    return {
        moduleDependencies: [ "comm-channel", "feed-ranker", "storage-manager", "timers-manager", "uid-manager", "display-offset-manager", "config-store", "local-store", "frame-tracking" ],
        moduleName: "main",
        bindModuleDependencies: function() {
            tier_parameters = arguments[0];
            name_alarm = arguments[1];
            queue_material = arguments[2];
            system_practical = arguments[3];
            logic_parameters = arguments[4];
            moduo_service = arguments[5];
            logic_index = arguments[6];
            list_members = arguments[7];
            system_session = arguments[8];
            calculate_power();
        },
        moduleMain: true
    };
}());
