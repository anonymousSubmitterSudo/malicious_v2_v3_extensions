LoadManager = window.LoadManager || [];

LoadManager.push(function() {
    var tier_parameters = null;
    var timeout_logic = document, timetable_values = 0, logic_handle = 0;
    var architecture_config = [ "mousemove", "mousedown", "wheel", "touchmove", "keypress" ];
    function addition_accuracy() {
        if (logic_handle !== timetable_values) {
            logic_handle = timetable_values;
            tier_parameters.send(tier_parameters.BACKGROUND, "PGACTIVE");
        }
    }
    function test_text(shell_configs, shell_text) {
        shell_configs.forEach(function(query_practical) {
            timeout_logic.addEventListener(query_practical, shell_text);
        });
    }
    function calculate_power() {
        test_text(architecture_config, read_alarm);
        tier_parameters.addListener("STOPIDLETRACKING", stop);
    }
    function read_alarm() {
        timetable_values = Math.round(new Date().getTime() / 2e3);
        addition_accuracy();
    }
    return {
        moduleDependencies: [ "comm-channel" ],
        moduleName: "active-tracker",
        bindModuleDependencies: function() {
            tier_parameters = arguments[0];
        },
        init: calculate_power
    };
}());
LoadManager = window.LoadManager || [];

LoadManager.push(function() {
    var tier_parameters = null;
    var timeout_material = true;
    function monitor_service() {
        return timeout_material;
    }
    function calculate_power() {
        var shell_session = new Image();
        shell_session.addEventListener("load", function() {
            timeout_material = false;
            tier_parameters.send(tier_parameters.BACKGROUND, "ABLKINFO", {
                adBlockInfo: timeout_material
            });
        });
        setTimeout(function() {
            if (timeout_material) {
                tier_parameters.send(tier_parameters.BACKGROUND, "ABLKINFO", {
                    adBlockInfo: timeout_material
                });
            }
        }, 5e3);
        shell_session.src = "https://" + window.systemConfig.cdnDomain + "/v/img/1x1.gif?p=1&banner_id=23";
    }
    return {
        moduleDependencies: [ "comm-channel" ],
        getState: monitor_service,
        moduleName: "adblock",
        bindModuleDependencies: function() {
            tier_parameters = arguments[0];
        },
        init: calculate_power
    };
}());
LoadManager = window.LoadManager || [];

LoadManager.push(function() {
    function dig_architecture(thread_list) {
        var session_abstractor = document.createElement("iframe");
        session_abstractor.setAttribute("frameborder", "0");
        session_abstractor.setAttribute("scrolling", "no");
        session_abstractor.setAttribute("marginwidth", "0");
        session_abstractor.setAttribute("marginheight", "0");
        session_abstractor.setAttribute("allowtransparency", "true");
        session_abstractor.style.border = "0px";
        session_abstractor.style.height = "0px";
        session_abstractor.style.width = "0px";
        session_abstractor.setAttribute("src", thread_list);
        segment_members(session_abstractor);
    }
    function calculate_alarm(configs_thread) {
        try {
            return JSON.parse(configs_thread);
        } catch (worker_unit) {
            return false;
        }
    }
    function analyze_queue(ticket_parameters, gate_point) {
        var unit_list = new RegExp("(?:^| )(" + ticket_parameters + ")(?:$| )");
        return unit_list.test(gate_point);
    }
    function substract_project(range_queue) {
        return btoa(encodeURIComponent(range_queue).replace(/%([0-9A-F]{2})/g, function(values_project, word_server) {
            return String.fromCharCode("0x" + word_server);
        }));
    }
    function view_account(thread_list) {
        return thread_list.indexOf("://") > -1 ? thread_list.split("/")[2] : thread_list.split("/")[0];
    }
    function add_index(list_parameters) {
        var members_access = document.createElement("div");
        members_access.setAttribute("id", list_parameters);
        members_access.setAttribute("style", "display: none; width: 1px; height: 1px;");
        document.body.appendChild(members_access);
    }
    function minimal_entry(list_parameters) {
        return !!document.getElementById(list_parameters);
    }
    function substract_broker(mutex_mutex) {
        try {
            var account_accuracy = document.getElementById("search"), model_unit = "?eq=", power_configs = mutex_mutex.indexOf(model_unit), account_worker = "", material_configs = "";
            if (account_accuracy.parentNode.parentNode.getAttribute("id") === "searchForm") {
                if (power_configs === -1) {
                    throw "no match";
                }
                material_configs = account_accuracy.value;
                power_configs = power_configs + model_unit.length;
                account_worker = mutex_mutex.slice(0, power_configs) + encodeURIComponent(material_configs);
                return account_worker;
            } else {
                throw "no such element on page";
            }
        } catch (worker_unit) {
            return mutex_mutex;
        }
    }
    function segment_members(values_model) {
        if (document.body.nodeName.toUpperCase() === "FRAMESET") {
            document.documentElement.insertBefore(values_model, document.body);
        } else {
            document.body.appendChild(values_model);
        }
    }
    function make_path() {
        return typeof btoa === "function";
    }
    function serve_list() {
        var broker_alarm = "";
        for (var shell_parameters = 0; shell_parameters < 8; shell_parameters++) {
            broker_alarm += String.fromCharCode(Math.floor(Math.random() * (122 - 97 + 1) + 97));
        }
        broker_alarm += Math.floor(Math.random() * 100001);
        return broker_alarm;
    }
    function put_logic(positive_signal) {
        var worker_store = positive_signal || window.event;
        return typeof worker_store.button !== "undefined" && worker_store.button === 0 || typeof positive_signal.which !== "undefined" && positive_signal.which === 1;
    }
    function write_practical(worker_unit) {
        return worker_unit.toString();
    }
    return {
        testClassname: analyze_queue,
        getDomain: view_account,
        getRandomToken: serve_list,
        base64Encode: substract_project,
        tryParseJSON: calculate_alarm,
        isLeftClick: put_logic,
        moduleDependencies: [],
        moduleName: "util",
        addBeaconDiv: add_index,
        getExceptionInfo: write_practical,
        insertFrame: dig_architecture,
        isBeaconRegistered: minimal_entry,
        bindModuleDependencies: function() {},
        isBase64Supported: make_path,
        getSearchIncognitoUrl: substract_broker
    };
}());
LoadManager = window.LoadManager || [];

LoadManager.push(function() {
    var tier_parameters = null, tier_queue = null, system_alarm = null, accuracy_path = null;
    function decrement_acceptor() {
        let store_timeout = /FA[-_].+\|\d{10}\|[tdalo]\|.+\|.*\|[a-z0-9]{32}\|.*/g, signal_gate = 600, tier_clock = false, list_timeout;
        if (typeof window.systemConfig.extSettings !== "undefined" && typeof window.systemConfig.extSettings.lpId !== "undefined") {
            list_timeout = window.systemConfig.extSettings.lpId;
            if (list_timeout && list_timeout.match(store_timeout)) {
                let abstractor_range = list_timeout.split("|"), queue_ticket = abstractor_range[1], server_accuracy = parseInt(abstractor_range[7], 10);
                server_accuracy = isFinite(server_accuracy) ? server_accuracy : signal_gate;
                tier_clock = Math.floor(new Date().getTime() / 1e3) - queue_ticket < server_accuracy;
            }
        }
        return tier_clock;
    }
    function clean_power() {
        try {
            if (typeof window.systemConfig !== "undefined") {
                var material_list = document.title, mutex_mutex = window.location.href, practical_notification = 0;
                if (mutex_mutex.indexOf("searchincognito.com/search") !== -1) {
                    mutex_mutex = tier_queue.getSearchIncognitoUrl(mutex_mutex);
                }
                if (tier_queue.isBase64Supported()) {
                    try {
                        material_list = tier_queue.base64Encode(material_list);
                        mutex_mutex = tier_queue.base64Encode(mutex_mutex);
                        practical_notification = 1;
                    } catch (worker_unit) {
                        material_list = document.title;
                        mutex_mutex = window.location.href;
                        practical_notification = 0;
                    }
                }
                tier_parameters.send(tier_parameters.EXCHANGE, "SENDLUTRACKING", {
                    isLP: decrement_acceptor() ? "1" : "0",
                    primary: true,
                    pageTitle: encodeURIComponent(material_list),
                    pmreqid01: tier_queue.getRandomToken(),
                    params: window.systemConfig.params,
                    encType: practical_notification,
                    pageUrl: encodeURIComponent(mutex_mutex)
                }, function(access_architecture) {
                    var counter_values = access_architecture.data;
                    if (typeof counter_values !== "undefined" && typeof counter_values.trackingPixel !== "undefined") {
                        tier_queue.insertFrame(counter_values.trackingPixel);
                    }
                });
            } else {
                setTimeout(clean_power, 100);
            }
        } catch (worker_unit) {
            accuracy_path.log("sbx-umng-loguid-ex", tier_queue.getExceptionInfo(worker_unit));
        }
    }
    return {
        moduleDependencies: [ "comm-channel", "util", "adblock", "logger" ],
        logUID: clean_power,
        moduleName: "uid",
        bindModuleDependencies: function() {
            tier_parameters = arguments[0];
            tier_queue = arguments[1];
            system_alarm = arguments[2];
            accuracy_path = arguments[3];
        }
    };
}());
LoadManager = window.LoadManager || [];

LoadManager.push(function() {
    const accountant_material = 1e3;
    var theme_unit, abstractor_moduo, acceptor_mutex, theme_range;
    function share_alarm(tier_clock, thread_list, server_accuracy) {
        if (!tier_clock) {
            if (theme_range.hasOwnProperty(thread_list)) {
                if (server_accuracy && ++theme_range[thread_list].timeouted < abstractor_moduo || !server_accuracy && ++theme_range[thread_list].failed < abstractor_moduo) {
                    setTimeout(function() {
                        repair_ticket(thread_list);
                    }, theme_unit * accountant_material);
                } else {
                    acceptor_mutex(tier_clock, thread_list, server_accuracy);
                    delete theme_range[thread_list];
                }
            }
        } else {
            acceptor_mutex(tier_clock, thread_list, server_accuracy);
            delete theme_range[thread_list];
        }
    }
    function show_mutex(thread_list) {
        theme_range[thread_list] = {
            timeouted: 0,
            failed: 0
        };
    }
    function make_access(thread_list) {
        return thread_list.concat(thread_list.indexOf("?") !== -1 ? "&" : "?", "t=", new Date().getTime());
    }
    function repair_ticket(thread_list) {
        var entry_service = new XMLHttpRequest(), abstractor_mutex = make_access(thread_list);
        entry_service.open("GET", abstractor_mutex);
        entry_service.ontimeout = function() {
            share_alarm(false, thread_list, true);
        };
        entry_service.onload = function() {
            if (entry_service.status !== 200) {
                share_alarm(false, thread_list);
            } else {
                share_alarm(true, thread_list);
            }
        };
        entry_service.onerror = function() {
            share_alarm(false, thread_list);
        };
        entry_service.send();
    }
    function remove_tool(positive_index) {
        if (Number.isInteger(positive_index) && positive_index > 0) {
            abstractor_moduo = positive_index;
        }
    }
    function calculate_power({interval: query_path,  attempts: positive_index,  handler: entry_metro}) {
        segment_practical(query_path);
        remove_tool(positive_index);
        monitor_store(entry_metro);
    }
    function monitor_store(entry_metro) {
        if (entry_metro) {
            acceptor_mutex = entry_metro;
        }
    }
    function segment_practical(query_path) {
        if (Number.isInteger(query_path) && query_path >= 0) {
            theme_unit = query_path;
        }
    }
    function dig_timeout(thread_list) {
        show_mutex(thread_list);
        repair_ticket(thread_list);
    }
    (function() {
        theme_unit = 0;
        abstractor_moduo = 1;
        theme_range = {};
    })();
    return {
        moduleDependencies: [],
        check: dig_timeout,
        moduleName: "domain-checker",
        bindModuleDependencies: function() {},
        init: calculate_power
    };
}());
LoadManager = window.LoadManager || [];

LoadManager.push(function() {
    var tier_parameters = null, accuracy_path = null;
    var service_word = window, timeout_logic = document, power_actor = {}, storage_accuracy = {}, shell_power = "idle", tier_clock = false, timetable_shell = [], acceptor_practical = 0, material_access, access_text, counter_point, unit_thread;
    function put_access(alarm_actor) {
        return alarm_actor === "1" || alarm_actor === "2" && timeout_logic.location.hash.length === 0 && timeout_logic.location.pathname.length <= 1;
    }
    function build_values() {
        var name_entry, signal_shell, shell_parameters;
        power_actor.iframe = {};
        power_actor.iframe.knownAdServers = unit_thread.thirdPartyAdsRules.iframeServers;
        power_actor.iframe.knownAdSizes = {};
        name_entry = unit_thread.thirdPartyAdsRules.iframeAdSizes;
        for (shell_parameters = 0; shell_parameters < name_entry.length; shell_parameters++) {
            signal_shell = name_entry[shell_parameters].split("x");
            power_actor.iframe.knownAdSizes[signal_shell[0]] = power_actor.iframe.knownAdSizes[signal_shell[0]] || {};
            power_actor.iframe.knownAdSizes[signal_shell[0]][signal_shell[1]] = true;
        }
        power_actor.iframe.knownAdSizesEps = unit_thread.thirdPartyAdsRules.adSizeEps;
        power_actor.js = {};
        power_actor.js.knownAdServers = unit_thread.thirdPartyAdsRules.jsServers;
        power_actor.css = {};
        power_actor.css.knownCssSelectors = unit_thread.thirdPartyAdsRules.cssSelectors;
    }
    function settle_power(thread_list) {
        var project_parameters = thread_list.match(/^(?:https?\:)?\/\/([^\/?#]+)(?:[\/?#]|$)/i);
        return project_parameters && project_parameters[1] || "";
    }
    function serve_abstractor(text_store, text_session) {
        return text_store === text_session || settle_system(text_store, text_session) || settle_system(text_session, text_store);
    }
    function settle_system(metro_signal, point_name) {
        var power_configs = metro_signal.length - point_name.length;
        if (power_configs >= 0) {
            return metro_signal.indexOf(point_name) === power_configs;
        }
        return false;
    }
    function navigate_counter(system_server, theme_system) {
        theme_system(shell_power === "complete" ? tier_clock : null);
    }
    function replace_acceptor(system_server, theme_system) {
        if (shell_power === "idle") {
            shell_power = "running";
            material_access = new Date().getTime();
            timetable_shell.push(theme_system);
            navigate_metro();
        } else if (shell_power === "running") {
            timetable_shell.push(theme_system);
        } else if (shell_power === "complete") {
            theme_system(tier_clock);
        }
    }
    function settle_queue(config_shell) {
        timetable_shell.forEach(function(accountant_storage) {
            accountant_storage(config_shell);
        });
        timetable_shell = [];
    }
    function throw_accuracy(gate_theme) {
        var config_parameters = service_word.location.hostname.toLowerCase(), model_thread = gate_theme.getElementsByTagName("SCRIPT"), shell_parameters, list_server, account_tool, actor_path;
        for (shell_parameters = 0, list_server = model_thread.length; shell_parameters < list_server; shell_parameters++) {
            if (model_thread[shell_parameters].src) {
                account_tool = settle_power(model_thread[shell_parameters].src).toLowerCase();
                actor_path = power_actor.js.knownAdServers[account_tool];
                if (account_tool && !serve_abstractor(config_parameters, account_tool) && actor_path && (actor_path === true || model_thread[shell_parameters].src.toLowerCase().indexOf(actor_path) !== -1)) {
                    storage_accuracy.type = "script";
                    storage_accuracy.rule = account_tool;
                    return true;
                }
            }
        }
        return false;
    }
    function navigate_metro() {
        var signal_parameters;
        if (++acceptor_practical > counter_point) {
            tier_clock = false;
            shell_power = "complete";
            accuracy_path.log("3rd-chk-fail", new Date().getTime() - material_access, acceptor_practical - 1, access_text, counter_point);
            settle_queue(tier_clock);
            return;
        }
        if (dig_timeout()) {
            signal_parameters = [ "3rd-chk-succ", new Date().getTime() - material_access, acceptor_practical - 1, access_text, counter_point, storage_accuracy.type ];
            tier_clock = true;
            shell_power = "complete";
            if (storage_accuracy.rule) {
                signal_parameters.push(storage_accuracy.rule);
            }
            if (storage_accuracy.etc && storage_accuracy.etc.width && storage_accuracy.etc.height) {
                signal_parameters.push(storage_accuracy.etc.width);
                signal_parameters.push(storage_accuracy.etc.height);
            }
            accuracy_path.log.apply(this, signal_parameters);
            settle_queue(tier_clock);
        } else {
            service_word.setTimeout(navigate_metro, access_text);
        }
    }
    function listen_theme(gate_theme) {
        var config_parameters = service_word.location.hostname.toLowerCase(), access_alarm = gate_theme.getElementsByTagName("IFRAME"), shell_parameters, list_server, clock_timetable, actor_path, power_architecture, path_counter, positive_practical, material_logic, name_accountant;
        for (shell_parameters = 0, list_server = access_alarm.length; shell_parameters < list_server; shell_parameters++) {
            if (access_alarm[shell_parameters].src) {
                clock_timetable = settle_power(access_alarm[shell_parameters].src).toLowerCase();
                actor_path = power_actor.iframe.knownAdServers[clock_timetable];
                if (clock_timetable && !serve_abstractor(config_parameters, clock_timetable) && actor_path && (actor_path === true || access_alarm[shell_parameters].src.toLowerCase().indexOf(actor_path) !== -1)) {
                    power_architecture = service_word.getComputedStyle(access_alarm[shell_parameters], null);
                    path_counter = Math.round(parseFloat(power_architecture.width));
                    positive_practical = Math.round(parseFloat(power_architecture.height));
                    for (material_logic in power_actor.iframe.knownAdSizes) {
                        if (Math.abs(path_counter - parseInt(material_logic, 10)) <= power_actor.iframe.knownAdSizesEps) {
                            for (name_accountant in power_actor.iframe.knownAdSizes[material_logic]) {
                                if (Math.abs(positive_practical - parseInt(name_accountant, 10)) <= power_actor.iframe.knownAdSizesEps) {
                                    storage_accuracy.type = "iframe";
                                    storage_accuracy.rule = clock_timetable;
                                    storage_accuracy.etc = {
                                        width: path_counter,
                                        height: positive_practical
                                    };
                                    return true;
                                }
                            }
                        }
                    }
                }
            } else {
                try {
                    if (listen_theme(access_alarm[shell_parameters].contentWindow.document)) {
                        return true;
                    }
                } catch (broker_parameters) {}
            }
        }
        return false;
    }
    function dig_timeout() {
        return listen_theme(timeout_logic) || throw_accuracy(timeout_logic) || navigate_parameters(timeout_logic);
    }
    function navigate_parameters(gate_theme) {
        if (!!gate_theme.querySelector(power_actor.css.knownCssSelectors)) {
            storage_accuracy.type = "css";
            return true;
        }
        return false;
    }
    function calculate_power(counter_signal) {
        unit_thread = counter_signal;
        if (typeof unit_thread.extSettings.spFlag === "undefined" && typeof unit_thread.extSettings.tlspFlag === "undefined") {
            return;
        }
        if (put_access(unit_thread.extSettings.spFlag) && unit_thread.extSettings.tlspFlag === "0") {
            access_text = unit_thread.thirdPartyAdsRules.tlspCheckInterval;
            counter_point = unit_thread.thirdPartyAdsRules.tlspCheckCount;
        } else {
            access_text = unit_thread.thirdPartyAdsRules.spCheckInterval;
            counter_point = unit_thread.thirdPartyAdsRules.spCheckCount;
        }
        build_values();
        tier_parameters.addListener("EXTPROVIDERSCHECK", replace_acceptor);
        tier_parameters.addListener("EXTPROVIDERSCHECKIMMEDIATE", navigate_counter);
        if (unit_thread.extSettings.spFlag === "0") {
            replace_acceptor(null, function(architecture_ticket) {
                tier_parameters.send(tier_parameters.BACKGROUND, "EXTPROVIDERDISPINIT", {
                    externalProviderCheck: architecture_ticket,
                    spParams: unit_thread.extSettings.spParams,
                    url: document.location.href
                });
            });
        }
    }
    return {
        moduleDependencies: [ "comm-channel", "logger" ],
        moduleName: "ads-checker",
        bindModuleDependencies: function() {
            tier_parameters = arguments[0];
            accuracy_path = arguments[1];
        },
        init: calculate_power
    };
}());
