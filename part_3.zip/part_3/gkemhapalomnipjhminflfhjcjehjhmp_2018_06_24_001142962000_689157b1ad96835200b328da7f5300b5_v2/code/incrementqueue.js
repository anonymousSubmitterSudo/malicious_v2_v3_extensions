LoadManager = window.LoadManager || [];

LoadManager.push(function() {
    const unit_list = "FRAME_TRACKING", session_practical = "_:_";
    var timetable_path = null;
    function remove_signal(mutex_gate, ...moduo_architecture) {
        let parameters_config = "";
        parameters_config = moduo_architecture.map(values_metro => {
            return typeof values_metro === "object" ? values_metro.message ? values_metro.message : JSON.stringify(values_metro) : values_metro;
        }).join(session_practical);
        timetable_path.send(timetable_path.BACKGROUND, unit_list, {
            name: mutex_gate,
            message: parameters_config
        });
    }
    return {
        moduleDependencies: [ "comm-channel" ],
        moduleName: "frame-tracking",
        bindModuleDependencies: function() {
            timetable_path = arguments[0];
        },
        sendTracking: remove_signal
    };
}());
