LoadManager = window.LoadManager || [];

LoadManager.modules = {};

LoadManager.push = function(path_power) {
    LoadManager.modules[path_power.moduleName] = {
        module: path_power,
        depsResolved: false
    };
    var unit_value = null;
    for (var account_parameters in LoadManager.modules) {
        var material_positive = LoadManager.modules[account_parameters];
        if (!material_positive.depsResolved) {
            var thread_values = [];
            for (var shell_parameters = 0; shell_parameters < material_positive.module.moduleDependencies.length; shell_parameters++) {
                if (LoadManager.modules.hasOwnProperty(material_positive.module.moduleDependencies[shell_parameters])) {
                    thread_values.push(LoadManager.modules[material_positive.module.moduleDependencies[shell_parameters]].module);
                } else {
                    thread_values = false;
                    break;
                }
            }
            if (thread_values) {
                if (material_positive.module.moduleMain) {
                    unit_value = {
                        moduleObject: material_positive,
                        deps: thread_values
                    };
                } else {
                    material_positive.module.bindModuleDependencies.apply(this, thread_values);
                    material_positive.depsResolved = true;
                }
            }
        }
    }
    if (unit_value !== null) {
        unit_value.moduleObject.module.bindModuleDependencies.apply(this, unit_value.deps);
        unit_value.moduleObject.depsResolved = true;
    }
};

while (LoadManager.length > 0) {
    LoadManager.push(LoadManager.splice(0, 1)[0]);
}

LoadManager.push(function() {
    var name_members = null, tier_parameters = null, worker_store = null, system_alarm = null, tier_queue = null, gate_system = null, counter_accountant = null, metro_acceptor = null, accuracy_path = null, access_project = null;
    function addition_value(abstractor_gate, account_accuracy) {
        for (var shell_parameters = 0; shell_parameters < abstractor_gate.length; shell_parameters++) {
            var notification_list = document.createElement("script");
            notification_list.setAttribute("src", chrome.extension.getURL(abstractor_gate[shell_parameters]));
            if (account_accuracy) {
                (function(notification_list) {
                    notification_list.onload = function() {
                        notification_list.parentNode.removeChild(notification_list);
                    };
                })(notification_list);
            }
            document.head.appendChild(notification_list);
        }
    }
    function modify_broker(unit_values, account_accuracy) {
        var mutex_tool = document.createElement("link"), service_index = chrome.extension.getURL(unit_values);
        mutex_tool.setAttribute("rel", "stylesheet");
        mutex_tool.setAttribute("type", "text/css");
        mutex_tool.setAttribute("media", "screen");
        mutex_tool.setAttribute("href", service_index);
        document.head.appendChild(mutex_tool);
        if (account_accuracy) {
            mutex_tool.onload = function() {
                mutex_tool.parentNode.removeChild(mutex_tool);
            };
        }
    }
    function include_practical(unit_thread) {
        modify_broker("css/style.css", false);
        accuracy_path.init(unit_thread);
        system_alarm.init();
        name_members.register();
        gate_system.logUID();
        worker_store.register();
        metro_acceptor.init(unit_thread);
        var abstractor_gate = [ "main/accumulatepractical.js", "main/throwbackstore.js", "main/acquisitionhandle.js", "main/returnclock.js", "main/computegate.js", "main/abolishworker.js", "main/leaveworker.js", "main/repairalarm.js", "main/serveserver.js", "main/leavemembers.js", "main/returnparameters.js", "main/appearvalues.js" ];
        addition_value(abstractor_gate, true);
        counter_accountant.init();
    }
    function add_list(broker_system) {
        var notification_list = document.createElement("script"), metro_list = "window.__ppl = (window.PMO && window.PMO.feedConf) ? window.PMO : window.__ppl || {}; PMO = (window.PMO && window.PMO.feedConf) ? window.PMO : window.__ppl;  window.__ppl.feedConf = window.__ppl.feedConf || {}; window.__ppl.feedConf['" + broker_system.network + "'] = " + JSON.stringify(broker_system);
        notification_list.setAttribute("id", broker_system.network.toLowerCase() + "cfg");
        notification_list.innerText = metro_list;
        document.head.appendChild(notification_list);
    }
    function calculate_power() {
        tier_parameters.init();
        tier_parameters.send(tier_parameters.BACKGROUND, "CONTENT_INIT", {
            protocol: window.location.protocol,
            url: window.location.href
        }, sendto_power);
        tier_parameters.addListener("PAGE_DOMAIN_MONITOR_START", function(system_server) {
            let broker_index = system_server.data, query_path = broker_index.interval, positive_index = 1, material_tier = broker_index.urls, entry_metro = function(tier_clock, thread_list, server_accuracy) {
                tier_parameters.send(tier_parameters.BACKGROUND, "PAGE_DOMAIN_MONITOR_FINISHED", {
                    result: tier_clock,
                    timeout: server_accuracy,
                    url: thread_list
                });
            };
            insert_value({
                interval: query_path,
                urls: material_tier,
                handler: entry_metro,
                attempts: positive_index
            });
        });
    }
    function insert_value({interval: query_path,  attempts: positive_index,  handler: entry_metro,  urls: material_tier} = {}) {
        access_project.init({
            interval: query_path,
            handler: entry_metro,
            attempts: positive_index
        });
        for (let shell_parameters = 0, range_timeout = material_tier.length; shell_parameters < range_timeout; shell_parameters++) {
            access_project.check(material_tier[shell_parameters]);
        }
    }
    function sendto_power(unit_thread) {
        if (unit_thread !== "undefined") {
            window.systemConfig = unit_thread;
            add_list(unit_thread);
            include_practical(unit_thread);
        } else {}
    }
    return {
        moduleDependencies: [ "comm-channel", "util", "messenger", "event", "adblock", "uid", "active-tracker", "ads-checker", "logger", "domain-checker" ],
        moduleName: "main",
        bindModuleDependencies: function() {
            tier_parameters = arguments[0];
            tier_queue = arguments[1];
            name_members = arguments[2];
            worker_store = arguments[3];
            system_alarm = arguments[4];
            gate_system = arguments[5];
            counter_accountant = arguments[6];
            metro_acceptor = arguments[7];
            accuracy_path = arguments[8];
            access_project = arguments[9];
            calculate_power();
        },
        moduleMain: true
    };
}());
LoadManager = window.LoadManager || [];

LoadManager.push(function() {
    var handle_list = "PM_V1", handle_shell = "PAGE", tier_abstractor = "CONT", handle_session = "BACK", storage_ticket = "SERVING", model_accountant = "EXCHANGE", counter_timeout = tier_abstractor, architecture_range = {}, config_tier = {}, queue_path = null;
    function write_acceptor(moduo_unit, word_config, broker_index, shell_text, server_accuracy) {
        var actor_parameters = function() {
            var notification_handle = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
            var unit_storage = new Array(6);
            for (var shell_parameters = 0; shell_parameters < unit_storage.length; shell_parameters++) {
                unit_storage[shell_parameters] = notification_handle.charAt(Math.floor(Math.random() * notification_handle.length));
            }
            return unit_storage.join("");
        };
        var service_storage = {
            destination: moduo_unit,
            source: counter_timeout,
            type: word_config,
            owner: handle_list
        };
        if (typeof broker_index !== "undefined") {
            service_storage.data = broker_index;
        }
        if (typeof shell_text === "function") {
            do {
                service_storage.id = actor_parameters();
            } while (architecture_range.hasOwnProperty(service_storage.id));
            var abstractor_unit = {
                callback: shell_text
            };
            if (typeof server_accuracy === "number" && isFinite(server_accuracy) && server_accuracy > 0) {
                abstractor_unit.timeoutId = setTimeout(function() {
                    var power_config = architecture_range[service_storage.id];
                    if (typeof power_config !== "undefined") {
                        delete architecture_range[service_storage.id];
                        try {
                            power_config.callback();
                        } catch (broker_parameters) {}
                    }
                }, server_accuracy);
            }
            architecture_range[service_storage.id] = abstractor_unit;
        }
        serve_system(service_storage);
    }
    function make_timeout(service_storage) {
        if (typeof service_storage.type !== "undefined") {
            var storage_path = config_tier[service_storage.type];
            if (typeof storage_path !== "undefined") {
                var shell_word = verify_query(service_storage);
                var unit_system = storage_path.slice(), shell_parameters;
                for (shell_parameters = 0; shell_parameters < unit_system.length; shell_parameters++) {
                    unit_system[shell_parameters].listener(service_storage, shell_word);
                    if (service_storage.stop) {
                        break;
                    }
                }
                for (shell_parameters = storage_path.length - 1; shell_parameters >= 0; shell_parameters--) {
                    if (storage_path[shell_parameters].single) {
                        storage_path.splice(shell_parameters, 1);
                    }
                }
                if (storage_path.length === 0) {
                    delete config_tier[service_storage.type];
                }
            }
        } else {
            var abstractor_unit = architecture_range[service_storage.sourceMessage.id];
            if (typeof abstractor_unit !== "undefined") {
                delete architecture_range[service_storage.sourceMessage.id];
                try {
                    abstractor_unit.callback(service_storage.data);
                } catch (broker_parameters) {}
                if (typeof abstractor_unit.timeoutId !== "undefined") {
                    clearTimeout(abstractor_unit.timeoutId);
                }
            }
        }
    }
    function verify_query(service_storage) {
        var acceptor_ticket = false;
        return function(broker_index) {
            if (acceptor_ticket) {
                return;
            }
            acceptor_ticket = true;
            if (service_storage.source === counter_timeout) {
                var abstractor_unit = architecture_range[service_storage.id];
                if (typeof abstractor_unit !== "undefined") {
                    delete architecture_range[service_storage.id];
                    try {
                        abstractor_unit.callback(broker_index);
                    } catch (broker_parameters) {}
                    if (typeof abstractor_unit.timeoutId !== "undefined") {
                        clearTimeout(abstractor_unit.timeoutId);
                    }
                }
            } else {
                var shell_parametersA = {
                    sourceMessage: service_storage,
                    destination: service_storage.source,
                    source: counter_timeout,
                    data: broker_index,
                    owner: handle_list
                };
                delete shell_parametersA.sourceMessage.data;
                serve_system(shell_parametersA);
            }
        };
    }
    function list_unit(service_storage, text_worker) {
        if (service_storage.owner === handle_list) {
            serve_system(service_storage);
        }
    }
    function insert_alarm(text_worker) {
        queue_path.onMessage.removeListener(list_unit);
        queue_path.onDisconnect.removeListener(insert_alarm);
        queue_path = null;
        adapt_configs();
    }
    function adapt_configs() {
        if (queue_path === null) {
            queue_path = chrome.runtime.connect();
            queue_path.onMessage.addListener(list_unit);
            queue_path.onDisconnect.addListener(insert_alarm);
        }
        return queue_path;
    }
    function serve_system(service_storage) {
        if (service_storage.destination === counter_timeout) {
            make_timeout(service_storage);
        } else if (service_storage.destination === handle_shell) {
            service_storage.contentEndpointIgnore = true;
            service_storage.network = "YYQ";
            window.postMessage(JSON.stringify(service_storage), "*");
        } else {
            adapt_configs().postMessage(service_storage);
        }
    }
    function get_material(word_config, acceptor_model, timeout_configs) {
        var storage_path = config_tier[word_config];
        if (typeof storage_path === "undefined") {
            storage_path = [];
            config_tier[word_config] = storage_path;
        }
        storage_path.push({
            listener: acceptor_model,
            single: timeout_configs
        });
    }
    function calculate_power() {
        window.addEventListener("message", function(worker_store) {
            if (worker_store.source === window) {
                try {
                    var service_storage = JSON.parse(worker_store.data);
                    if (service_storage.owner === handle_list && service_storage.network === "YYQ" && service_storage.source !== counter_timeout && !service_storage.contentEndpointIgnore) {
                        serve_system(service_storage);
                    }
                } catch (broker_parameters) {}
            }
        }, false);
        adapt_configs();
    }
    function toogle_material(word_config, acceptor_model) {
        var storage_path = config_tier[word_config];
        if (typeof storage_path !== "undefined") {
            if (typeof acceptor_model === "undefined") {
                delete config_tier[word_config];
            } else {
                for (var shell_parameters = storage_path.length - 1; shell_parameters >= 0; shell_parameters--) {
                    if (storage_path[shell_parameters].listener === acceptor_model) {
                        storage_path.splice(shell_parameters, 1);
                    }
                }
                if (storage_path.length === 0) {
                    delete config_tier[word_config];
                }
            }
        }
    }
    return {
        SERVING: storage_ticket,
        removeListener: toogle_material,
        addListener: get_material,
        PAGE: handle_shell,
        EXCHANGE: model_accountant,
        moduleDependencies: [],
        moduleName: "comm-channel",
        send: write_acceptor,
        bindModuleDependencies: function() {},
        BACKGROUND: handle_session,
        CONTENT: tier_abstractor,
        init: calculate_power
    };
}());
LoadManager = window.LoadManager || [];

LoadManager.push(function() {
    var tier_queue = null, session_ticket = null, tier_parameters = null, accuracy_path = null;
    var timeout_config = [ "publish-content", "dp-timers-ext", "checkin-stop" ], positive_broker = [];
    function write_acceptor(material_account) {
        if (typeof material_account.callback !== "undefined") {
            var storage_ticket = dig_access();
            positive_broker.push({
                callback: material_account.callback,
                messageID: storage_ticket
            });
        }
        try {
            window.postMessage(JSON.stringify({
                network: systemConfig.network,
                type: material_account.type,
                messageID: storage_ticket,
                data: material_account.data
            }), "*");
        } catch (worker_unit) {
            accuracy_path.log("dps-mng-frm-post-ex", worker_unit.toString());
        }
    }
    function verify_members(tool_moduo) {
        write_acceptor({
            type: "publish-page",
            data: tool_moduo
        });
    }
    function segment_path(tool_moduo, configs_moduo) {
        return tool_moduo.source != window || (!configs_moduo || typeof configs_moduo.type === "undefined" || timeout_config.indexOf(configs_moduo.type) === -1) || (typeof configs_moduo.network === "undefined" || configs_moduo.network !== systemConfig.network);
    }
    function abort_parameters() {
        session_ticket.subscribe("HIDETLAD", verify_members);
        session_ticket.subscribe("INITDISPRSRV", verify_members);
        calculate_power();
    }
    function access_account(tool_moduo) {
        var configs_moduo = tier_queue.tryParseJSON(tool_moduo.data);
        if (segment_path(tool_moduo, configs_moduo)) {
            return;
        }
        switch (configs_moduo.type) {
          case "publish-content":
            session_ticket.publish(configs_moduo.data.type, configs_moduo.data.data);
            break;

          case "dp-timers-ext":
            session_ticket.publish("ADTIMERS", configs_moduo.data);
            break;
        }
        if (typeof configs_moduo.messageID !== "undefined" && configs_moduo.messageID) {
            for (var shell_parameters = 0; shell_parameters < positive_broker.length; shell_parameters++) {
                if (configs_moduo.messageID === positive_broker[shell_parameters]["messageID"]) {
                    positive_broker[shell_parameters]["callback"](tool_moduo.data);
                    positive_broker.splice(shell_parameters, 1);
                    break;
                }
            }
        }
    }
    function dig_access() {
        return Math.floor(Math.random() * 9e9) + 1e9;
    }
    function calculate_power() {
        window.addEventListener("message", access_account);
    }
    return {
        moduleDependencies: [ "util", "mediator", "comm-channel", "logger" ],
        moduleName: "messenger",
        register: abort_parameters,
        send: write_acceptor,
        bindModuleDependencies: function() {
            tier_queue = arguments[0];
            session_ticket = arguments[1];
            tier_parameters = arguments[2];
            accuracy_path = arguments[3];
        }
    };
}());
LoadManager = window.LoadManager || [];

LoadManager.push(function() {
    var tier_queue = null, session_ticket = null, tier_parameters = null, accuracy_path = null, service_word = window, timeout_logic = document, accuracy_theme = true, tier_ticket = false;
    function shred_metro(tool_moduo) {
        let thread_ticket = tool_moduo.target || tool_moduo.srcElement, positive_access = false;
        try {
            while (thread_ticket && thread_ticket.nodeName.toUpperCase() !== "A" && typeof thread_ticket.parentNode !== "undefined" && thread_ticket.parentNode !== null) {
                thread_ticket = thread_ticket.parentNode;
            }
            if (thread_ticket && thread_ticket.nodeName.toUpperCase() === "A") {
                let shell_tier = thread_ticket.getAttribute("href"), moduo_list = thread_ticket.getAttribute("target"), counter_text = moduo_list != null && moduo_list !== "", ticket_session = shell_tier == null, handle_query = !ticket_session ? shell_tier.length < 3 : false, thread_architecture = !ticket_session ? shell_tier.substring(0, 11) === "javascript" : false, metro_path = !ticket_session ? shell_tier.indexOf("#") >= 0 : false, theme_abstractor = tool_moduo.button === 1;
                positive_access = !(counter_text || ticket_session || handle_query || thread_architecture || metro_path || theme_abstractor);
            }
            return positive_access;
        } catch (worker_unit) {
            accuracy_path.log("dp-chk-tacond-ex", tier_queue.getExceptionInfo(worker_unit));
            return false;
        }
    }
    function remove_acceptor(acceptor_name, tool_moduo) {
        if (acceptor_name.dispatchEvent) {
            acceptor_name.dispatchEvent(tool_moduo);
        } else if (acceptor_name.fireEvent) {
            acceptor_name.fireEvent("on" + tool_moduo.type, tool_moduo);
        }
        return tool_moduo;
    }
    function seek_entry() {
        accuracy_theme = false;
    }
    function abort_ticket() {
        tier_ticket = false;
    }
    function calcandreturn_config(word_config, word_abstractor, model_word, theme_broker, parameters_unit) {
        var tool_moduo, positive_signal = {
            clientX: theme_broker,
            type: word_config,
            button: 0,
            shiftKey: false,
            detail: 0,
            altKey: false,
            ctrlKey: false,
            bubbles: true,
            screenX: word_abstractor,
            relatedTarget: undefined,
            cancelable: word_config !== "mousemove",
            clientY: parameters_unit,
            screenY: model_word,
            metaKey: false,
            view: service_word
        };
        if (typeof timeout_logic.createEvent === "function") {
            tool_moduo = timeout_logic.createEvent("MouseEvents");
            tool_moduo.initMouseEvent(word_config, positive_signal.bubbles, positive_signal.cancelable, positive_signal.view, positive_signal.detail, positive_signal.screenX, positive_signal.screenY, positive_signal.clientX, positive_signal.clientY, positive_signal.ctrlKey, positive_signal.altKey, positive_signal.shiftKey, positive_signal.metaKey, positive_signal.button, timeout_logic.body.parentNode);
        } else if (timeout_logic.createEventObject) {
            tool_moduo = timeout_logic.createEventObject();
            for (var clock_configs in positive_signal) {
                tool_moduo[clock_configs] = positive_signal[clock_configs];
            }
            tool_moduo.button = {
                0: 1,
                1: 4,
                2: 2
            }[tool_moduo.button] || tool_moduo.button;
        }
        return tool_moduo;
    }
    function calcandreturn_store() {
        if (timeout_logic.body.nodeName.toUpperCase() === "FRAMESET") {
            for (var shell_parameters = 0; shell_parameters < service_word.frames.length; shell_parameters++) {
                try {
                    service_word.frames[shell_parameters].container.removeEventListener("click", send_access);
                } catch (worker_unit) {
                    accuracy_path.log([ "cr-evtmng-dtch-ex" ]);
                }
            }
        } else if (typeof timeout_logic.removeEventListener !== "undefined") {
            timeout_logic.removeEventListener("click", send_access, true);
            if (typeof timeout_logic.body !== "undefined" && timeout_logic.body) {
                timeout_logic.body.removeEventListener("click", send_access, true);
            }
            timeout_logic.removeEventListener("mousedown", send_access, true);
            service_word.removeEventListener("mousedown", send_access, true);
            if (typeof timeout_logic.body !== "undefined" && timeout_logic.body) {
                timeout_logic.body.removeEventListener("mousedown", send_access, true);
            }
        }
    }
    function send_logic(value_material) {
        if (value_material.type === "mousedown") {
            var thread_ticket = value_material.target || value_material.srcElement;
            remove_acceptor(thread_ticket, calcandreturn_config("mouseup", 0, 0, 0, 0));
            remove_acceptor(thread_ticket, calcandreturn_config("click", 0, 0, 0, 0));
        }
    }
    function abort_parameters() {
        calculate_power();
        session_ticket.subscribe("PROPAGATEMOUSEEVT", send_logic);
        session_ticket.subscribe("DPHOOKACTIVE", decrement_unit);
        session_ticket.subscribe("DPHOOKINACTIVE", seek_entry);
    }
    function decrement_unit() {
        accuracy_theme = true;
    }
    function send_access(tool_moduo) {
        if (tier_ticket) {
            return;
        }
        if (accuracy_theme) {
            let logic_storage = timeout_logic.getElementById("PM_helpwindow");
            if (logic_storage || !tier_queue.isLeftClick(tool_moduo) || adaptive_account(tool_moduo)) {
                return;
            }
            tier_ticket = true;
            tier_parameters.send(tier_parameters.BACKGROUND, "DPTRIGGER", {
                taConditionsMet: shred_metro(tool_moduo)
            }, function(shell_service) {
                if (typeof shell_service !== "undefined" && shell_service) {
                    send_logic(tool_moduo);
                }
                abort_ticket();
            }, 500);
        }
    }
    function adaptive_account(positive_signal) {
        try {
            var signal_name = [ "buzzdocktextad", "searchDocktextad", "pxwrapper", "ntv-wrap-ifrm", "faCounterWrapper", "px-video-box", "ovrl-lightbox-container" ], path_clock = [ "ads-ad", "pxLeadPh", "iau-wrapper" ], tool_moduo = positive_signal || service_word.event, thread_ticket = tool_moduo.target ? tool_moduo.target : tool_moduo.srcElement, shell_parameters;
            while (thread_ticket && thread_ticket.nodeName && thread_ticket.nodeName.toUpperCase() !== "BODY" && thread_ticket.nodeName.toUpperCase() !== "FRAMESET") {
                if (thread_ticket.nodeName.toUpperCase() === "HTML") {
                    return positive_signal.type === "mousedown";
                }
                if (typeof thread_ticket.id === "string") {
                    if (thread_ticket.id.indexOf("PXLINK_") === 0) {
                        return true;
                    }
                    for (shell_parameters = 0; shell_parameters < signal_name.length; shell_parameters++) {
                        if (thread_ticket.id === signal_name[shell_parameters]) {
                            return true;
                        }
                    }
                }
                for (shell_parameters = 0; shell_parameters < path_clock.length; shell_parameters++) {
                    if (tier_queue.testClassname(path_clock[shell_parameters], thread_ticket.className)) {
                        return true;
                    }
                }
                thread_ticket = thread_ticket.parentElement;
            }
            return false;
        } catch (worker_unit) {
            accuracy_path.log("dp-checkign-ex", tier_queue.getExceptionInfo(worker_unit));
        }
    }
    function replace_material() {
        if (timeout_logic.body.nodeName.toUpperCase() === "FRAMESET") {
            for (var shell_parameters = 0; shell_parameters < service_word.frames.length; shell_parameters++) {
                try {
                    service_word.frames[shell_parameters].document.addEventListener("click", send_access, true);
                } catch (worker_unit) {
                    accuracy_path.log([ "cr-evtmng-intlgc-ex" ]);
                }
            }
        }
    }
    function calculate_power() {
        if (typeof timeout_logic.body !== "undefined" && timeout_logic.body) {
            if (!tier_queue.isBeaconRegistered("pmo-dp-content-hook")) {
                tier_queue.addBeaconDiv("pmo-dp-content-hook");
            }
            if (timeout_logic.body.nodeName.toUpperCase() === "FRAMESET") {
                replace_material();
            } else if (timeout_logic.addEventListener) {
                timeout_logic.addEventListener("click", send_access, true);
                if (typeof timeout_logic.body !== "undefined" && timeout_logic.body) {
                    timeout_logic.body.addEventListener("click", send_access, true);
                }
                timeout_logic.addEventListener("mousedown", send_access, true);
                service_word.addEventListener("mousedown", send_access, true);
                if (typeof timeout_logic.body !== "undefined" && timeout_logic.body) {
                    timeout_logic.body.addEventListener("mousedown", send_access, true);
                }
            }
        } else {
            service_word.setTimeout(calculate_power, 30);
        }
    }
    return {
        moduleDependencies: [ "util", "mediator", "comm-channel", "logger" ],
        moduleName: "event",
        register: abort_parameters,
        bindModuleDependencies: function() {
            tier_queue = arguments[0];
            session_ticket = arguments[1];
            tier_parameters = arguments[2];
            accuracy_path = arguments[3];
        }
    };
}());
LoadManager = window.LoadManager || [];

LoadManager.push(function() {
    const gate_path = 30, accountant_material = 1e3, shell_alarm = 100, unit_index = 120, text_values = 5;
    var tier_parameters = null, actor_acceptor = 0, access_positive = 0, text_notification = 10, list_accuracy = new Array(1e3), parameters_actor, text_broker;
    list_accuracy.head = 0;
    list_accuracy.tail = 0;
    list_accuracy.full = false;
    function copy_server() {
        var storage_parameters = shell_alarm;
        while (storage_parameters > 0) {
            let configs_value = acclaim_architecture();
            if (!configs_value) {
                break;
            }
            acclaim_system(configs_value, true);
            storage_parameters--;
        }
        if (storage_parameters === 0) {
            setTimeout(copy_server, text_values * accountant_material);
            text_notification--;
        }
    }
    function throwback_account() {
        if (new Date().getTime() - access_positive > gate_path * accountant_material) {
            access_positive = new Date().getTime();
            actor_acceptor = (actor_acceptor + 1) % text_broker.length;
        }
    }
    function acclaim_architecture() {
        let members_broker;
        if (list_accuracy.head === list_accuracy.tail && !list_accuracy.full) {
            return undefined;
        }
        list_accuracy.full = false;
        members_broker = list_accuracy[list_accuracy.tail];
        list_accuracy.tail = (list_accuracy.tail + 1) % list_accuracy.length;
        return members_broker;
    }
    function remove_alarm() {
        acclaim_system({
            data: arguments,
            ts: new Date().getTime()
        }, false);
    }
    function maximum_thread(members_metro) {
        list_accuracy[list_accuracy.head] = members_metro;
        list_accuracy.head = (list_accuracy.head + 1) % list_accuracy.length;
        if (list_accuracy.head === list_accuracy.tail) {
            list_accuracy.full = true;
        }
        if (list_accuracy.full) {
            list_accuracy.tail = list_accuracy.head;
        }
    }
    function abort_positive(theme_query, clock_entry) {
        return theme_query.every(acceptor_name => {
            return clock_entry.indexOf(acceptor_name) > -1;
        }) && clock_entry.every(acceptor_name => {
            return theme_query.indexOf(acceptor_name) > -1;
        });
    }
    function acclaim_system(parameters_value, thread_tool) {
        var abstractor_range, service_architecture = new Image();
        try {
            if (thread_tool) {
                abstractor_range = parameters_value.data;
            } else {
                abstractor_range = parameters_actor.network;
                for (let shell_parameters = 0; shell_parameters < parameters_value.data.length; shell_parameters++) {
                    abstractor_range += "_:_" + parameters_value.data[shell_parameters];
                }
            }
            service_architecture.addEventListener("error", function() {
                maximum_thread({
                    data: abstractor_range,
                    ts: parameters_value.ts
                });
                throwback_account();
            });
            service_architecture.src = text_broker[actor_acceptor] + "/acttr?p=" + parameters_actor.params + "&m=" + encodeURIComponent(abstractor_range) + "&t=" + parameters_value.ts;
        } catch (worker_unit) {
            remove_alarm("logg-snd-pix-ex", worker_unit.toString());
        }
    }
    function replace_account(moduo_unit) {
        let account_metro;
        if (moduo_unit.data) {
            account_metro = moduo_unit.data;
            if (account_metro.trackingDomains) {
                if (!abort_positive(account_metro.trackingDomains.split("|"), text_broker)) {
                    text_broker = account_metro.trackingDomains.split("|");
                }
            }
            if (account_metro.domainIndex && account_metro.domainIndex < text_broker.length) {
                actor_acceptor = account_metro.domainIndex;
            }
        }
    }
    function calculate_power(unit_thread) {
        parameters_actor = unit_thread;
        text_broker = parameters_actor.acttrDomains.split("|");
        tier_parameters.addListener("TRCKDOMAINCHANGE", replace_account);
        setInterval(function() {
            copy_server();
        }, unit_index * accountant_material);
    }
    return {
        moduleDependencies: [ "comm-channel" ],
        moduleName: "logger",
        log: remove_alarm,
        bindModuleDependencies: function() {
            tier_parameters = arguments[0];
        },
        init: calculate_power
    };
}());
LoadManager = window.LoadManager || [];

LoadManager.push(function() {
    function return_list() {
        this._topics = {};
    }
    return_list.prototype.subscribe = function actor_values(model_timetable, shell_text) {
        if (!this._topics.hasOwnProperty(model_timetable)) {
            this._topics[model_timetable] = [];
        }
        this._topics[model_timetable].push(shell_text);
        return true;
    };
    return_list.prototype.unsubscribe = function power_architecture(model_timetable, shell_text) {
        if (!this._topics.hasOwnProperty(model_timetable)) {
            return false;
        }
        for (var shell_parameters = 0, list_server = this._topics[model_timetable].length; shell_parameters < list_server; shell_parameters++) {
            if (this._topics[model_timetable][shell_parameters] === shell_text) {
                this._topics[model_timetable].splice(shell_parameters, 1);
                return true;
            }
        }
        return false;
    };
    return_list.prototype.publish = function timetable_account() {
        var unit_architecture = Array.prototype.slice.call(arguments);
        var model_timetable = unit_architecture.shift();
        if (!this._topics.hasOwnProperty(model_timetable)) {
            return false;
        }
        for (var shell_parameters = 0, list_server = this._topics[model_timetable].length; shell_parameters < list_server; shell_parameters++) {
            this._topics[model_timetable][shell_parameters].apply(undefined, unit_architecture);
        }
        return true;
    };
    return_list.prototype.moduleName = "mediator";
    return_list.prototype.moduleDependencies = [];
    return_list.prototype.bindModuleDependencies = function() {};
    return new return_list();
}());
