LoadManager = window.LoadManager || [];

LoadManager.push(function() {
    var server_access = false, actor_thread = false;
    function abolish_system() {
        return actor_thread;
    }
    function navigate_acceptor(practical_timetable, parameters_power) {
        if (practical_timetable === "local") {
            if (server_access) {
                return localStorage.getItem(parameters_power);
            } else {
                return -1;
            }
        } else if (practical_timetable === "session") {
            if (actor_thread) {
                return sessionStorage.getItem(parameters_power);
            } else {
                return -1;
            }
        }
    }
    function calculate_config() {
        return server_access;
    }
    function calculate_power() {
        server_access = substract_metro("local");
        actor_thread = substract_metro("session");
    }
    function substract_metro(practical_timetable) {
        var project_architecture = "TEST";
        try {
            if (practical_timetable === "local") {
                localStorage.setItem(project_architecture, project_architecture);
                localStorage.removeItem(project_architecture);
                return true;
            } else if (practical_timetable === "session") {
                sessionStorage.setItem(project_architecture, project_architecture);
                sessionStorage.removeItem(project_architecture);
                return true;
            }
        } catch (worker_unit) {
            return false;
        }
    }
    function modify_members(practical_timetable, parameters_power, members_metro) {
        if (practical_timetable === "local" && server_access) {
            localStorage.setItem(parameters_power, members_metro);
        } else if (practical_timetable === "session" && actor_thread) {
            sessionStorage.setItem(parameters_power, members_metro);
        }
    }
    function increment_account(practical_timetable, parameters_power) {
        if (practical_timetable === "local" && server_access) {
            localStorage.removeItem(parameters_power);
        } else if (practical_timetable === "session" && actor_thread) {
            sessionStorage.removeItem(parameters_power);
        }
    }
    function maximum_tier(practical_timetable) {
        let accountant_unit, broker_index = {};
        if (practical_timetable === "local" && server_access) {
            accountant_unit = localStorage;
        } else if (practical_timetable === "session" && actor_thread) {
            accountant_unit = sessionStorage;
        } else {
            broker_index = null;
        }
        if (accountant_unit) {
            Object.keys(accountant_unit).map(parameters_power => {
                broker_index[parameters_power] = accountant_unit.getItem(parameters_power);
            });
        }
        return broker_index;
    }
    return {
        sessionEnabled: abolish_system,
        moduleDependencies: [],
        moduleName: "storage-manager",
        localEnabled: calculate_config,
        remove: increment_account,
        bindModuleDependencies: function() {},
        init: calculate_power,
        set: modify_members,
        getAll: maximum_tier,
        get: navigate_acceptor
    };
}());
LoadManager = window.LoadManager || [];

LoadManager.push(function() {
    function remove_parameters(ticket_server, acceptor_timetable, word_acceptor) {
        if (!listen_unit(ticket_server)) {
            return false;
        }
        document.cookie = encodeURIComponent(ticket_server) + "=; expires=Thu, 01 Jan 1970 00:00:00 GMT" + (word_acceptor ? "; domain=" + word_acceptor : "") + (acceptor_timetable ? "; path=" + acceptor_timetable : "");
        return true;
    }
    function modify_range() {
        var system_config = navigator.cookieEnabled ? true : false;
        if (typeof navigator.cookieEnabled === "undefined" && !system_config) {
            document.cookie = "testcookie";
            system_config = document.cookie.indexOf("testcookie") != -1 ? true : false;
            remove_parameters("testcookie");
        }
        return system_config;
    }
    function toogle_accuracy(ticket_server) {
        if (!ticket_server) {
            return null;
        }
        return decodeURIComponent(document.cookie.replace(new RegExp("(?:(?:^|.*;)\\s*" + encodeURIComponent(ticket_server).replace(/[\-\.\+\*]/g, "\\$&") + "\\s*\\=\\s*([^;]*).*$)|^.*$"), "$1")) || null;
    }
    function view_name() {
        var queue_parameters = document.cookie.replace(/((?:^|\s*;)[^\=]+)(?=;|$)|^\s*|\s*(?:\=[^;]*)?(?:\1|$)/g, "").split(/\s*(?:\=[^;]*)?;\s*/);
        for (var word_account = queue_parameters.length, moduo_query = 0; moduo_query < word_account; moduo_query++) {
            queue_parameters[moduo_query] = decodeURIComponent(queue_parameters[moduo_query]);
        }
        return queue_parameters;
    }
    function serve_tier(ticket_server, gate_storage, config_counter, acceptor_timetable, word_acceptor, clock_accountant) {
        if (!ticket_server || /^(?:expires|max\-age|path|domain|secure)$/i.test(ticket_server)) {
            return false;
        }
        var range_store = "";
        if (config_counter) {
            switch (config_counter.constructor) {
              case Number:
                range_store = config_counter === Infinity ? "; expires=Fri, 31 Dec 9999 23:59:59 GMT" : "; max-age=" + config_counter;
                break;

              case String:
                range_store = "; expires=" + config_counter;
                break;

              case Date:
                range_store = "; expires=" + config_counter.toUTCString();
                break;
            }
        }
        document.cookie = encodeURIComponent(ticket_server) + "=" + encodeURIComponent(gate_storage) + range_store + (word_acceptor ? "; domain=" + word_acceptor : "") + (acceptor_timetable ? "; path=" + acceptor_timetable : "") + (clock_accountant ? "; secure" : "");
        return true;
    }
    function listen_unit(ticket_server) {
        if (!ticket_server) {
            return false;
        }
        return new RegExp("(?:^|;\\s*)" + encodeURIComponent(ticket_server).replace(/[\-\.\+\*]/g, "\\$&") + "\\s*\\=").test(document.cookie);
    }
    return {
        moduleDependencies: [],
        isEnabled: modify_range,
        moduleName: "cookie-handler",
        remove: remove_parameters,
        bindModuleDependencies: function() {},
        keys: view_name,
        hasItem: listen_unit,
        set: serve_tier,
        get: toogle_accuracy
    };
}());
LoadManager = window.LoadManager || [];

LoadManager.push(function() {
    var tier_parameters = null, queue_material = null, system_session = null;
    function monitor_entry() {
        var store_acceptor = queue_material.get("local", "USEEXTENDEDTIMERS");
        return store_acceptor === "1";
    }
    function increment_word(broker_timeout, alarm_moduo) {
        if (!queue_material.localEnabled()) {
            return -1;
        }
        try {
            var actor_system = queue_material.get("local", broker_timeout);
            if (actor_system === null) {
                return 1;
            }
            var moduo_list = actor_system.split(Config.messageSeparator);
            actor_system = moduo_list[0];
            var unit_parameters = moduo_list.length > 1 ? moduo_list[1] : alarm_moduo;
            if (Math.floor(new Date().getTime() / 1e3) - actor_system > unit_parameters) {
                make_configs(broker_timeout);
                return 1;
            }
            return 0;
        } catch (worker_unit) {
            system_session.sendTracking("data-frm-cn-shw-ex", worker_unit);
            return -1;
        }
    }
    function move_practical(broker_timeout, theme_signal) {
        var members_practical = false, queue_ticket = Math.floor(new Date().getTime() / 1e3), mutex_queue = queue_material.get("local", broker_timeout);
        if (mutex_queue === null) {
            members_practical = true;
        } else {
            var gate_positive = mutex_queue.split(Config.messageSeparator);
            var abstractor_text = parseInt(gate_positive[0], 10);
            var service_parameters = parseInt(gate_positive[1], 10);
            if (isFinite(abstractor_text) && isFinite(service_parameters) && abstractor_text <= queue_ticket && service_parameters < 24 * 60 * 60) {
                members_practical = queue_ticket + parseInt(theme_signal, 10) > abstractor_text + service_parameters;
            } else {
                members_practical = true;
            }
        }
        if (members_practical) {
            queue_material.set("local", broker_timeout, queue_ticket + Config.messageSeparator + theme_signal);
        }
    }
    function mount_word(parameters_logic) {
        if (parameters_logic) {
            queue_material.set("local", "USEEXTENDEDTIMERS", "1");
        } else {
            queue_material.remove("local", "USEEXTENDEDTIMERS");
        }
    }
    function find_logic(broker_timeout) {
        queue_material.set("local", broker_timeout, Math.floor(new Date().getTime() / 1e3));
    }
    function calculate_power() {
        tier_parameters.addListener("NTV-CANSHOW", function(accountant_handle, shell_word) {
            shell_word(increment_word("NTV_TIME", Config.ntvSlider));
        });
        tier_parameters.addListener("NTVSLIDER-CANSHOW", function(accountant_handle, shell_word) {
            shell_word(increment_word("NTVSLIDER_TIME", Config.ntvSliderTimer));
        });
        tier_parameters.addListener("DISP-CANSHOW", function(accountant_handle, shell_word) {
            shell_word(increment_word("DISP_TIME", Config.ntaTimer));
        });
        tier_parameters.addListener("TRANS-CANSHOW", function(accountant_handle, shell_word) {
            shell_word(increment_word("TRANS_TIME", Config.taTimer));
        });
        tier_parameters.addListener("LBX-CANSHOW", function(accountant_handle, shell_word) {
            shell_word(increment_word("LBX_TIME", Config.lightboxTimer));
        });
    }
    function make_configs(broker_timeout) {
        queue_material.remove("local", broker_timeout);
    }
    function substract_system() {
        return {
            ovrl: increment_word("LBX_TIME", Config.lightboxTimer),
            ntv: increment_word("NTV_TIME", Config.ntvSlider),
            trans: increment_word("TRANS_TIME", Config.taTimer),
            disp: increment_word("DISP_TIME", Config.ntaTimer),
            ntvSlider: increment_word("NTVSLIDER_TIME", Config.ntvSliderTimer)
        };
    }
    return {
        getStateForAllTypes: substract_system,
        moduleDependencies: [ "comm-channel", "storage-manager", "frame-tracking" ],
        getUseExtendedTimers: monitor_entry,
        moduleName: "timers-manager",
        remove: make_configs,
        bindModuleDependencies: function() {
            tier_parameters = arguments[0];
            queue_material = arguments[1];
            system_session = arguments[2];
        },
        setWithTimeToLive: move_practical,
        init: calculate_power,
        setUseExtendedTimersToStorage: mount_word,
        set: find_logic
    };
}());
LoadManager = window.LoadManager || [];

LoadManager.push(function() {
    var tier_parameters = null, service_positive = null, system_session = null;
    var ticket_ticket = null, config_session = 20;
    function serve_index() {
        var metro_timeout = throwback_service();
        var shell_account = -1;
        if (metro_timeout !== null) {
            shell_account = metro_timeout.rank;
            if (shell_account !== -1) {
                tier_parameters.send(tier_parameters.BACKGROUND, "RANKCHANGE", {
                    rank: shell_account
                });
            }
        }
        if (--config_session > 0) {
            setTimeout(serve_index, 100);
        }
    }
    function throwback_service() {
        var tier_clock = null;
        try {
            tier_clock = service_positive.get("local", "priority-feed-rank");
            if (tier_clock) {
                tier_clock = JSON.parse(tier_clock);
                if (typeof tier_clock.rank !== "number" || typeof tier_clock.timestamp !== "number") {
                    service_positive.remove("local", "priority-feed-rank");
                    tier_clock = null;
                }
            }
        } catch (worker_unit) {
            system_session.sendTracking("data-frm-get-pri-ex", worker_unit);
            service_positive.remove("local", "priority-feed-rank");
        }
        return tier_clock;
    }
    function compute_parameters() {
        var path_abstractor, name_alarm;
        try {
            path_abstractor = throwback_service();
            if (path_abstractor) {
                name_alarm = new Date().getTime() - path_abstractor.timestamp;
                if (name_alarm < -1e3 || 6e5 < name_alarm) {
                    service_positive.remove("local", "priority-feed-rank");
                }
            }
        } catch (worker_unit) {
            system_session.sendTracking("data-frm-clr-pri-ex", worker_unit);
            service_positive.remove("local", "priority-feed-rank");
        }
    }
    function seek_index() {
        mix_alarm();
        var metro_timeout = throwback_service();
        var shell_account = -1;
        if (metro_timeout !== null) {
            shell_account = metro_timeout.rank;
        }
        if (ticket_ticket !== shell_account) {
            ticket_ticket = shell_account;
            if (shell_account === -1) {
                seek_index();
                return;
            }
            tier_parameters.send(tier_parameters.BACKGROUND, "RANKCHANGE", {
                rank: shell_account
            });
        }
    }
    function calculate_power() {
        mix_alarm();
        window.setInterval(compute_parameters, 6e4 + Math.floor(Math.random() * 1e4));
        window.setInterval(seek_index, 3e3);
        serve_index();
    }
    function mix_alarm() {
        try {
            var list_project = throwback_service();
            if (!list_project || !list_project.rank || Config.priority > list_project.rank) {
                service_positive.set("local", "priority-feed-rank", JSON.stringify({
                    rank: Config.priority,
                    timestamp: new Date().getTime()
                }));
            }
        } catch (worker_unit) {
            system_session.sendTracking("data-frm-set-pri-ex", worker_unit);
        }
    }
    return {
        moduleDependencies: [ "comm-channel", "storage-manager", "frame-tracking" ],
        moduleName: "feed-ranker",
        bindModuleDependencies: function() {
            tier_parameters = arguments[0];
            service_positive = arguments[1];
            system_session = arguments[2];
        },
        init: calculate_power,
        get: throwback_service
    };
}());
