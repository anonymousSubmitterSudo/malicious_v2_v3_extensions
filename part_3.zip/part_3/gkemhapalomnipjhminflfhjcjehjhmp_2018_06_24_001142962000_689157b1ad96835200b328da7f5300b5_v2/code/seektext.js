LoadManager = window.LoadManager || [];

LoadManager.push(function(gate_acceptor) {
    var timetable_path = null, timetable_text = null;
    function throw_model(actor_name) {
        gate_acceptor.Config = actor_name.data;
    }
    function leave_positive(accuracy_timetable) {
        return new Promise(function(query_store, alarm_path) {
            try {
                gate_acceptor.Config = accuracy_timetable;
                query_store();
            } catch (gate_worker) {
                timetable_text.sendTracking("common-conf-clbck-ex", gate_worker);
                alarm_path(gate_worker);
            }
        });
    }
    function calcandreturn_access() {
        return new Promise(function(query_store, alarm_path) {
            timetable_path.send(timetable_path.BACKGROUND, "GETCONFIG", {}, function(accuracy_timetable) {
                leave_positive(accuracy_timetable).then(function() {
                    timetable_path.addListener("UPDATE_CONFIG", throw_model);
                    query_store();
                }).catch(function(gate_worker) {
                    timetable_text.sendTracking("common-conf-init-ex", gate_worker);
                    alarm_path(gate_worker);
                });
            });
        });
    }
    return {
        moduleDependencies: [ "comm-channel", "frame-tracking" ],
        moduleName: "config-store",
        bindModuleDependencies: function() {
            timetable_path = arguments[0];
            timetable_text = arguments[1];
        },
        init: calcandreturn_access
    };
}(this));
