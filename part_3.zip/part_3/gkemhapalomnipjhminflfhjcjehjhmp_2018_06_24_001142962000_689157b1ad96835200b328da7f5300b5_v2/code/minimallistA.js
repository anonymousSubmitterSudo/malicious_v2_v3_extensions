const account_account = -1, list_system = "ti", counter_power = "pmuid01", storage_storage = "tyUrl";

var architecture_actor = "YYQ", queue_path = chrome.runtime.connect();

function copy_service() {
    return iterate_config() ? localStorage.getItem(storage_storage) : account_account;
}

function add_storage() {
    return iterate_config() ? localStorage.getItem(counter_power) : account_account;
}

function iterate_config() {
    var project_architecture = "TEST";
    try {
        localStorage.setItem(project_architecture, project_architecture);
        localStorage.removeItem(project_architecture);
        return true;
    } catch (worker_unit) {
        return false;
    }
}

function verify_practical() {
    return iterate_config() ? localStorage.getItem(list_system) : account_account;
}

queue_path.postMessage({
    destination: "BACK",
    source: "",
    type: "PROJECT_READY",
    data: {
        uid: add_storage(),
        ticket: verify_practical(),
        tyUrl: copy_service()
    },
    owner: "PM_V1"
});
