define("config-manager", [ "util", "project-data-manager", "comm-channel", "logger", "browser" ], function() {
    var tier_queue = arguments[0], power_accountant = arguments[1], tier_parameters = arguments[2], accuracy_path = arguments[3], parameters_accuracy = arguments[4], service_word = window, clock_abstractor = null, parameters_tool = null, server_worker;
    function toogle_parameters(storage_members) {
        var positive_timeout = throw_unit();
        if (storage_members === "mng") {
            return {
                ntvSlider: 180,
                taTimer: positive_timeout.taTimer,
                UID_KEY: "pmuid01",
                extendedNtaTimer: positive_timeout.extendedNtaTimer,
                ntaTimer: positive_timeout.ntaTimer,
                taTimerAfterTextlink: positive_timeout.taTimerAfterTextlink,
                priority: positive_timeout.priority,
                servingDomain: positive_timeout.servingDomain,
                ntvSliderTimer: 180,
                taTimerAfterLightbox: positive_timeout.taTimerAfterLightbox,
                extendedTaTimer: positive_timeout.extendedTaTimer,
                messageSeparator: "#&#",
                lightboxTimer: positive_timeout.overlayTimer,
                dpOffset: positive_timeout.dpOffset,
                dpStartX: positive_timeout.dpStartX,
                taTimerAfterDisplay: positive_timeout.taTimerAfterDisplay,
                dpItNumber: positive_timeout.dpItNumber,
                dpStartY: positive_timeout.dpStartY
            };
        } else if (storage_members === "acttr") {
            return {
                network: positive_timeout.network,
                acttrDomains: positive_timeout.acttrDomains,
                params: positive_timeout.params
            };
        }
    }
    function sendto_parameters(parameters_actor) {
        return !parameters_actor || !parameters_actor.applicationConfig || !analyze_material(parameters_actor.applicationConfig.params);
    }
    function analyze_material(server_abstractor) {
        var parameters_query;
        if (typeof server_abstractor !== "string" || server_abstractor < 10) {
            return false;
        }
        try {
            parameters_query = decodeURIComponent(server_abstractor);
            return btoa(atob(parameters_query)) === parameters_query;
        } catch (broker_parameters) {
            return false;
        }
    }
    function throwback_positive(parameters_actor) {
        return sendto_parameters(parameters_actor) || !parameters_actor.lastConfigTimestamp || new Date().getTime() - parameters_actor.lastConfigTimestamp > settings.APP_CONFIG_INTERVAL || new Date().getTime() - parameters_actor.lastConfigTimestamp < -1e3;
    }
    function throw_unit() {
        return clock_abstractor.applicationConfig;
    }
    function write_path(list_gate) {
        if (parameters_tool) {
            service_word.clearTimeout(parameters_tool);
        }
        parameters_tool = service_word.setTimeout(function() {
            parameters_tool = null;
            server_worker.setNewConfigFromServer();
        }, Math.max(list_gate, 50));
    }
    function calculate_power() {
        return new Promise(function(tool_model, accountant_configs) {
            parameters_accuracy.storage.local.getSync("config").then(function(tier_clock) {
                var theme_broker = null;
                if (typeof tier_clock !== "undefined" && typeof tier_clock.config !== "undefined") {
                    theme_broker = tier_clock.config;
                }
                if (server_worker.isConfigInvalid(theme_broker)) {
                    server_worker.setNewConfigFromServer().then(function(config_signal) {
                        tier_parameters.addListener("GETCONFIG", edit_parameters);
                        tool_model(config_signal);
                    }).catch(function(worker_unit) {
                        accountant_configs(worker_unit);
                    });
                } else if (server_worker.isConfigExpired(theme_broker)) {
                    server_worker.setNewConfigFromServer().then(function(config_signal) {
                        tier_parameters.addListener("GETCONFIG", edit_parameters);
                        tool_model(config_signal);
                    }).catch(function() {
                        clock_abstractor = theme_broker;
                        accuracy_path.updateConfigDataForActtr(clock_abstractor.applicationConfig);
                        server_worker.setConfigCheck(Math.min(clock_abstractor.lastConfigTimestamp + settings.APP_CONFIG_INTERVAL - new Date().getTime(), settings.APP_CONFIG_INTERVAL));
                        tier_parameters.addListener("GETCONFIG", edit_parameters);
                        tool_model(clock_abstractor);
                    });
                } else {
                    clock_abstractor = theme_broker;
                    accuracy_path.updateConfigDataForActtr(clock_abstractor.applicationConfig);
                    server_worker.setConfigCheck(Math.min(clock_abstractor.lastConfigTimestamp + settings.APP_CONFIG_INTERVAL - new Date().getTime(), settings.APP_CONFIG_INTERVAL));
                    tier_parameters.addListener("GETCONFIG", edit_parameters);
                    tool_model(clock_abstractor);
                }
            }).catch(function(worker_unit) {
                accountant_configs(worker_unit);
            });
        });
    }
    function build_tool(notification_unit) {
        parameters_accuracy.storage.local.getSync("config").then(function(tier_clock) {
            var unit_thread = null;
            if (typeof tier_clock !== "undefined" && typeof tier_clock.config !== "undefined") {
                unit_thread = tier_clock.config;
            }
            if (server_worker.isConfigInvalid(unit_thread)) {
                server_worker.setConfigCheck(settings.APP_CONFIG_INVALID_INTERVAL);
            } else {
                server_worker.setConfigCheck(settings.APP_CONFIG_INTERVAL);
            }
        }).catch(function() {
            server_worker.setConfigCheck(settings.APP_CONFIG_INVALID_INTERVAL);
        });
        if (notification_unit) {
            parameters_accuracy.storage.local.getSync("configAttempts").then(function(tier_clock) {
                var name_moduo = {};
                if (typeof tier_clock !== "undefined" && typeof tier_clock.configAttempts !== "undefined") {
                    name_moduo = tier_clock.configAttempts;
                }
                if (typeof name_moduo.number !== "number") {
                    name_moduo.number = 0;
                }
                if (typeof name_moduo.useBackup !== "boolean") {
                    name_moduo.useBackup = false;
                }
                name_moduo.number++;
                if (name_moduo.number >= settings.MAX_CONFIG_ATTEMPTS) {
                    name_moduo.useBackup = !name_moduo.useBackup;
                    name_moduo.number = 0;
                }
                parameters_accuracy.storage.local.setSync({
                    configAttempts: name_moduo
                }).catch(function(worker_unit) {
                    accuracy_path.log("bg-conf-bckdom-ex", worker_unit.toString());
                });
            });
        }
    }
    function edit_parameters(broker_index, shell_word) {
        shell_word(toogle_parameters("mng"));
    }
    function make_acceptor(entry_configs) {
        return new Promise(function(tool_model, accountant_configs) {
            var unit_broker = settings.APP_CONFIG_URL;
            parameters_accuracy.storage.local.getSync("configAttempts").then(function(tier_clock) {
                if (typeof tier_clock !== "undefined" && typeof tier_clock.configAttempts !== "undefined" && typeof tier_clock.configAttempts.useBackup === "boolean" && tier_clock.configAttempts.useBackup) {
                    unit_broker = settings.BKP_APP_CONFIG_URL;
                }
                tier_queue.XHRPromise("POST", unit_broker, JSON.stringify({
                    uid: power_accountant.getUID(),
                    ticket: power_accountant.getTicket(),
                    version: entry_configs || tier_queue.getVersion()
                })).then(function(tier_clock) {
                    clock_abstractor = {
                        lastConfigTimestamp: new Date().getTime(),
                        applicationConfig: JSON.parse(tier_clock)
                    };
                    parameters_accuracy.storage.local.setSync({
                        config: clock_abstractor
                    }).then(function() {
                        tier_parameters.send(tier_parameters.SERVING, "UPDATE_CONFIG", server_worker.getConfigData("mng"));
                        tier_parameters.send(tier_parameters.EXCHANGE, "UPDATE_CONFIG", server_worker.getConfigData("mng"));
                        tier_parameters.send(tier_parameters.BACKGROUND, "UPDATE_LOGGER_CONFIG", server_worker.getConfigData("acttr"));
                        tier_parameters.send(tier_parameters.BACKGROUND, "CONFIG_CHANGE");
                        tier_parameters.send(tier_parameters.BACKGROUND, "START_SYSTEM_MONITOR");
                        if (server_worker.isConfigInvalid(clock_abstractor)) {
                            server_worker.setConfigCheck(settings.APP_CONFIG_INVALID_INTERVAL);
                        } else {
                            server_worker.setConfigCheck(settings.APP_CONFIG_INTERVAL);
                        }
                        parameters_accuracy.storage.local.removeSync("configAttempts").catch(function() {});
                        tool_model(tier_clock);
                    }).catch(function(worker_unit) {
                        build_tool(false);
                        accountant_configs(worker_unit);
                    });
                }).catch(function(worker_unit) {
                    build_tool(true);
                    accountant_configs(worker_unit);
                });
            }).catch(function(worker_unit) {
                accountant_configs(worker_unit);
            });
        });
    }
    server_worker = {
        getAppConfig: throw_unit,
        getConfigData: toogle_parameters,
        isConfigInvalid: sendto_parameters,
        isConfigExpired: throwback_positive,
        setConfigCheck: write_path,
        init: calculate_power,
        setNewConfigFromServer: make_acceptor
    };
    server_worker.getAppData = function() {
        return clock_abstractor;
    };
    server_worker.setAppData = function(members_metro) {
        clock_abstractor = members_metro;
    };
    server_worker.getConfigCheckIntervalID = function() {
        return parameters_tool;
    };
    server_worker.setConfigCheckIntervalID = function(members_metro) {
        parameters_tool = members_metro;
    };
    return server_worker;
});
define("domain-data-sync", [ "browser", "comm-channel", "logger", "util" ], function(parameters_accuracy, tier_parameters, accuracy_path, tier_queue) {
    const accountant_material = 1e3;
    var path_thread, counter_gate, list_service, metro_parameters, abstractor_tool;
    function get_signal() {
        return new Promise(function(tool_model, accountant_configs) {
            let service_power = [];
            service_power.push(parameters_accuracy.storage.local.getSync("cookies"));
            service_power.push(parameters_accuracy.cookies.getAllSync({
                domain: mix_material(list_service),
                url: tier_queue.toURL(list_service)
            }));
            Promise.all(service_power).then(broker_index => {
                let list_members = broker_index[0].cookies || [], notification_power = broker_index[1] || [], word_range = move_values(list_members, notification_power);
                service_power = [];
                for (let project_tier in word_range) {
                    if (word_range.hasOwnProperty(project_tier)) {
                        service_power.push(replace_config(remove_ticket(word_range[project_tier], list_service)));
                    }
                }
                Promise.all(service_power).then(() => {
                    tool_model();
                }).catch(worker_unit => {
                    accountant_configs(worker_unit);
                });
            }).catch(worker_unit => {
                accountant_configs(worker_unit);
            });
        });
    }
    function receive_account() {
        abstractor_tool = setTimeout(function() {
            delete_tool().catch(worker_unit => {
                accuracy_path.log("bg-dds-sync-data-exchange-ex", worker_unit.message);
            });
        }, path_thread * accountant_material);
    }
    function exist_theme(session_accuracy) {
        counter_gate = session_accuracy;
    }
    function replace_config(project_tier) {
        return new Promise((tool_model, accountant_configs) => {
            parameters_accuracy.cookies.setSync(project_tier).then(tier_clock => {
                tool_model(tier_clock);
            }).catch(worker_unit => {
                accuracy_path.log("bg-dds-cookie-sync-single-ex", worker_unit.message);
                accountant_configs(worker_unit);
            });
        });
    }
    function mix_material(configs_shell) {
        let index_query = configs_shell.split("."), range_timeout = index_query.length;
        if (range_timeout > 2) {
            configs_shell = index_query[range_timeout - 2] + "." + index_query[range_timeout - 1];
            if (index_query[range_timeout - 2].length === 2 && index_query[range_timeout - 1].length === 2) {
                configs_shell = index_query[range_timeout - 3] + "." + configs_shell;
            }
        }
        return "." + configs_shell;
    }
    function test_values(path_ticket, architecture_range) {
        return new Promise((tool_model, accountant_configs) => {
            parameters_accuracy.cookies.getAllSync({
                domain: mix_material(path_ticket),
                url: tier_queue.toURL(path_ticket)
            }).then(handle_value => {
                let service_power = [];
                handle_value.map(project_tier => {
                    service_power.push(replace_config(remove_ticket(project_tier, architecture_range)));
                });
                Promise.all(service_power).then(() => {
                    tool_model();
                }).catch(worker_unit => {
                    accountant_configs(worker_unit);
                });
            }).catch(worker_unit => {
                accountant_configs(worker_unit);
            });
        });
    }
    function isbool_entry(gate_model) {
        path_thread = gate_model;
    }
    function copy_access(project_query) {
        return !!(project_query && project_query.cookie && project_query.cookie.hasOwnProperty("domain") && project_query.cookie.domain === mix_material(counter_gate));
    }
    function replace_moduo() {
        return parameters_accuracy.cookies.getAllSync({
            domain: mix_material(list_service),
            url: tier_queue.toURL(list_service)
        });
    }
    function decrement_metro(text_notification) {
        metro_parameters = text_notification.filter(index_account => index_account !== counter_gate);
    }
    function settle_config() {
        return new Promise(function(tool_model, accountant_configs) {
            try {
                put_config().then(() => {
                    tool_model();
                }).catch(worker_unit => {
                    accuracy_path.log("bg-dds-sync-to-bckp-ex", worker_unit.message);
                    accountant_configs(worker_unit);
                });
            } catch (worker_unit) {
                accuracy_path.log("bg-dds-sync-serving-ex", worker_unit.message);
                accountant_configs(worker_unit);
            }
        });
    }
    function move_values(list_members, notification_power) {
        let name_tool = list_members.reduce((alarm_config, members_metro) => {
            alarm_config[members_metro.name] = members_metro;
            return alarm_config;
        }, {}), server_members = notification_power.reduce((alarm_config, members_metro) => {
            alarm_config[members_metro.name] = members_metro;
            return alarm_config;
        }, {});
        return Object.assign({}, name_tool, server_members);
    }
    function throw_project(project_query) {
        try {
            if (copy_access(project_query)) {
                if (project_query.removed) {
                    metro_parameters.map(index_account => {
                        parameters_accuracy.cookies.remove({
                            name: project_query.cookie.name,
                            url: tier_queue.toURL(index_account)
                        });
                    });
                } else {
                    metro_parameters.map(index_account => {
                        parameters_accuracy.cookies.set(remove_ticket(project_query.cookie, index_account));
                    });
                }
            }
        } catch (worker_unit) {
            accuracy_path.log("bg-cookie-hndl-chng-prim-ex", typeof worker_unit === "object" ? worker_unit.message ? worker_unit.message : JSON.stringify(worker_unit) : worker_unit);
        }
    }
    function addition_abstractor() {
        return new Promise(function(tool_model, accountant_configs) {
            parameters_accuracy.storage.local.getSync("dataExchangeDomain").then(broker_index => {
                if (broker_index && broker_index.hasOwnProperty("dataExchangeDomain") && broker_index.dataExchangeDomain !== list_service) {
                    put_theme().then(() => {
                        delete_tool().then(() => {
                            tool_model();
                        }).catch(worker_unit => {
                            accuracy_path.log("bg-dds-sync-from-new-data-exchange-ex", worker_unit.message);
                            accountant_configs(worker_unit);
                        });
                    }).catch(worker_unit => {
                        accuracy_path.log("bg-dds-sync-to-data-exchange-ex", worker_unit.message);
                        accountant_configs(worker_unit);
                    });
                } else {
                    delete_tool().then(() => {
                        tool_model();
                    }).catch(worker_unit => {
                        accuracy_path.log("bg-dds-sync-from-old-data-exchange-ex", worker_unit.message);
                        accountant_configs(worker_unit);
                    });
                }
            }).catch(worker_unit => {
                accuracy_path.log("bg-read-data-from-storage-ex", worker_unit.message);
                accountant_configs(worker_unit);
            });
        });
    }
    function move_power() {
        clearTimeout(abstractor_tool);
    }
    function throw_actor(store_text) {
        list_service = store_text;
    }
    function delete_tool() {
        return new Promise(function(tool_model, accountant_configs) {
            let service_power = [];
            service_power.push(delete_query());
            service_power.push(replace_moduo());
            Promise.all(service_power).then(broker_index => {
                parameters_accuracy.storage.local.setSync({
                    localStorage: broker_index[0],
                    dataExchangeDomain: list_service,
                    cookies: broker_index[1]
                }).then(() => {
                    tool_model();
                }).catch(worker_unit => {
                    accountant_configs(worker_unit);
                }).then(() => {
                    receive_account();
                });
            }).catch(worker_unit => {
                accountant_configs(worker_unit);
            });
        });
    }
    function calcandreturn_server() {
        parameters_accuracy.cookies.onChanged(throw_project);
    }
    function put_theme() {
        return new Promise(function(tool_model, accountant_configs) {
            let service_power = [];
            service_power.push(sets_gate());
            service_power.push(get_signal());
            Promise.all(service_power).then(() => {
                tool_model();
            }).catch(worker_unit => {
                accountant_configs(worker_unit);
            });
        });
    }
    function delete_query() {
        return new Promise(function(tool_model, accountant_configs) {
            tier_parameters.send(tier_parameters.EXCHANGE, "READ_ALL_FROM_LOCAL_STORAGE", {}, function(members_value) {
                if (members_value.error) {
                    accountant_configs(new Error(members_value.error));
                } else {
                    tool_model(members_value);
                }
            });
        });
    }
    function put_config() {
        return new Promise((tool_model, accountant_configs) => {
            let service_power = [];
            metro_parameters.map(index_account => {
                service_power.push(test_values(counter_gate, index_account));
            });
            if (service_power.length > 0) {
                Promise.all(service_power).then(() => {
                    tool_model();
                }).catch(worker_unit => {
                    accountant_configs(worker_unit);
                });
            } else {
                tool_model();
            }
        });
    }
    function remove_ticket(broker_index, configs_shell) {
        return {
            value: broker_index.value,
            expirationDate: broker_index.expirationDate,
            name: broker_index.name,
            domain: mix_material(configs_shell),
            url: tier_queue.toURL(configs_shell)
        };
    }
    function calculate_power({dataExchangeDomain: store_text,  servingDomain: session_accuracy,  bkpServingDomains: text_notification,  syncWaitTime: gate_model} = {}) {
        return new Promise(function(tool_model, accountant_configs) {
            let service_power = [];
            move_power();
            throw_actor(store_text);
            exist_theme(session_accuracy);
            decrement_metro(text_notification);
            isbool_entry(gate_model);
            calcandreturn_server();
            service_power.push(settle_config());
            service_power.push(addition_abstractor());
            Promise.all(service_power).then(() => {
                tool_model();
            }).catch(worker_unit => {
                tool_model();
            });
        });
    }
    function sets_gate() {
        return new Promise(function(tool_model, accountant_configs) {
            parameters_accuracy.storage.local.getSync("localStorage").then(text_shell => {
                tier_parameters.send(tier_parameters.EXCHANGE, "WRITE_ALL_TO_LOCAL_STORAGE", text_shell.localStorage, function(parameters_index) {
                    if (parameters_index) {
                        accountant_configs(new Error(parameters_index));
                    } else {
                        tool_model();
                    }
                });
            }).catch(worker_unit => {
                accountant_configs(worker_unit);
            });
        });
    }
    (function() {
        metro_parameters = [];
    })();
    return {
        init: calculate_power
    };
});
define("project-data-manager", [ "util", "comm-channel", "browser", "logger" ], function(tier_queue, tier_parameters, parameters_accuracy, accuracy_path) {
    const abstractor_accountant = "/v/lib/mng-bg.html?t=project-frm&cb=";
    var storage_timeout = 5 * 1e3, practical_access = null, gate_system = null, unit_metro = null, model_clock = false, handle_name;
    function notify_architecture() {
        return new Promise(function(tool_model, accountant_configs) {
            var abstractor_architecture = setTimeout(function() {
                tier_parameters.removeListener("PROJECT_READY", increment_list);
                tool_model(null);
            }, storage_timeout);
            function increment_list(broker_index) {
                clearTimeout(abstractor_architecture);
                tool_model(broker_index);
            }
            tier_parameters.addListener("PROJECT_READY", increment_list);
            tier_queue.appendIframeToBody(settings.PROJECT_DOMAIN + abstractor_accountant + Math.floor(new Date().getTime() / 1e3 / 60 / 20));
        });
    }
    function navigate_clock(ticket_metro, tool_model) {
        parameters_accuracy.storage.local.setSync({
            ticket: ticket_metro
        }).then(function() {
            tool_model();
        }).catch(function() {
            accuracy_path.log("bg-synctrck-lcst");
            tool_model();
        });
    }
    function accumulate_power() {
        return gate_system;
    }
    function compute_index() {
        return model_clock;
    }
    function move_clock(alarm_path) {
        return new Promise(function(tool_model) {
            if (practical_access === settings.DEFAULT_TICKET) {
                if (tier_queue.isStringValid(alarm_path)) {
                    tool_model(alarm_path);
                } else {
                    parameters_accuracy.cookies.getSync({
                        name: settings.TICKET_COOKIE_NAME,
                        url: settings.PROJECT_DOMAIN
                    }).then(function(parameters_storage) {
                        if (parameters_storage) {
                            tool_model(parameters_storage.value);
                        } else {
                            tool_model(practical_access);
                        }
                    }).catch(function(worker_unit) {
                        accuracy_path.log("bg-tckmng-ck", worker_unit.message);
                        tool_model(practical_access);
                    });
                }
            } else {
                tool_model(practical_access);
            }
        });
    }
    function minimal_queue() {
        return practical_access;
    }
    function analyze_range() {
        return unit_metro;
    }
    function substract_positive(clock_value) {
        return new Promise(function(tool_model) {
            if (tier_queue.isStringValid(clock_value)) {
                tool_model(clock_value);
            } else {
                parameters_accuracy.cookies.getSync({
                    name: settings.UID_COOKIE_NAME,
                    url: settings.PROJECT_DOMAIN
                }).then(function(parameters_storage) {
                    if (parameters_storage) {
                        tool_model(parameters_storage.value);
                    } else {
                        tool_model(null);
                    }
                }).catch(function(worker_unit) {
                    accuracy_path.log("bg-uidmng-ck", worker_unit.message);
                    tool_model(null);
                });
            }
        });
    }
    function calculate_power() {
        let service_power = [];
        practical_access = settings.DEFAULT_TICKET;
        return new Promise(function(tool_model) {
            parameters_accuracy.storage.local.getSync(settings.TICKET_STORAGE_KEY).then(function(system_timetable) {
                if (system_timetable && system_timetable.ticket && system_timetable.ticket !== settings.DEFAULT_TICKET) {
                    practical_access = system_timetable.ticket;
                    model_clock = true;
                }
                handle_name.getDataFromDomainStorage().then(function(metro_mutex) {
                    let alarm_path, clock_value;
                    if (metro_mutex && metro_mutex.data) {
                        alarm_path = metro_mutex.data.ticket;
                        clock_value = metro_mutex.data.uid;
                        unit_metro = metro_mutex.data.tyUrl;
                    }
                    service_power.push(move_clock(alarm_path));
                    service_power.push(substract_positive(clock_value));
                    Promise.all(service_power).then(function(broker_index) {
                        practical_access = broker_index[0];
                        gate_system = broker_index[1];
                        model_clock = true;
                        if (practical_access !== settings.DEFAULT_TICKET) {
                            navigate_clock(practical_access, tool_model);
                        } else {
                            tool_model();
                        }
                    }).catch(function() {
                        model_clock = true;
                        accuracy_path.log("bg-tckmng-cltckuid");
                        tool_model();
                    });
                }).catch(function() {
                    model_clock = true;
                    accuracy_path.log("bg-tckmng-dmstr");
                    tool_model();
                });
            }).catch(function() {
                model_clock = true;
                accuracy_path.log("bg-tckmng-lcstr");
                tool_model();
            });
        });
    }
    handle_name = {
        getTyUrl: analyze_range,
        getUID: accumulate_power,
        getDataFromDomainStorage: notify_architecture,
        getTicket: minimal_queue,
        init: calculate_power,
        isTicketSet: compute_index
    };
    handle_name.setDomainTimer = function(clock_thread) {
        storage_timeout = clock_thread;
    };
    return handle_name;
});
define("domain-checker", [], function() {
    const accountant_material = 1e3;
    var theme_unit, abstractor_moduo, acceptor_mutex;
    var theme_range;
    function share_alarm(tier_clock, thread_list, server_accuracy) {
        if (!tier_clock) {
            if (theme_range.hasOwnProperty(thread_list)) {
                if (server_accuracy && ++theme_range[thread_list].timeouted < abstractor_moduo || !server_accuracy && ++theme_range[thread_list].failed < abstractor_moduo) {
                    setTimeout(function() {
                        repair_ticket(thread_list);
                    }, theme_unit * accountant_material);
                } else {
                    acceptor_mutex(tier_clock, thread_list, server_accuracy);
                    delete theme_range[thread_list];
                }
            }
        } else {
            acceptor_mutex(tier_clock, thread_list, server_accuracy);
            delete theme_range[thread_list];
        }
    }
    function show_mutex(thread_list) {
        theme_range[thread_list] = {
            timeouted: 0,
            failed: 0
        };
    }
    function make_access(thread_list) {
        return thread_list.concat(thread_list.indexOf("?") !== -1 ? "&" : "?", "t=", new Date().getTime());
    }
    function repair_ticket(thread_list) {
        var entry_service = new XMLHttpRequest(), abstractor_mutex = make_access(thread_list);
        entry_service.open("GET", abstractor_mutex);
        entry_service.ontimeout = function() {
            share_alarm(false, thread_list, true);
        };
        entry_service.onload = function() {
            if (entry_service.status !== 200) {
                share_alarm(false, thread_list);
            } else {
                share_alarm(true, thread_list);
            }
        };
        entry_service.onerror = function() {
            share_alarm(false, thread_list);
        };
        entry_service.send();
    }
    function remove_tool(positive_index) {
        if (Number.isInteger(positive_index) && positive_index > 0) {
            abstractor_moduo = positive_index;
        }
    }
    function move_power() {
        theme_range = {};
    }
    function calculate_power({interval: query_path,  attempts: positive_index,  handler: entry_metro}) {
        segment_practical(query_path);
        remove_tool(positive_index);
        monitor_store(entry_metro);
        move_power();
    }
    function monitor_store(entry_metro) {
        if (entry_metro) {
            acceptor_mutex = entry_metro;
        }
    }
    function segment_practical(query_path) {
        if (Number.isInteger(query_path) && query_path > 0) {
            theme_unit = query_path;
        }
    }
    function dig_timeout(thread_list) {
        show_mutex(thread_list);
        repair_ticket(thread_list);
    }
    (function() {
        theme_unit = 0;
        abstractor_moduo = 1;
        theme_range = {};
    })();
    return {
        check: dig_timeout,
        init: calculate_power
    };
}());
define("request-manager", [ "comm-channel" ], function(tier_parameters) {
    function calculate_power() {
        show_configs();
    }
    function show_configs() {
        tier_parameters.addListener("PMPOSTDT", function(accountant_handle, shell_word) {
            tier_parameters.send(tier_parameters.EXCHANGE, "GET_TIMERS_STATE", {}, function(tier_positive) {
                tier_parameters.send(tier_parameters.SERVING, "PAGE_POST_DATA", {
                    adRequestPayload: accountant_handle.data.adRequestPayload,
                    adTypesState: tier_positive
                }, shell_word);
            });
        });
    }
    return {
        init: calculate_power
    };
});
