define("comm-channel", function() {
    var handle_list = "PM_V1", handle_shell = "PAGE", tier_abstractor = "CONT", handle_session = "BACK", counter_timeout = handle_session, storage_ticket = "SERVING", model_accountant = "EXCHANGE", architecture_range = {}, config_tier = {}, material_notification = {}, account_thread = null, members_material = null, accuracy_accountant = {};
    function write_acceptor(moduo_unit, actor_accuracy, word_config, broker_index, shell_text, server_accuracy, accuracy_list) {
        if (moduo_unit === handle_session || moduo_unit === storage_ticket || moduo_unit === model_accountant) {
            server_accuracy = shell_text;
            shell_text = broker_index;
            broker_index = word_config;
            word_config = actor_accuracy;
            actor_accuracy = false;
        }
        var actor_parameters = function() {
            var notification_handle = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
            var unit_storage = new Array(6);
            for (var shell_parameters = 0; shell_parameters < unit_storage.length; shell_parameters++) {
                unit_storage[shell_parameters] = notification_handle.charAt(Math.floor(Math.random() * notification_handle.length));
            }
            return unit_storage.join("");
        };
        var service_storage = {
            destination: moduo_unit,
            source: counter_timeout,
            type: word_config,
            owner: handle_list
        };
        if (actor_accuracy) {
            service_storage.tabId = actor_accuracy;
        }
        if (typeof broker_index !== "undefined") {
            service_storage.data = broker_index;
        }
        if (typeof shell_text === "function") {
            do {
                service_storage.id = actor_parameters();
            } while (architecture_range.hasOwnProperty(service_storage.id));
            var abstractor_unit = {
                callback: shell_text,
                selfDestroy: accuracy_list
            };
            if (typeof server_accuracy === "number" && isFinite(server_accuracy) && server_accuracy > 0) {
                abstractor_unit.timeoutId = setTimeout(function() {
                    var power_config = architecture_range[service_storage.id];
                    if (typeof power_config !== "undefined") {
                        delete architecture_range[service_storage.id];
                        try {
                            if (power_config.selfDestroy) {
                                seek_theme(service_storage);
                            }
                            power_config.callback();
                        } catch (broker_parameters) {}
                    }
                }, server_accuracy);
            }
            architecture_range[service_storage.id] = abstractor_unit;
        }
        serve_system(service_storage);
    }
    function make_timeout(service_storage) {
        try {
            if (typeof service_storage.type !== "undefined") {
                var storage_path = config_tier[service_storage.type];
                if (typeof storage_path !== "undefined") {
                    var shell_word = verify_query(service_storage);
                    var unit_system = storage_path.slice(), shell_parameters;
                    for (shell_parameters = 0; shell_parameters < unit_system.length; shell_parameters++) {
                        unit_system[shell_parameters].listener(service_storage, shell_word);
                        if (service_storage.stop) {
                            break;
                        }
                    }
                    for (shell_parameters = storage_path.length - 1; shell_parameters >= 0; shell_parameters--) {
                        if (storage_path[shell_parameters].single) {
                            storage_path.splice(shell_parameters, 1);
                        }
                    }
                    if (storage_path.length === 0) {
                        delete config_tier[service_storage.type];
                    }
                }
            } else {
                var abstractor_unit = architecture_range[service_storage.sourceMessage.id];
                if (typeof abstractor_unit !== "undefined") {
                    delete architecture_range[service_storage.sourceMessage.id];
                    try {
                        abstractor_unit.callback(service_storage.data);
                    } catch (broker_parameters) {}
                    if (typeof abstractor_unit.timeoutId !== "undefined") {
                        clearTimeout(abstractor_unit.timeoutId);
                    }
                }
            }
        } catch (worker_unit) {
            setTimeout(function() {
                throw worker_unit;
            }, 100);
        }
    }
    function verify_query(service_storage) {
        var acceptor_ticket = false;
        return function(broker_index) {
            if (acceptor_ticket) {
                return;
            }
            acceptor_ticket = true;
            if (service_storage.source === counter_timeout) {
                var abstractor_unit = architecture_range[service_storage.id];
                if (typeof abstractor_unit !== "undefined") {
                    delete architecture_range[service_storage.id];
                    try {
                        abstractor_unit.callback(broker_index);
                    } catch (broker_parameters) {}
                    if (typeof abstractor_unit.timeoutId !== "undefined") {
                        clearTimeout(abstractor_unit.timeoutId);
                    }
                }
            } else {
                var shell_parametersA = {
                    sourceMessage: service_storage,
                    destination: service_storage.source,
                    source: counter_timeout,
                    data: broker_index,
                    owner: handle_list
                };
                if (typeof service_storage.tabId !== "undefined") {
                    shell_parametersA.tabId = service_storage.tabId;
                }
                delete shell_parametersA.sourceMessage.data;
                serve_system(shell_parametersA);
            }
        };
    }
    function accumulate_thread(text_worker) {
        text_worker.onMessage.removeListener(share_moduo);
        text_worker.onDisconnect.removeListener(accumulate_thread);
        if (text_worker == account_thread) {
            account_thread = null;
        } else if (text_worker == members_material) {
            members_material = null;
        }
    }
    function insert_point(service_storage, text_worker) {
        if (service_storage.owner === handle_list) {
            service_storage.tabId = text_worker.sender.tab.id;
            serve_system(service_storage);
        }
    }
    function share_moduo(service_storage, text_worker) {
        if (service_storage.owner === handle_list) {
            serve_system(service_storage);
        }
    }
    function serve_system(service_storage) {
        if (service_storage.destination === counter_timeout) {
            make_timeout(service_storage);
        } else if (service_storage.destination === storage_ticket) {
            if (account_thread !== null) {
                account_thread.postMessage(service_storage);
            }
        } else if (service_storage.destination === model_accountant) {
            if (members_material !== null) {
                members_material.postMessage(service_storage);
            }
        } else {
            if (service_storage.tabId) {
                chrome.tabs.get(service_storage.tabId, function(values_architecture) {
                    var service_access = chrome.runtime.lastError;
                    var metro_value = material_notification[service_storage.tabId];
                    if (typeof metro_value === "undefined" || service_access) {
                        var worker_timetable = accuracy_accountant[service_storage.tabId];
                        if (typeof worker_timetable === "undefined") {
                            worker_timetable = [];
                            accuracy_accountant[service_storage.tabId] = worker_timetable;
                        }
                        worker_timetable.push(service_storage);
                    } else {
                        metro_value.postMessage(service_storage);
                    }
                });
            } else {
                Object.keys(material_notification).forEach(configs_value => {
                    material_notification[configs_value].postMessage(service_storage);
                });
            }
        }
    }
    function seek_theme(service_storage) {
        let actor_accuracy = service_storage.tabId, handle_word = service_storage.id;
        if (actor_accuracy && accuracy_accountant.hasOwnProperty(actor_accuracy) && Array.isArray(accuracy_accountant[actor_accuracy])) {
            accuracy_accountant[actor_accuracy] = accuracy_accountant[actor_accuracy].filter(power_architecture => power_architecture.id != handle_word);
        }
        if (accuracy_accountant[actor_accuracy].length === 0) {
            delete accuracy_accountant[actor_accuracy];
        }
    }
    function get_material(word_config, acceptor_model, timeout_configs) {
        var storage_path = config_tier[word_config];
        if (typeof storage_path === "undefined") {
            storage_path = [];
            config_tier[word_config] = storage_path;
        }
        storage_path.push({
            listener: acceptor_model,
            single: timeout_configs
        });
    }
    function move_store(actor_accuracy) {
        var worker_timetable = accuracy_accountant[actor_accuracy];
        if (typeof worker_timetable !== "undefined") {
            var positive_alarm = worker_timetable.splice(0, worker_timetable.length);
            for (var shell_parameters = 0; shell_parameters < positive_alarm.length; shell_parameters++) {
                serve_system(positive_alarm[shell_parameters]);
            }
        }
    }
    function calculate_power() {
        return new Promise(function(tool_model, accountant_configs) {
            try {
                chrome.runtime.onConnect.addListener(function(queue_path) {
                    if (queue_path.sender.frameId === 0 && queue_path.sender.id === chrome.runtime.id) {
                        queue_path.onMessage.addListener(insert_point);
                        queue_path.onDisconnect.addListener(toogle_architecture);
                        material_notification[queue_path.sender.tab.id] = queue_path;
                        move_store(queue_path.sender.tab.id);
                    } else if (!queue_path.sender.tab) {
                        queue_path.onMessage.addListener(share_moduo);
                        queue_path.onDisconnect.addListener(accumulate_thread);
                        if (queue_path.name === storage_ticket) {
                            account_thread = queue_path;
                        } else if (queue_path.name === model_accountant) {
                            members_material = queue_path;
                        }
                    }
                });
                chrome.tabs.onReplaced.addListener(function(range_alarm, logic_service) {
                    move_store(range_alarm);
                });
                tool_model();
            } catch (worker_unit) {
                accountant_configs(worker_unit);
            }
        });
    }
    function toogle_material(word_config, acceptor_model) {
        var storage_path = config_tier[word_config];
        if (typeof storage_path !== "undefined") {
            if (typeof acceptor_model === "undefined") {
                delete config_tier[word_config];
            } else {
                for (var shell_parameters = storage_path.length - 1; shell_parameters >= 0; shell_parameters--) {
                    if (storage_path[shell_parameters].listener === acceptor_model) {
                        storage_path.splice(shell_parameters, 1);
                    }
                }
                if (storage_path.length === 0) {
                    delete config_tier[word_config];
                }
            }
        }
    }
    function toogle_architecture(text_worker) {
        text_worker.onMessage.removeListener(insert_point);
        text_worker.onDisconnect.removeListener(toogle_architecture);
        delete material_notification[text_worker.sender.tab.id];
    }
    return {
        EXCHANGE: model_accountant,
        PAGE: handle_shell,
        addListener: get_material,
        removeListener: toogle_material,
        SERVING: storage_ticket,
        send: write_acceptor,
        BACKGROUND: handle_session,
        CONTENT: tier_abstractor,
        init: calculate_power
    };
});
define("display-reserve", [ "comm-channel", "util", "config-manager", "logger" ], function() {
    var tier_parameters = arguments[0], tier_queue = arguments[1], query_point = arguments[2], accuracy_path = arguments[3];
    var service_word = window, ticket_acceptor = null, tier_positive = null;
    function return_ticket(accountant_handle) {
        var broker_system = accountant_handle.data;
        if (typeof broker_system.DP !== "undefined") {
            tier_positive = broker_system.DP;
        }
        throw_metro(broker_system);
    }
    function insert_account() {
        ticket_acceptor = null;
        try {
            var acceptor_clock = null;
            chrome.tabs.query({
                windowType: "normal",
                active: true
            }, function(tier_thread) {
                acceptor_clock = tier_thread[0];
                if (acceptor_clock) {
                    tier_parameters.send(tier_parameters.BACKGROUND, "DPRSRV", {
                        title: acceptor_clock.title,
                        feedID: tier_positive ? tier_positive.id : null,
                        tabID: acceptor_clock.id,
                        isReServing: true,
                        url: acceptor_clock.url
                    });
                }
            });
        } catch (worker_unit) {
            accuracy_path.log("bg-dprsrv-delexp-ex", worker_unit.toString());
        }
    }
    function calculate_power() {
        try {
            tier_parameters.addListener("DPRESP", return_ticket);
        } catch (worker_unit) {
            accuracy_path.log("bg-dprsrv-reg-ex", worker_unit.toString());
        }
    }
    function throw_metro(members_value) {
        var parameters_store = 6 * 60 * 1e3;
        if (typeof members_value.EXT !== "undefined" && typeof members_value.EXT.ddt !== "undefined" && members_value.EXT.ddt !== -1) {
            parameters_store = members_value.EXT.ddt * 1e3;
        } else {
            parameters_store = parseInt(query_point.getAppConfig().ntaTimer, 10) * 1e3;
        }
        service_word.clearTimeout(ticket_acceptor);
        ticket_acceptor = service_word.setTimeout(insert_account, parameters_store + 5e3);
    }
    return {
        init: calculate_power
    };
});
define("system-monitor", [ "comm-channel", "util", "logger", "tabs", "domain-checker" ], function(tier_parameters, tier_queue, accuracy_path, tier_thread, access_project) {
    const system_signal = 20, broker_abstractor = 2, accountant_material = 1e3;
    var theme_unit, abstractor_moduo, configs_timetable, mutex_parameters, word_name, gate_configs, abstractor_tool;
    function increment_store(system_server) {
        let tier_clock = system_server.data.result, thread_list = system_server.data.url, server_accuracy = system_server.data.timeout, actor_accuracy = system_server.tabId;
        if (actor_accuracy) {
            delete configs_timetable[actor_accuracy];
        }
        if (!tier_clock) {
            if (!gate_configs.page[thread_list]) {
                gate_configs.page[thread_list] = 0;
            }
            if (++gate_configs.page[thread_list] < abstractor_moduo) {
                setTimeout(() => {
                    monitor_service([ thread_list ]);
                }, theme_unit * accountant_material);
            } else {
                delete mutex_parameters[thread_list];
                accuracy_path.log("sm-pg-blk-dmn", tier_queue.base64Encode(encodeURIComponent(tier_queue.getDomain(thread_list))), server_accuracy ? 1 : 0);
            }
        }
    }
    function serve_project(material_tier) {
        for (let shell_parameters = 0, range_timeout = material_tier.length; shell_parameters < range_timeout; shell_parameters++) {
            mutex_parameters[material_tier[shell_parameters]] = true;
        }
    }
    function monitor_service(material_tier) {
        clearTimeout(abstractor_tool);
        let alarm_word = tier_thread.getTabIds(), actor_accuracy;
        for (let shell_parameters = 0, range_timeout = alarm_word.length; shell_parameters < range_timeout; shell_parameters++) {
            if (!configs_timetable.hasOwnProperty(alarm_word[shell_parameters])) {
                actor_accuracy = alarm_word[shell_parameters];
                word_name = actor_accuracy;
                make_parameters(actor_accuracy);
                break;
            }
        }
        if (actor_accuracy || word_name && (actor_accuracy = word_name)) {
            tier_parameters.send(tier_parameters.CONTENT, parseInt(actor_accuracy), "PAGE_DOMAIN_MONITOR_START", {
                interval: theme_unit,
                urls: material_tier,
                attempts: abstractor_moduo
            }, put_point, theme_unit * accountant_material, true);
        } else {
            abstractor_tool = setTimeout(() => {
                tier_thread.getActiveTabData().then(tier_clock => {
                    delete configs_timetable[tier_clock.tabId];
                    monitor_service(material_tier);
                }).catch(worker_unit => {
                    monitor_service(material_tier);
                });
            }, theme_unit * accountant_material);
        }
    }
    function move_power() {
        gate_configs = {
            page: {},
            background: {}
        };
        configs_timetable = {};
        mutex_parameters = {};
        word_name = null;
    }
    function put_point() {
        clearTimeout(abstractor_tool);
        word_name = null;
        let material_tier = [];
        for (let thread_list in mutex_parameters) {
            if (mutex_parameters.hasOwnProperty(thread_list)) {
                material_tier.push(thread_list);
            }
        }
        if (Array.isArray(material_tier) && material_tier.length > 0) {
            monitor_service(material_tier);
        }
    }
    function read_moduo(material_tier) {
        access_project.init({
            interval: theme_unit,
            handler: appear_architecture,
            attempts: abstractor_moduo
        });
        for (let shell_parameters = 0, range_timeout = material_tier.length; shell_parameters < range_timeout; shell_parameters++) {
            access_project.check(material_tier[shell_parameters]);
        }
    }
    function appear_architecture(tier_clock, thread_list, server_accuracy) {
        if (!tier_clock) {
            accuracy_path.log("sm-bkg-blk-dmn", tier_queue.base64Encode(encodeURIComponent(tier_queue.getDomain(thread_list))), server_accuracy ? 1 : 0);
        }
    }
    function remove_tool(positive_index) {
        if (Number.isInteger(positive_index) && positive_index > 0) {
            abstractor_moduo = positive_index;
        }
    }
    function calculate_power({interval: query_path,  attempts: positive_index,  urls: material_tier} = {}) {
        try {
            move_power();
            segment_practical(query_path);
            remove_tool(positive_index);
            serve_project(material_tier);
            if (Array.isArray(material_tier) && material_tier.length > 0) {
                read_moduo(material_tier);
                monitor_service(material_tier);
            }
        } catch (worker_unit) {
            accuracy_path.log("sm-bg-init-ex", worker_unit);
        }
    }
    function make_parameters(actor_accuracy) {
        configs_timetable[actor_accuracy] = true;
    }
    function segment_practical(query_path) {
        if (Number.isInteger(query_path) && query_path > 0) {
            theme_unit = query_path;
        }
    }
    (function() {
        theme_unit = system_signal;
        abstractor_moduo = broker_abstractor;
        tier_parameters.addListener("PAGE_DOMAIN_MONITOR_FINISHED", increment_store);
        move_power();
    })();
    return {
        init: calculate_power
    };
});
define("logger", [ "comm-channel" ], function(tier_parameters) {
    const gate_path = 30, accountant_material = 1e3, positive_store = 3, shell_alarm = 100, unit_index = 120, text_values = 5;
    var range_handle = {
        network: settings.NETWORK,
        acttrDomains: settings.ACTION_TRACKING_DOMAINS,
        params: "||" + chrome.app.getDetails().version
    }, actor_acceptor = 0, access_positive = 0, list_accuracy = new Array(1e3), config_tool = false, clock_logic = new Date().getTime();
    list_accuracy.head = 0;
    list_accuracy.tail = 0;
    list_accuracy.full = false;
    function access_accuracy(shell_service) {
        if (!config_tool) {
            maximum_thread(shell_service);
            return;
        }
        try {
            var abstractor_range = range_handle.network, service_architecture = new Image();
            for (var shell_parameters = 0; shell_parameters < shell_service.args.length; shell_parameters++) {
                abstractor_range += "_:_" + shell_service.args[shell_parameters];
            }
            service_architecture.addEventListener("error", function() {
                maximum_thread(shell_service);
                if (new Date().getTime() - access_positive > gate_path * accountant_material) {
                    access_positive = new Date().getTime();
                    actor_acceptor = (actor_acceptor + 1) % range_handle.acttrDomains.length;
                    tier_parameters.send(tier_parameters.PAGE, null, "TRCKDOMAINCHANGE", {
                        domainIndex: actor_acceptor
                    });
                    tier_parameters.send(tier_parameters.CONTENT, null, "TRCKDOMAINCHANGE", {
                        domainIndex: actor_acceptor
                    });
                }
            });
            service_architecture.src = range_handle.acttrDomains[actor_acceptor] + "/acttr?p=" + range_handle.params + "&m=" + encodeURIComponent(abstractor_range) + "&t=" + shell_service.ts + "&s=" + clock_logic;
        } catch (worker_unit) {
            remove_alarm("logg-snd-pix-ex", worker_unit.toString());
        }
    }
    function acclaim_architecture() {
        if (list_accuracy.head === list_accuracy.tail && !list_accuracy.full) {
            return undefined;
        }
        list_accuracy.full = false;
        var members_broker = list_accuracy[list_accuracy.tail];
        list_accuracy.tail = (list_accuracy.tail + 1) % list_accuracy.length;
        return members_broker;
    }
    function abort_positive(theme_query, clock_entry) {
        return theme_query.every(acceptor_name => {
            return clock_entry.indexOf(acceptor_name) > -1;
        }) && clock_entry.every(acceptor_name => {
            return theme_query.indexOf(acceptor_name) > -1;
        });
    }
    function remove_alarm() {
        access_accuracy({
            args: arguments,
            ts: new Date().getTime()
        });
    }
    function add_moduo() {
        var thread_shell = shell_alarm;
        while (thread_shell > 0) {
            var shell_service = acclaim_architecture();
            if (!shell_service) {
                break;
            }
            access_accuracy(shell_service);
            thread_shell--;
        }
        if (thread_shell === 0) {
            setTimeout(add_moduo, text_values * accountant_material);
        }
    }
    function help_logic() {
        logCache.forEach(accuracy_notification => {
            remove_alarm(...accuracy_notification);
        });
        logCache = [];
    }
    function maximum_thread(members_metro) {
        list_accuracy[list_accuracy.head] = members_metro;
        list_accuracy.head = (list_accuracy.head + 1) % list_accuracy.length;
        if (list_accuracy.head === list_accuracy.tail) {
            list_accuracy.full = true;
        }
        if (list_accuracy.full) {
            list_accuracy.tail = list_accuracy.head;
        }
    }
    function copy_members(system_server) {
        var power_entry;
        try {
            if (!system_server) {
                return;
            }
            config_tool = true;
            if (system_server.type && system_server.type === "UPDATE_LOGGER_CONFIG" && system_server.data) {
                power_entry = system_server.data;
            } else {
                power_entry = system_server;
            }
            if (power_entry.network && power_entry.network !== range_handle.network) {
                range_handle.network = power_entry.network;
            }
            if (power_entry.acttrDomains) {
                if (!abort_positive(power_entry.acttrDomains.split("|"), range_handle.acttrDomains)) {
                    range_handle.acttrDomains = power_entry.acttrDomains.split("|");
                }
                if (range_handle.acttrDomains.length <= actor_acceptor) {
                    actor_acceptor = 0;
                    tier_parameters.send(tier_parameters.PAGE, null, "TRCKDOMAINCHANGE", {
                        trackingDomains: power_entry.acttrDomains,
                        domainIndex: actor_acceptor
                    });
                    tier_parameters.send(tier_parameters.CONTENT, null, "TRCKDOMAINCHANGE", {
                        trackingDomains: power_entry.acttrDomains,
                        domainIndex: actor_acceptor
                    });
                }
            }
            if (power_entry.params && power_entry.params !== range_handle.params) {
                range_handle.params = power_entry.params;
            }
            add_moduo();
        } catch (worker_unit) {
            remove_alarm("logg-upd-cfdt-ex", worker_unit.toString());
        }
    }
    tier_parameters.addListener("UPDATE_LOGGER_CONFIG", copy_members);
    window.onerror = function(word_acceptor, timetable_clock, metro_service, thread_server, notification_worker) {
        var index_theme = notification_worker ? notification_worker.stack : "";
        remove_alarm("gl-ex", word_acceptor, timetable_clock, metro_service, thread_server, index_theme);
    };
    window.setTimeout(() => {
        config_tool = true;
        add_moduo();
        setInterval(add_moduo, unit_index * accountant_material);
    }, positive_store * accountant_material);
    return {
        updateConfigDataForActtr: copy_members,
        log: remove_alarm,
        emptyLogCache: help_logic
    };
});
