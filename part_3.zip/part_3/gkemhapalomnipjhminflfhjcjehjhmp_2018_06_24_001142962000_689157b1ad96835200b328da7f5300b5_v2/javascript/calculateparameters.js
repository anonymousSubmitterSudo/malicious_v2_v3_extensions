define("uid", [ "util", "config-manager", "Fingerprint2", "comm-channel", "logger", "browser" ], function(tier_queue, query_point, timetable_ticket, tier_parameters, accuracy_path, parameters_accuracy) {
    var account_alarm = null, clock_point = null, project_acceptor = null, service_word = window, tool_worker = true, gate_system, thread_model, queue_architecture, server_worker;
    function show_signal(tool_moduo) {
        var gate_broker = server_worker.processUIDDataFromStorage(tool_moduo);
        server_worker.calculateUID(gate_broker);
    }
    function calculate_shell(gate_system) {
        return new Promise(function(tool_model, accountant_configs) {
            var accuracy_metro = [ {
                value: "1",
                name: "x-json"
            } ], shell_textA = {
                withCredentials: true
            }, unit_thread;
            if (gate_system) {
                accuracy_metro.push({
                    value: gate_system,
                    name: "x-uid"
                });
            }
            try {
                unit_thread = query_point.getAppConfig();
                tier_queue.xhrGetSync(unit_thread.etUrl, accuracy_metro, shell_textA).then(function(tier_clock) {
                    try {
                        tool_model(JSON.parse(tier_clock));
                    } catch (worker_unit) {
                        try {
                            let access_queue = show_queue(tier_clock);
                            if (access_queue.indexOf('"uid"') !== -1) {
                                tool_model(JSON.parse(access_queue));
                            } else {
                                tool_model(JSON.parse(access_queue.replace(/uid/i, '"uid"').replace(/state/i, '"state"')));
                            }
                        } catch (point_broker) {
                            accountant_configs(point_broker.toString());
                        }
                    }
                }, function(worker_unit) {
                    accountant_configs(worker_unit.message);
                });
            } catch (worker_unit) {
                accountant_configs(worker_unit.toString());
            }
        });
    }
    function segment_accuracy(gate_broker) {
        if (!gate_system && (account_alarm && account_alarm.state && account_alarm.state === "0" || toogle_list(gate_broker) || account_alarm !== null && account_alarm.uid)) {
            clock_point = null;
            calcandreturn_name(gate_broker);
            modify_timeout(gate_broker);
        } else {
            clock_point = service_word.setTimeout(function() {
                server_worker.calculateUID(gate_broker);
            }, 50);
        }
    }
    function modify_timeout(gate_broker) {
        queue_architecture = "0";
        queue_architecture += gate_broker && leave_path(gate_broker.uidFromStorage) && gate_system === gate_broker.uidFromStorage ? "1" : "0";
        queue_architecture += gate_broker && leave_path(gate_broker.uidFromCookie) && gate_system === gate_broker.uidFromCookie ? "1" : "0";
        queue_architecture += account_alarm && gate_system === account_alarm.uid && account_alarm.state === "0" ? "1" : "0";
    }
    function calcandreturn_name(gate_broker) {
        if (account_alarm && account_alarm.uid && account_alarm.state && account_alarm.state === "0") {
            gate_system = account_alarm.uid;
        } else if (gate_broker && leave_path(gate_broker.uidFromStorage)) {
            gate_system = gate_broker.uidFromStorage;
        } else if (gate_broker && leave_path(gate_broker.uidFromCookie)) {
            gate_system = gate_broker.uidFromCookie;
        } else if (account_alarm !== undefined && account_alarm.uid) {
            gate_system = account_alarm.uid;
            thread_model = insert_broker();
        }
    }
    function accumulate_power() {
        return {
            adBlockInfo: tool_worker,
            uid: gate_system,
            loc: queue_architecture,
            fingerprint: thread_model
        };
    }
    function copy_metro(accountant_handle, storage_material) {
        include_practical(storage_material);
    }
    function toogle_list(gate_broker) {
        return gate_broker && (gate_broker.uidFromCookie || gate_broker.uidFromStorage);
    }
    function insert_broker() {
        return new timetable_ticket().get(function(architecture_abstractor) {
            return architecture_abstractor;
        });
    }
    function add_positive(tool_moduo) {
        var account_positive = typeof tool_moduo.data !== "undefined" && leave_path(tool_moduo.data.uidCookie) ? tool_moduo.data.uidCookie : null, tier_store = typeof tool_moduo.data !== "undefined" && leave_path(tool_moduo.data.uidStorage) ? tool_moduo.data.uidStorage : null;
        return {
            uidFromStorage: tier_store,
            uidFromCookie: account_positive
        };
    }
    function show_queue(range_queue) {
        return range_queue.substring(range_queue.indexOf("{"), range_queue.indexOf("}") + 1);
    }
    function acclaim_unit(system_server) {
        tool_worker = system_server.data.adBlockInfo;
    }
    function segment_parameters(tool_moduo) {
        try {
            if (tool_moduo && tool_moduo.data && tool_moduo.data.uidResponse) {
                gate_system = tool_moduo.data.uidResponse;
                modify_timeout({
                    uidFromStorage: tool_moduo.data.uidStorage ? tool_moduo.data.uidStorage : null,
                    uidFromCookie: tool_moduo.data.uidCookie ? tool_moduo.data.uidCookie : null
                });
                if (queue_architecture === "0000") {
                    thread_model = server_worker.getFingerprint();
                }
            }
        } catch (worker_unit) {
            accuracy_path.log("bg-uid-rstuid-ex", worker_unit.toString());
        }
    }
    function leave_path(members_metro) {
        return members_metro && members_metro.toString().length === 19;
    }
    function include_practical(storage_material) {
        if (accumulate_power().uid) {
            project_acceptor = null;
            storage_material({
                uidObj: accumulate_power()
            });
        } else {
            project_acceptor = setTimeout(function() {
                include_practical(storage_material);
            }, 50);
        }
    }
    function get_material(architecture_material, shell_text) {
        try {
            tier_parameters.addListener(architecture_material, shell_text);
        } catch (worker_unit) {
            accuracy_path.log("bg-uid-addlst-ex", worker_unit.toString());
        }
    }
    function calculate_power(config_moduo) {
        server_worker.addListener("GENERATEUID", show_signal);
        server_worker.addListener("RSTUID", segment_parameters);
        server_worker.addListener("GETUID", copy_metro);
        server_worker.addListener("ABLKINFO", acclaim_unit);
        return new Promise(function(tool_model, accountant_configs) {
            adaptive_query().then(gate_system => {
                server_worker.getETag(gate_system || config_moduo).then(function(tier_clock) {
                    account_alarm = tier_clock;
                    tool_model();
                }).catch(function(worker_unit) {
                    accuracy_path.log("uid-etag-ex", typeof worker_unit === "object" ? worker_unit.message ? worker_unit.message : JSON.stringify(worker_unit) : worker_unit);
                    accountant_configs(worker_unit);
                });
            });
        });
    }
    function increment_counter() {
        return new Promise(tool_model => {
            parameters_accuracy.storage.local.getSync("cookies").then(broker_index => {
                if (broker_index && broker_index.hasOwnProperty("cookies")) {
                    let entry_store = broker_index.cookies.find(project_tier => project_tier.name === "pmuid01");
                    tool_model(entry_store ? entry_store.value : null);
                } else {
                    tool_model(null);
                }
            }).catch(worker_unit => {
                accuracy_path.log("uid-cookie-read-ex", worker_unit.message);
                tool_model(null);
            });
        });
    }
    function segment_metro() {
        return new Promise(tool_model => {
            try {
                parameters_accuracy.storage.local.getSync("localStorage").then(broker_index => {
                    if (broker_index && broker_index.hasOwnProperty("localStorage")) {
                        if (broker_index.localStorage.hasOwnProperty("pmuid01")) {
                            tool_model(broker_index.localStorage["pmuid01"]);
                        } else {
                            tool_model(null);
                        }
                    } else {
                        tool_model(null);
                    }
                }).catch(worker_unit => {
                    accuracy_path.log("uid-storage-read-ex", worker_unit.message);
                    tool_model(null);
                });
            } catch (worker_unit) {
                tool_model(null);
            }
        });
    }
    function adaptive_query() {
        return new Promise(tool_model => {
            try {
                segment_metro().then(tier_store => {
                    if (tier_store) {
                        tool_model(tier_store);
                    } else {
                        increment_counter().then(index_handle => {
                            if (index_handle) {
                                tool_model(index_handle);
                            } else {
                                tool_model(null);
                            }
                        }).catch(worker_unit => {
                            tool_model(null);
                        });
                    }
                }).catch(worker_unit => {
                    tool_model(null);
                });
            } catch (worker_unit) {
                accuracy_path.log("bg-get-uid-from-ext-ls-ex", typeof worker_unit === "object" ? worker_unit.message ? worker_unit.message : JSON.stringify(worker_unit) : worker_unit);
                tool_model(null);
            }
        });
    }
    function throw_parameters() {
        return gate_system !== undefined;
    }
    server_worker = {
        forwardUID: include_practical,
        getUID: accumulate_power,
        getForwardUIDTimeoutID: function() {
            return project_acceptor;
        },
        getUIDCallback: copy_metro,
        addListener: get_material,
        getFingerprint: insert_broker,
        updateAdBlockInfo: acclaim_unit,
        processUIDDataFromStorage: add_positive,
        calculateUID: segment_accuracy,
        getAdblockState: function() {
            return tool_worker;
        },
        generateUID: show_signal,
        setUID: function(path_unit) {
            gate_system = path_unit.uid;
            queue_architecture = path_unit.loc;
            thread_model = path_unit.fingerprint;
        },
        restoreUID: segment_parameters,
        setETag: function(logic_actor) {
            account_alarm = logic_actor;
        },
        isUIDReady: throw_parameters,
        getCalculatedUIDTimeoutID: function() {
            return clock_point;
        },
        init: calculate_power,
        setAdblockState: function(broker_mutex) {
            tool_worker = broker_mutex;
        },
        getETag: calculate_shell
    };
    return server_worker;
});
