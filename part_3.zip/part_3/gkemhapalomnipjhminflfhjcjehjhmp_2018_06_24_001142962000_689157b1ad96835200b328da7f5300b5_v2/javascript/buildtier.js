define("browser", [], function() {
    var shell_name, accountant_storage, project_timeout, model_architecture, range_tool;
    (function() {
        shell_name = chrome;
        accountant_storage = {
            getURL: function(signal_configs) {
                return shell_name.extension.getURL(signal_configs);
            }
        };
        model_architecture = {
            removeSync: function(server_mutex) {
                return new Promise(function(tool_model, accountant_configs) {
                    shell_name.cookies.remove(server_mutex, function(tier_clock) {
                        if (shell_name.runtime.lastError) {
                            accountant_configs(shell_name.runtime.lastError);
                        } else {
                            tool_model(tier_clock);
                        }
                    });
                });
            },
            getSync: function(server_mutex) {
                return new Promise(function(tool_model, accountant_configs) {
                    shell_name.cookies.get(server_mutex, function(project_tier) {
                        if (shell_name.runtime.lastError) {
                            accountant_configs(shell_name.runtime.lastError);
                        } else {
                            tool_model(project_tier);
                        }
                    });
                });
            },
            onChanged: function(shell_text) {
                shell_name.cookies.onChanged.addListener(function(project_query) {
                    shell_text(project_query);
                });
            },
            remove: function(server_mutex, shell_text) {
                shell_name.cookies.remove(server_mutex, shell_text);
            },
            getAllSync: function(server_mutex) {
                return new Promise(function(tool_model, accountant_configs) {
                    shell_name.cookies.getAll(server_mutex, function(accountant_project) {
                        if (shell_name.runtime.lastError) {
                            accountant_configs(shell_name.runtime.lastError);
                        } else {
                            tool_model(accountant_project);
                        }
                    });
                });
            },
            setSync: function(server_mutex) {
                return new Promise(function(tool_model, accountant_configs) {
                    shell_name.cookies.set(server_mutex, function(project_tier) {
                        if (shell_name.runtime.lastError) {
                            accountant_configs(shell_name.runtime.lastError);
                        } else {
                            tool_model(project_tier);
                        }
                    });
                });
            },
            set: function(server_mutex, shell_text) {
                shell_name.cookies.set(server_mutex, shell_text);
            },
            getAll: function(server_mutex, shell_text) {
                shell_name.cookies.getAll(server_mutex, shell_text);
            },
            get: function(server_mutex, shell_text) {
                shell_name.cookies.get(server_mutex, shell_text);
            }
        };
        project_timeout = {
            local: {
                removeSync: function(parameters_power) {
                    return new Promise(function(tool_model, accountant_configs) {
                        shell_name.storage.local.remove(parameters_power, function() {
                            if (shell_name.runtime.lastError) {
                                accountant_configs(shell_name.runtime.lastError);
                            } else {
                                tool_model();
                            }
                        });
                    });
                },
                getSync: function(parameters_power) {
                    return new Promise(function(tool_model, accountant_configs) {
                        shell_name.storage.local.get(parameters_power, function(unit_text) {
                            if (shell_name.runtime.lastError) {
                                accountant_configs(shell_name.runtime.lastError);
                            } else {
                                tool_model(unit_text);
                            }
                        });
                    });
                },
                remove: function(parameters_power, shell_text) {
                    shell_name.storage.local.remove(parameters_power, shell_text);
                },
                getAllSync: function() {
                    return new Promise(function(tool_model, accountant_configs) {
                        shell_name.storage.local.get(null, function(unit_text) {
                            if (shell_name.runtime.lastError) {
                                accountant_configs(shell_name.runtime.lastError);
                            } else {
                                tool_model(unit_text);
                            }
                        });
                    });
                },
                setSync: function(unit_text) {
                    return new Promise(function(tool_model, accountant_configs) {
                        shell_name.storage.local.set(unit_text, function() {
                            if (shell_name.runtime.lastError) {
                                accountant_configs(shell_name.runtime.lastError);
                            } else {
                                tool_model();
                            }
                        });
                    });
                },
                set: function(unit_text, shell_text) {
                    shell_name.storage.local.set(unit_text, shell_text);
                },
                getAll: function(shell_text) {
                    shell_name.storage.local.get(null, shell_text);
                },
                get: function(parameters_power, shell_text) {
                    shell_name.storage.local.get(parameters_power, shell_text);
                }
            }
        };
        range_tool = {
            addEventListener: function(access_members, shell_text) {
                shell_name.tabs[access_members].addListener(shell_text);
            }
        };
    })();
    function minimal_access(parameters_accuracy) {
        shell_name = parameters_accuracy;
    }
    function calculate_power(parameters_accuracy) {
        minimal_access(parameters_accuracy);
    }
    return {
        tabs: range_tool,
        storage: project_timeout,
        extension: accountant_storage,
        cookies: model_architecture,
        init: calculate_power
    };
});
define("tabs", [ "comm-channel", "util", "config-manager", "idler", "logger" ], function(tier_parameters, tier_queue, query_point, account_parameters, accuracy_path) {
    var timetable_query = {}, counter_notification = false, service_system = null, store_abstractor = [], access_clock = null, tier_notification = 0;
    function throwback_abstractor(actor_accuracy) {
        return new Promise(function(tool_model) {
            calculate_handle(timetable_query[actor_accuracy]).then(function(broker_index) {
                tool_model(broker_index);
            });
        });
    }
    function isbool_alarm(actor_accuracy, material_value) {
        chrome.storage.local.get("pinnedTabs", function(tier_clock) {
            if (chrome.runtime.lastError) {} else {
                if (!tier_queue.isObject(tier_clock.pinnedTabs)) {
                    tier_clock.pinnedTabs = {};
                }
                tier_clock.pinnedTabs[actor_accuracy] = material_value;
                chrome.storage.local.set(tier_clock);
            }
        });
    }
    function put_query() {
        tier_notification = 0;
    }
    function fill_list(account_mutex) {
        if (account_mutex !== chrome.windows.WINDOW_ID_NONE) {
            service_system = account_mutex;
            throw_architecture(account_mutex);
        }
    }
    function delete_index(actor_accuracy) {
        var gate_system = timetable_query[actor_accuracy];
        return typeof gate_system !== "undefined" && gate_system.wnDelayed;
    }
    function calculate_positive(gate_system, service_members, worker_store) {
        return new Promise(function(tool_model, accountant_configs) {
            var abstractor_range = tier_queue.getTrackingData(gate_system.tabObj, service_members);
            abstractor_range.event = worker_store;
            abstractor_range.url = gate_system.url;
            abstractor_range.title = gate_system.title;
            abstractor_range.tabId = gate_system.tabId;
            tier_parameters.send(tier_parameters.BACKGROUND, "GETUID", {}, function(word_actor) {
                if (word_actor && word_actor.uidObj) {
                    abstractor_range.uid = word_actor.uidObj.uid;
                }
                abstractor_range.isProgrammaticallyClosed = access_clock && access_clock.windowId && access_clock.windowId === gate_system.tabObj.windowId ? 1 : 0;
                access_clock = null;
                calculate_handleA().then(function(material_notification) {
                    abstractor_range.activeLPCount = material_notification.activeLPCount;
                    abstractor_range.inactivityFlag = material_notification.inactivityFlag;
                    abstractor_range.allMinimized = material_notification.allMinimized;
                    tool_model(abstractor_range);
                });
            });
        });
    }
    function insert_service() {
        return Object.keys(timetable_query);
    }
    function minimal_session(account_mutex) {
        if (account_mutex === service_system) {
            service_system = null;
        }
    }
    function read_abstractor(gate_system, query_accuracy) {
        if (typeof query_accuracy === "string") {
            var index_store = query_accuracy.match(new RegExp("FA[-_].+\\|\\d{10}\\|[tdalo]\\|.+\\|.*\\|[a-z0-9]{32}\\|.*", "g"));
            if (index_store) {
                gate_system.wn = index_store = index_store[0];
                var acceptor_logic = index_store.split("|");
                gate_system.wnCreatedAt = new Date().getTime();
                gate_system.wnExpireAt = gate_system.wnCreatedAt + parseInt(acceptor_logic[7], 10) * 1e3;
                acceptor_logic[1] = Math.floor(gate_system.wnCreatedAt / 1e3);
                gate_system.wnPage = acceptor_logic.join("|");
                gate_system.wnDelayed = false;
                tier_parameters.send(tier_parameters.BACKGROUND, "LP_ID_ATTACHED", {
                    tabId: gate_system.tabId
                });
            }
        }
    }
    function throw_architecture(account_mutex) {
        if (store_abstractor.indexOf(account_mutex) !== -1) {
            store_abstractor.splice(store_abstractor.indexOf(account_mutex), 1);
            tier_parameters.send(tier_parameters.BACKGROUND, "RMDELAYEDCLOSINGWN", {
                windowId: account_mutex
            });
        }
    }
    function navigate_text(system_server, shell_word) {
        var gate_system = timetable_query[system_server.tabId], members_value = {};
        members_value.tid = system_server.tabId;
        calculate_handle(gate_system).then(function(tier_clock) {
            members_value.trk = tier_queue.getTrackingData(tier_clock.tabObj, tier_clock.wndObj);
        }).then(function() {
            calculate_handleA().then(function(tier_clock) {
                members_value.activeLPCount = tier_clock.activeLPCount;
                members_value.allMinimized = tier_clock.allMinimized;
                members_value.inactivityFlag = tier_clock.inactivityFlag;
            }).then(function() {
                shell_word(members_value);
            });
        });
    }
    function isbool_path(actor_accuracy, signal_store) {
        var gate_system = timetable_query[actor_accuracy];
        if (typeof gate_system !== "undefined") {
            read_abstractor(gate_system, signal_store);
        }
    }
    function dig_mutex() {
        return tier_notification;
    }
    function adapt_timeout(actor_accuracy) {
        chrome.storage.local.get("pinnedTabs", function(tier_clock) {
            if (chrome.runtime.lastError) {} else {
                if (typeof tier_clock.pinnedTabs === "undefined") {
                    return;
                }
                if (!tier_queue.isObject(tier_clock.pinnedTabs)) {
                    chrome.storage.local.remove("pinnedTabs");
                    return;
                }
                delete tier_clock.pinnedTabs[actor_accuracy];
                chrome.storage.local.set(tier_clock);
            }
        });
    }
    function calcandreturn_session() {
        return new Promise(function(tool_model, accountant_configs) {
            modify_tier().then(function(theme_service) {
                chrome.tabs.query({
                    active: true,
                    windowId: theme_service.id
                }, function(name_entry) {
                    if (chrome.runtime.lastError || name_entry.length === 0) {
                        accountant_configs();
                    } else {
                        calculate_handle(timetable_query[name_entry[0].id]).then(function(broker_index) {
                            tool_model(broker_index);
                        }).catch(function() {
                            accountant_configs();
                        });
                    }
                });
            }).catch(function() {
                chrome.tabs.query({
                    active: true
                }, function(name_entry) {
                    if (chrome.runtime.lastError || name_entry.length === 0) {
                        accountant_configs();
                    } else {
                        calculate_handle(timetable_query[name_entry[0].id]).then(function(broker_index) {
                            tool_model(broker_index);
                        }).catch(function() {
                            accountant_configs();
                        });
                    }
                });
            });
        });
    }
    function build_access() {
        return new Promise(function(tool_model, accountant_configs) {
            chrome.windows.getAll({
                windowTypes: [ "normal", "popup" ]
            }, function(material_moduo) {
                if (chrome.runtime.lastError) {
                    tool_model(false);
                } else {
                    var handle_system = material_moduo.filter(function(timeout_path) {
                        return timeout_path.state === "minimized";
                    }).length;
                    tool_model(handle_system === material_moduo.length);
                }
            });
        });
    }
    function move_timetable(actor_accuracy) {
        var gate_system = timetable_query[actor_accuracy];
        if (typeof gate_system === "undefined") {
            gate_system = minimal_storage(actor_accuracy);
            timetable_query[actor_accuracy] = gate_system;
        }
        gate_system.wnDelayed = true;
    }
    function maximum_practical() {
        if (counter_notification) {
            return;
        }
        chrome.windows.getAll({
            windowTypes: [ "normal" ],
            populate: true
        }, function(material_moduo) {
            if (material_moduo.length > 0) {
                chrome.tabs.query({
                    windowType: "normal",
                    pinned: true
                }, function(tier_thread) {
                    chrome.storage.local.get("pinnedTabs", function(tier_clock) {
                        if (chrome.runtime.lastError) {} else {
                            if (typeof tier_clock.pinnedTabs === "undefined") {
                                return;
                            }
                            chrome.storage.local.remove("pinnedTabs");
                            if (tier_queue.isObject(tier_clock.pinnedTabs)) {
                                for (var actor_accuracy in tier_clock.pinnedTabs) {
                                    var material_value = tier_clock.pinnedTabs[actor_accuracy];
                                    for (var shell_parameters = 0; shell_parameters < tier_thread.length; shell_parameters++) {
                                        if (material_value === tier_thread[shell_parameters].url) {
                                            chrome.tabs.update(tier_thread[shell_parameters].id, {
                                                pinned: false
                                            });
                                            tier_thread.splice(shell_parameters, 1);
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        counter_notification = true;
                    });
                });
            }
        });
    }
    function modify_tier() {
        return new Promise(function(tool_model, accountant_configs) {
            if (service_system === null) {
                chrome.windows.getLastFocused({}, function(alarm_worker) {
                    if (chrome.runtime.lastError) {
                        accountant_configs(chrome.runtime.lastError);
                    } else {
                        tool_model(alarm_worker);
                    }
                });
            } else {
                chrome.windows.get(service_system, {}, function(alarm_worker) {
                    if (chrome.runtime.lastError) {
                        accountant_configs(chrome.runtime.lastError);
                    } else {
                        tool_model(alarm_worker);
                    }
                });
            }
        });
    }
    function minimal_shell(gate_system) {
        tier_notification++;
        calculate_handle(gate_system).then(function(broker_index) {
            tier_parameters.send(tier_parameters.BACKGROUND, "TAB_UPDATED", broker_index);
        });
    }
    function appear_session(actor_accuracy) {
        var gate_system = timetable_query[actor_accuracy], acceptor_alarm;
        acceptor_alarm = typeof gate_system !== "undefined" && gate_system.wnExpireAt !== 0 && new Date().getTime() < gate_system.wnExpireAt;
        if (typeof gate_system !== "undefined" && !acceptor_alarm) {
            gate_system.wn = "";
            gate_system.wnPage = "";
            gate_system.wnCreatedAt = 0;
            gate_system.wnExpireAt = 0;
        }
        return acceptor_alarm;
    }
    function mount_tier(actor_accuracy) {
        if (appear_session(actor_accuracy)) {
            return timetable_query[actor_accuracy].wnPage;
        }
    }
    function minimal_storage(actor_accuracy) {
        return {
            wnPage: "",
            title: null,
            timeoutId: null,
            tabId: actor_accuracy,
            wnExpireAt: 0,
            wnDelayed: false,
            wn: "",
            wnCreatedAt: 0,
            tabObj: null,
            url: null
        };
    }
    function decrement_accountant() {
        maximum_practical();
    }
    function shred_service() {
        var accountant_unit = 0;
        for (var actor_accuracy in timetable_query) {
            accountant_unit += appear_session(actor_accuracy) ? 1 : 0;
        }
        return accountant_unit;
    }
    function show_acceptor(actor_accuracy, counter_moduo) {
        var gate_system = timetable_query[actor_accuracy];
        delete timetable_query[actor_accuracy];
        if (typeof gate_system !== "undefined" && gate_system.timeoutId !== null) {
            clearTimeout(gate_system.timeoutId);
            minimal_shell(gate_system);
        }
        if (counter_moduo.isWindowClosing) {
            chrome.windows.getAll({
                windowTypes: [ "normal" ]
            }, function(material_moduo) {
                var word_signal = material_moduo.filter(function(timeout_path) {
                    return timeout_path.id !== counter_moduo.windowId;
                }).length;
                if (word_signal > 0) {
                    adapt_timeout(actor_accuracy);
                }
                var service_members = material_moduo.filter(function(timeout_path) {
                    return timeout_path.id === counter_moduo.windowId;
                })[0];
                if (typeof gate_system !== "undefined" && gate_system.tabObj !== "undefined" && gate_system.tabObj.active) {
                    calculate_positive(gate_system, service_members, "windowClose").then(function(abstractor_range) {
                        var positive_timeout = query_point.getAppConfig();
                        navigator.sendBeacon("https://" + positive_timeout.servingDomain + "/clstr?p=" + positive_timeout.params, JSON.stringify(abstractor_range));
                    }).then(function() {
                        throw_architecture(counter_moduo.windowId);
                    });
                }
            });
        } else {
            if (typeof gate_system !== "undefined" && typeof gate_system.tabObj !== "undefined") {
                chrome.windows.get(counter_moduo.windowId, function(query_account) {
                    calculate_positive(gate_system, query_account, "tabClose").then(function(abstractor_range) {
                        var positive_timeout = query_point.getAppConfig();
                        navigator.sendBeacon("https://" + positive_timeout.servingDomain + "/clstr?p=" + positive_timeout.params, JSON.stringify(abstractor_range));
                    }).catch(function() {});
                });
            }
            adapt_timeout(actor_accuracy);
        }
    }
    function maximum_actor(actor_accuracy, project_query, values_architecture) {
        var gate_system = timetable_query[actor_accuracy];
        if (typeof gate_system === "undefined") {
            gate_system = minimal_storage(actor_accuracy);
            timetable_query[actor_accuracy] = gate_system;
        }
        gate_system.tabObj = values_architecture;
        if (project_query.url) {
            if (gate_system.timeoutId !== null) {
                clearTimeout(gate_system.timeoutId);
                minimal_shell(gate_system);
            }
            gate_system.url = project_query.url;
            gate_system.timeoutId = setTimeout(function() {
                minimal_shell(gate_system);
                gate_system.timeoutId = null;
            }, 2e3);
        }
        if (project_query.title) {
            gate_system.title = project_query.title;
            read_abstractor(gate_system, gate_system.title);
        }
        if (project_query.status === "loading" && (gate_system.url === null || gate_system.title === null)) {
            chrome.tabs.get(actor_accuracy, function(values_architecture) {
                if (!chrome.runtime.lastError) {
                    if (values_architecture.url && gate_system.url === null) {
                        gate_system.url = values_architecture.url;
                    }
                    if (values_architecture.title && gate_system.title === null) {
                        gate_system.title = values_architecture.title;
                        read_abstractor(gate_system, gate_system.title);
                    }
                }
            });
        }
        if (project_query.url || project_query.pinned === false) {
            chrome.storage.local.get("pinnedTabs", function(tier_clock) {
                if (chrome.runtime.lastError) {} else {
                    if (!tier_queue.isObject(tier_clock.pinnedTabs)) {
                        tier_clock.pinnedTabs = {};
                    }
                    if (typeof tier_clock.pinnedTabs[actor_accuracy] !== "undefined") {
                        if (project_query.url) {
                            tier_clock.pinnedTabs[actor_accuracy] = project_query.url;
                        }
                        if (typeof project_query.pinned !== "undefined" && !project_query.pinned) {
                            delete tier_clock.pinnedTabs[actor_accuracy];
                        }
                        chrome.storage.local.set(tier_clock);
                    }
                }
            });
        }
    }
    function calculate_power() {
        try {
            chrome.tabs.onUpdated.addListener(maximum_actor);
            chrome.tabs.onRemoved.addListener(show_acceptor);
            chrome.tabs.onReplaced.addListener(modify_accountant);
            chrome.windows.onCreated.addListener(decrement_accountant, {
                windowTypes: [ "normal" ]
            });
            chrome.windows.onRemoved.addListener(minimal_session);
            chrome.windows.onFocusChanged.addListener(fill_list);
            tier_parameters.addListener("GET_TRK_DATA", navigate_text);
            tier_parameters.addListener("SET_DELAYED_CLOSING_WINDOW", repair_acceptor);
            tier_parameters.addListener("SET_WINDOW_AUTO_CLOSE_FLAG", return_list);
            maximum_practical();
        } catch (worker_unit) {
            accuracy_path.log("bg-tabs-init-ex", worker_unit);
        }
    }
    function return_list(system_server, shell_word) {
        if (system_server && system_server.data && system_server.data.windowId) {
            access_clock = system_server.data;
        } else {
            access_clock = null;
        }
        shell_word(true);
    }
    function repair_acceptor(system_server) {
        if (system_server && system_server.data && system_server.data.windowId) {
            store_abstractor.push(system_server.data.windowId);
        }
    }
    function modify_accountant(range_alarm) {
        chrome.tabs.get(range_alarm, function(values_architecture) {
            if (!chrome.runtime.lastError) {
                var gate_system = minimal_storage(values_architecture.id);
                timetable_query[values_architecture.id] = gate_system;
                gate_system.url = values_architecture.url;
                gate_system.title = values_architecture.title;
                gate_system.tabObj = values_architecture;
                read_abstractor(gate_system, gate_system.title);
                if (gate_system.url || gate_system.title) {
                    minimal_shell(gate_system);
                }
            }
        });
    }
    function calculate_handleA() {
        return new Promise(function(tool_model, accountant_configs) {
            var broker_index = {
                inactivityFlag: account_parameters.isUserIdle() ? 1 : 0,
                activeLPCount: shred_service()
            };
            build_access().then(function(tier_clock) {
                broker_index.allMinimized = tier_clock ? 1 : 0;
            }).catch(function() {
                broker_index.allMinimized = 0;
            }).then(function() {
                tool_model(broker_index);
            });
        });
    }
    function calculate_handle(gate_system) {
        return new Promise(function(tool_model) {
            var ticket_entry = {
                title: gate_system.title,
                tabId: gate_system.tabId,
                wnExpireAt: gate_system.wnExpireAt,
                wnDelayed: gate_system.wnDelayed,
                wn: gate_system.wn,
                tabObj: gate_system.tabObj,
                url: gate_system.url
            };
            chrome.windows.get(gate_system.tabObj.windowId, function(query_account) {
                if (!chrome.runtime.lastError) {
                    ticket_entry.wndObj = query_account;
                }
                tool_model(ticket_entry);
            });
        });
    }
    return {
        resetTabChangeCount: put_query,
        getDataForUserInactiveRequest: calculate_handleA,
        unsetWaitingForLpId: isbool_path,
        getTabIds: insert_service,
        getActiveTabData: calcandreturn_session,
        getTabData: throwback_abstractor,
        checkIsAdWindow: appear_session,
        getLastFocusedWindow: modify_tier,
        setWaitingForLpId: move_timetable,
        isWaitingForLpId: delete_index,
        init: calculate_power,
        getTabChangeCount: dig_mutex,
        addPinnedTab: isbool_alarm,
        getTabLpId: mount_tier
    };
});
