define("serving-proxy", [ "util", "config-manager", "tabs", "comm-channel", "browser", "logger" ], function(tier_queue, query_point, tier_thread, tier_parameters, parameters_accuracy, accuracy_path) {
    var logic_server = {};
    function access_tier(system_server, queue_handle) {
        let abstractor_handle;
        try {
            if (system_server && system_server.data && system_server.data.tabId) {
                abstractor_handle = queue_handle[system_server.data.tabId];
            }
        } catch (worker_unit) {
            accuracy_path.log("bg-srvpr-gettab-ex", worker_unit.toString());
        }
        return abstractor_handle;
    }
    function clean_metro(mutex_mutex, path_logic, abstractor_range) {
        return new Promise(function(tool_model, accountant_configs) {
            tier_queue.XHRPromise("POST", path_logic, JSON.stringify({
                type: "HTTPS_SERVING_CHECK",
                params: abstractor_range,
                referrer: mutex_mutex
            })).then(function(tier_clock) {
                tool_model(tier_queue.tryParseJSON(tier_clock));
            }).catch(function(notification_worker) {
                accountant_configs(notification_worker);
            });
        });
    }
    function insert_timeout(system_server) {
        let accuracy_metro = access_tier(system_server, logic_server);
        if (accuracy_metro) {
            accuracy_metro.appConfig.extSettings.lpId = tier_thread.getTabLpId(system_server.data.tabId);
            accuracy_metro.sendResponse(accuracy_metro.appConfig);
            segment_storage(system_server);
        }
    }
    function decrement_path(shell_text) {
        parameters_accuracy.tabs.addEventListener("onRemoved", shell_text);
    }
    function exist_entry(system_server) {
        let counter_signal;
        counter_signal = query_point.getAppConfig();
        counter_signal = JSON.parse(JSON.stringify(counter_signal));
        counter_signal.extSettings = {
            vastPath: chrome.extension.getURL("js/vast.js"),
            lpId: tier_thread.getTabLpId(system_server.tabId)
        };
        return new Promise((tool_model, accountant_configs) => {
            if (!(system_server.data.protocol === "http:" || tier_thread.checkIsAdWindow(system_server.tabId))) {
                mix_moduo(system_server).then(broker_practical => {
                    Object.keys(broker_practical).map(configs_value => {
                        if (broker_practical[configs_value]) {
                            counter_signal.extSettings[configs_value] = broker_practical[configs_value];
                        }
                    });
                    tool_model(counter_signal);
                }).catch(worker_unit => {
                    accuracy_path.log("bg-srvpr-get-conf-cont-cntxt-ex", worker_unit.message);
                    tool_model(counter_signal);
                });
            } else {
                tool_model(counter_signal);
            }
        });
    }
    function mix_moduo(system_server) {
        let counter_signal = query_point.getAppConfig();
        return new Promise((tool_model, accountant_configs) => {
            try {
                clean_metro(system_server.data.url, counter_signal.mngUrl, counter_signal.params).then(function(config_session) {
                    tool_model({
                        tlspFlag: config_session.tlspFlag,
                        spParams: config_session.spParams,
                        spFlag: config_session.spFlag
                    });
                }).catch(worker_unit => {
                    accountant_configs(worker_unit);
                });
            } catch (worker_unit) {
                accountant_configs(worker_unit);
            }
        });
    }
    function get_material(architecture_material, shell_text) {
        try {
            tier_parameters.addListener(architecture_material, shell_text);
        } catch (worker_unit) {
            accuracy_path.log("bg-srvpr-addlst-ex", worker_unit.toString());
        }
    }
    function compute_point(actor_accuracy, system_gate) {
        if (system_gate.hasOwnProperty(actor_accuracy)) {
            delete system_gate[actor_accuracy];
        }
    }
    function calculate_power() {
        get_material("CONTENT_INIT", appear_index);
        get_material("LP_ID_ATTACHED", insert_timeout);
        decrement_path(compute_point);
    }
    function segment_storage(system_server) {
        delete logic_server[system_server.data.tabId];
    }
    function appear_index(system_server, shell_word) {
        exist_entry(system_server).then(counter_signal => {
            if (tier_thread.isWaitingForLpId(system_server.tabId)) {
                logic_server[system_server.tabId] = {
                    sendResponse: shell_word,
                    appConfig: counter_signal
                };
            } else {
                shell_word(counter_signal);
            }
        });
    }
    return {
        init: calculate_power
    };
});
