define("frame-tracking", [ "comm-channel", "logger" ], function(tier_parameters, accuracy_path) {
    function repair_configs() {
        tier_parameters.addListener("FRAME_TRACKING", calculate_ticket);
    }
    function calculate_power() {
        repair_configs();
    }
    function calculate_ticket(point_members) {
        accuracy_path.log(point_members.data.name, point_members.data.message);
    }
    return {
        init: calculate_power
    };
});
define("Fingerprint2", function() {
    "use strict";
    var timetable_ticket = function(timeout_theme) {
        var name_timeout = {
            extendedJsFonts: true,
            swfContainerId: "fingerprintjs2",
            swfPath: "flash/compiled/FontList.swf"
        };
        this.options = this.extend(timeout_theme, name_timeout);
        this.nativeForEach = Array.prototype.forEach;
        this.nativeMap = Array.prototype.map;
    };
    timetable_ticket.prototype = {
        hasSessionStorage: function() {
            try {
                return !!window.sessionStorage;
            } catch (positive_signal) {
                return true;
            }
        },
        extend: function(timetable_clock, account_session) {
            if (timetable_clock == null) {
                return account_session;
            }
            for (var session_positive in timetable_clock) {
                if (timetable_clock[session_positive] != null && account_session[session_positive] !== timetable_clock[session_positive]) {
                    account_session[session_positive] = timetable_clock[session_positive];
                }
            }
            return account_session;
        },
        x64Xor: function(notification_point, actor_entry) {
            return [ notification_point[0] ^ actor_entry[0], notification_point[1] ^ actor_entry[1] ];
        },
        userAgentKey: function(name_word) {
            if (!this.options.excludeUserAgent) {
                name_word.push(this.getUserAgent());
            }
            return name_word;
        },
        hasMinFlashInstalled: function() {
            return swfobject.hasFlashPlayerVersion("9.0.0");
        },
        hasSwfObjectLoaded: function() {
            return typeof window.swfobject !== "undefined";
        },
        isIE: function() {
            if (navigator.appName === "Microsoft Internet Explorer") {
                return true;
            } else if (navigator.appName === "Netscape" && /Trident/.test(navigator.userAgent)) {
                return true;
            }
            return false;
        },
        isWebGlSupported: function() {
            if (!this.isCanvasSupported()) {
                return false;
            }
            var parameters_timetable = document.createElement("canvas"), acceptor_server;
            try {
                acceptor_server = parameters_timetable.getContext && (parameters_timetable.getContext("webgl") || parameters_timetable.getContext("experimental-webgl"));
            } catch (positive_signal) {
                acceptor_server = false;
            }
            return !!window.WebGLRenderingContext && !!acceptor_server;
        },
        getTouchSupport: function() {
            var query_service = 0;
            var tier_path = false;
            if (typeof navigator.maxTouchPoints !== "undefined") {
                query_service = navigator.maxTouchPoints;
            } else if (typeof navigator.msMaxTouchPoints !== "undefined") {
                query_service = navigator.msMaxTouchPoints;
            }
            try {
                document.createEvent("TouchEvent");
                tier_path = true;
            } catch (model_power) {}
            var worker_tool = "ontouchstart" in window;
            return [ query_service, tier_path, worker_tool ];
        },
        getNavigatorPlatform: function() {
            if (navigator.platform) {
                return navigator.platform;
            } else {
                return "NavigatorPlatform: unknown";
            }
        },
        pluginsKey: function(name_word) {
            if (!this.options.excludePlugins) {
                if (this.isIE()) {
                    name_word.push(this.getIEPluginsString());
                } else {
                    name_word.push(this.getRegularPluginsString());
                }
            }
            return name_word;
        },
        fontsKey: function(name_word) {
            if (!this.options.excludeFonts) {
                name_word.push(this.jsFontsKey());
            }
            return name_word;
        },
        hasLiedLanguagesKey: function(name_word) {
            if (!this.options.excludeHasLiedLanguages) {
                name_word.push(this.getHasLiedLanguages());
            }
            return name_word;
        },
        openDatabaseKey: function(name_word) {
            if (!this.options.excludeOpenDatabase && window.openDatabase) {
                name_word.push("openDatabase");
            }
            return name_word;
        },
        canvasKey: function(name_word) {
            if (!this.options.excludeCanvas && this.isCanvasSupported()) {
                name_word.push(this.getCanvasFp());
            }
            return name_word;
        },
        platformKey: function(name_word) {
            if (!this.options.excludePlatform) {
                name_word.push(this.getNavigatorPlatform());
            }
            return name_word;
        },
        getHasLiedLanguages: function() {
            if (typeof navigator.languages !== "undefined") {
                try {
                    var model_practical = navigator.languages[0].substr(0, 2);
                    if (model_practical !== navigator.language.substr(0, 2)) {
                        return true;
                    }
                } catch (broker_parameters) {
                    return true;
                }
            }
            return false;
        },
        x64hash128: function(parameters_power, counter_architecture) {
            parameters_power = parameters_power || "";
            counter_architecture = counter_architecture || 0;
            var accountant_entry = parameters_power.length % 16;
            var practical_handle = parameters_power.length - accountant_entry;
            var gate_timeout = [ 0, counter_architecture ];
            var thread_range = [ 0, counter_architecture ];
            var acceptor_accuracy = [ 0, 0 ];
            var notification_project = [ 0, 0 ];
            var mutex_session = [ 2277735313, 289559509 ];
            var tier_gate = [ 1291169091, 658871167 ];
            for (var shell_parameters = 0; shell_parameters < practical_handle; shell_parameters = shell_parameters + 16) {
                acceptor_accuracy = [ parameters_power.charCodeAt(shell_parameters + 4) & 255 | (parameters_power.charCodeAt(shell_parameters + 5) & 255) << 8 | (parameters_power.charCodeAt(shell_parameters + 6) & 255) << 16 | (parameters_power.charCodeAt(shell_parameters + 7) & 255) << 24, parameters_power.charCodeAt(shell_parameters) & 255 | (parameters_power.charCodeAt(shell_parameters + 1) & 255) << 8 | (parameters_power.charCodeAt(shell_parameters + 2) & 255) << 16 | (parameters_power.charCodeAt(shell_parameters + 3) & 255) << 24 ];
                notification_project = [ parameters_power.charCodeAt(shell_parameters + 12) & 255 | (parameters_power.charCodeAt(shell_parameters + 13) & 255) << 8 | (parameters_power.charCodeAt(shell_parameters + 14) & 255) << 16 | (parameters_power.charCodeAt(shell_parameters + 15) & 255) << 24, parameters_power.charCodeAt(shell_parameters + 8) & 255 | (parameters_power.charCodeAt(shell_parameters + 9) & 255) << 8 | (parameters_power.charCodeAt(shell_parameters + 10) & 255) << 16 | (parameters_power.charCodeAt(shell_parameters + 11) & 255) << 24 ];
                acceptor_accuracy = this.x64Multiply(acceptor_accuracy, mutex_session);
                acceptor_accuracy = this.x64Rotl(acceptor_accuracy, 31);
                acceptor_accuracy = this.x64Multiply(acceptor_accuracy, tier_gate);
                gate_timeout = this.x64Xor(gate_timeout, acceptor_accuracy);
                gate_timeout = this.x64Rotl(gate_timeout, 27);
                gate_timeout = this.x64Add(gate_timeout, thread_range);
                gate_timeout = this.x64Add(this.x64Multiply(gate_timeout, [ 0, 5 ]), [ 0, 1390208809 ]);
                notification_project = this.x64Multiply(notification_project, tier_gate);
                notification_project = this.x64Rotl(notification_project, 33);
                notification_project = this.x64Multiply(notification_project, mutex_session);
                thread_range = this.x64Xor(thread_range, notification_project);
                thread_range = this.x64Rotl(thread_range, 31);
                thread_range = this.x64Add(thread_range, gate_timeout);
                thread_range = this.x64Add(this.x64Multiply(thread_range, [ 0, 5 ]), [ 0, 944331445 ]);
            }
            acceptor_accuracy = [ 0, 0 ];
            notification_project = [ 0, 0 ];
            switch (accountant_entry) {
              case 15:
                notification_project = this.x64Xor(notification_project, this.x64LeftShift([ 0, parameters_power.charCodeAt(shell_parameters + 14) ], 48));

              case 14:
                notification_project = this.x64Xor(notification_project, this.x64LeftShift([ 0, parameters_power.charCodeAt(shell_parameters + 13) ], 40));

              case 13:
                notification_project = this.x64Xor(notification_project, this.x64LeftShift([ 0, parameters_power.charCodeAt(shell_parameters + 12) ], 32));

              case 12:
                notification_project = this.x64Xor(notification_project, this.x64LeftShift([ 0, parameters_power.charCodeAt(shell_parameters + 11) ], 24));

              case 11:
                notification_project = this.x64Xor(notification_project, this.x64LeftShift([ 0, parameters_power.charCodeAt(shell_parameters + 10) ], 16));

              case 10:
                notification_project = this.x64Xor(notification_project, this.x64LeftShift([ 0, parameters_power.charCodeAt(shell_parameters + 9) ], 8));

              case 9:
                notification_project = this.x64Xor(notification_project, [ 0, parameters_power.charCodeAt(shell_parameters + 8) ]);
                notification_project = this.x64Multiply(notification_project, tier_gate);
                notification_project = this.x64Rotl(notification_project, 33);
                notification_project = this.x64Multiply(notification_project, mutex_session);
                thread_range = this.x64Xor(thread_range, notification_project);

              case 8:
                acceptor_accuracy = this.x64Xor(acceptor_accuracy, this.x64LeftShift([ 0, parameters_power.charCodeAt(shell_parameters + 7) ], 56));

              case 7:
                acceptor_accuracy = this.x64Xor(acceptor_accuracy, this.x64LeftShift([ 0, parameters_power.charCodeAt(shell_parameters + 6) ], 48));

              case 6:
                acceptor_accuracy = this.x64Xor(acceptor_accuracy, this.x64LeftShift([ 0, parameters_power.charCodeAt(shell_parameters + 5) ], 40));

              case 5:
                acceptor_accuracy = this.x64Xor(acceptor_accuracy, this.x64LeftShift([ 0, parameters_power.charCodeAt(shell_parameters + 4) ], 32));

              case 4:
                acceptor_accuracy = this.x64Xor(acceptor_accuracy, this.x64LeftShift([ 0, parameters_power.charCodeAt(shell_parameters + 3) ], 24));

              case 3:
                acceptor_accuracy = this.x64Xor(acceptor_accuracy, this.x64LeftShift([ 0, parameters_power.charCodeAt(shell_parameters + 2) ], 16));

              case 2:
                acceptor_accuracy = this.x64Xor(acceptor_accuracy, this.x64LeftShift([ 0, parameters_power.charCodeAt(shell_parameters + 1) ], 8));

              case 1:
                acceptor_accuracy = this.x64Xor(acceptor_accuracy, [ 0, parameters_power.charCodeAt(shell_parameters) ]);
                acceptor_accuracy = this.x64Multiply(acceptor_accuracy, mutex_session);
                acceptor_accuracy = this.x64Rotl(acceptor_accuracy, 31);
                acceptor_accuracy = this.x64Multiply(acceptor_accuracy, tier_gate);
                gate_timeout = this.x64Xor(gate_timeout, acceptor_accuracy);
            }
            gate_timeout = this.x64Xor(gate_timeout, [ 0, parameters_power.length ]);
            thread_range = this.x64Xor(thread_range, [ 0, parameters_power.length ]);
            gate_timeout = this.x64Add(gate_timeout, thread_range);
            thread_range = this.x64Add(thread_range, gate_timeout);
            gate_timeout = this.x64Fmix(gate_timeout);
            thread_range = this.x64Fmix(thread_range);
            gate_timeout = this.x64Add(gate_timeout, thread_range);
            thread_range = this.x64Add(thread_range, gate_timeout);
            return ("00000000" + (gate_timeout[0] >>> 0).toString(16)).slice(-8) + ("00000000" + (gate_timeout[1] >>> 0).toString(16)).slice(-8) + ("00000000" + (thread_range[0] >>> 0).toString(16)).slice(-8) + ("00000000" + (thread_range[1] >>> 0).toString(16)).slice(-8);
        },
        webglKey: function(name_word) {
            if (this.options.excludeWebGL) {
                if (typeof NODEBUG === "undefined") {
                    this.log("Skipping WebGL fingerprinting per excludeWebGL configuration option");
                }
                return name_word;
            }
            if (!this.isWebGlSupported()) {
                if (typeof NODEBUG === "undefined") {
                    this.log("Skipping WebGL fingerprinting because it is not supported in this browser");
                }
                return name_word;
            }
            name_word.push(this.getWebglFp());
            return name_word;
        },
        indexedDbKey: function(name_word) {
            if (!this.options.excludeIndexedDB && this.hasIndexedDB()) {
                name_word.push("indexedDbKey");
            }
            return name_word;
        },
        x64Add: function(notification_point, actor_entry) {
            notification_point = [ notification_point[0] >>> 16, notification_point[0] & 65535, notification_point[1] >>> 16, notification_point[1] & 65535 ];
            actor_entry = [ actor_entry[0] >>> 16, actor_entry[0] & 65535, actor_entry[1] >>> 16, actor_entry[1] & 65535 ];
            var point_thread = [ 0, 0, 0, 0 ];
            point_thread[3] += notification_point[3] + actor_entry[3];
            point_thread[2] += point_thread[3] >>> 16;
            point_thread[3] &= 65535;
            point_thread[2] += notification_point[2] + actor_entry[2];
            point_thread[1] += point_thread[2] >>> 16;
            point_thread[2] &= 65535;
            point_thread[1] += notification_point[1] + actor_entry[1];
            point_thread[0] += point_thread[1] >>> 16;
            point_thread[1] &= 65535;
            point_thread[0] += notification_point[0] + actor_entry[0];
            point_thread[0] &= 65535;
            return [ point_thread[0] << 16 | point_thread[1], point_thread[2] << 16 | point_thread[3] ];
        },
        each: function(power_architecture, session_material, abstractor_index) {
            if (power_architecture === null) {
                return;
            }
            if (this.nativeForEach && power_architecture.forEach === this.nativeForEach) {
                power_architecture.forEach(session_material, abstractor_index);
            } else if (power_architecture.length === +power_architecture.length) {
                for (var shell_parameters = 0, parameters_text = power_architecture.length; shell_parameters < parameters_text; shell_parameters++) {
                    if (session_material.call(abstractor_index, power_architecture[shell_parameters], shell_parameters, power_architecture) === {}) {
                        return;
                    }
                }
            } else {
                for (var parameters_power in power_architecture) {
                    if (power_architecture.hasOwnProperty(parameters_power)) {
                        if (session_material.call(abstractor_index, power_architecture[parameters_power], parameters_power, power_architecture) === {}) {
                            return;
                        }
                    }
                }
            }
        },
        hasLiedBrowserKey: function(name_word) {
            if (!this.options.excludeHasLiedBrowser) {
                name_word.push(this.getHasLiedBrowser());
            }
            return name_word;
        },
        localStorageKey: function(name_word) {
            if (!this.options.excludeSessionStorage && this.hasLocalStorage()) {
                name_word.push("localStorageKey");
            }
            return name_word;
        },
        jsFontsKey: function() {
            var clock_actor = this;
            var alarm_practical = "mmmmmmmmmmlli";
            var account_accountant = [ "fantasy", "cursive" ];
            var handle_value = "72px";
            var notification_ticket = document.getElementsByTagName("body")[0];
            var mutex_tool = document.createElement("span");
            mutex_tool.style.position = "absolute";
            mutex_tool.style.left = "-9999px";
            mutex_tool.style.fontSize = handle_value;
            mutex_tool.innerHTML = alarm_practical;
            var values_clock = {};
            var actor_positive = {};
            for (var accuracy_model = 0, positive_notification = account_accountant.length; accuracy_model < positive_notification; accuracy_model++) {
                mutex_tool.style.fontFamily = account_accountant[accuracy_model];
                if (document.body.nodeName.toUpperCase() == "FRAMESET") {
                    document.documentElement.insertBefore(mutex_tool, document.body);
                } else {
                    notification_ticket.appendChild(mutex_tool);
                }
                values_clock[account_accountant[accuracy_model]] = mutex_tool.offsetWidth;
                actor_positive[account_accountant[accuracy_model]] = mutex_tool.offsetHeight;
                if (document.body.nodeName.toUpperCase() == "FRAMESET") {
                    document.documentElement.removeChild(mutex_tool);
                } else {
                    notification_ticket.removeChild(mutex_tool);
                }
            }
            var name_range = function(practical_material) {
                var value_text = false;
                for (var accuracy_model = 0, parameters_text = account_accountant.length; accuracy_model < parameters_text; accuracy_model++) {
                    mutex_tool.style.fontFamily = practical_material + "," + account_accountant[accuracy_model];
                    if (document.body.nodeName.toUpperCase() == "FRAMESET") {
                        document.documentElement.insertBefore(mutex_tool, document.body);
                    } else {
                        notification_ticket.appendChild(mutex_tool);
                    }
                    var point_range = mutex_tool.offsetWidth !== values_clock[account_accountant[accuracy_model]] || mutex_tool.offsetHeight !== actor_positive[account_accountant[accuracy_model]];
                    if (document.body.nodeName.toUpperCase() == "FRAMESET") {
                        document.documentElement.removeChild(mutex_tool);
                    } else {
                        notification_ticket.removeChild(mutex_tool);
                    }
                    value_text = value_text || point_range;
                    if (value_text) {
                        break;
                    }
                }
                return value_text;
            };
            var mutex_account = [ "Andale Mono", "Arial", "Arial Black", "Arial Hebrew", "Arial MT", "Arial Narrow", "Arial Rounded MT Bold", "Arial Unicode MS", "Bitstream Vera Sans Mono", "Book Antiqua", "Bookman Old Style", "Calibri", "Cambria", "Cambria Math", "Century", "Century Gothic", "Century Schoolbook", "Comic Sans", "Comic Sans MS", "Consolas", "Courier", "Courier New", "Garamond", "Geneva", "Georgia", "Helvetica", "Helvetica Neue", "Impact", "Lucida Bright", "Lucida Calligraphy", "Lucida Console", "Lucida Fax", "LUCIDA GRANDE", "Lucida Handwriting", "Lucida Sans", "Lucida Sans Typewriter", "Lucida Sans Unicode", "Microsoft Sans Serif", "Monaco", "Monotype Corsiva", "MS Gothic", "MS Outlook", "MS PGothic", "MS Reference Sans Serif", "MS Sans Serif", "MS Serif", "MYRIAD", "MYRIAD PRO", "Palatino", "Palatino Linotype", "Segoe Print", "Segoe Script", "Segoe UI", "Segoe UI Light", "Segoe UI Semibold", "Segoe UI Symbol", "Tahoma", "Times", "Times New Roman", "Times New Roman PS", "Trebuchet MS", "Verdana", "Wingdings", "Wingdings 2", "Wingdings 3" ];
            var metro_project = [ "Abadi MT Condensed Light", "Academy Engraved LET", "ADOBE CASLON PRO", "Adobe Garamond", "ADOBE GARAMOND PRO", "Agency FB", "Aharoni", "Albertus Extra Bold", "Albertus Medium", "Algerian", "Amazone BT", "American Typewriter", "American Typewriter Condensed", "AmerType Md BT", "Andalus", "Angsana New", "AngsanaUPC", "Antique Olive", "Aparajita", "Apple Chancery", "Apple Color Emoji", "Apple SD Gothic Neo", "Arabic Typesetting", "ARCHER", "ARNO PRO", "Arrus BT", "Aurora Cn BT", "AvantGarde Bk BT", "AvantGarde Md BT", "AVENIR", "Ayuthaya", "Bandy", "Bangla Sangam MN", "Bank Gothic", "BankGothic Md BT", "Baskerville", "Baskerville Old Face", "Batang", "BatangChe", "Bauer Bodoni", "Bauhaus 93", "Bazooka", "Bell MT", "Bembo", "Benguiat Bk BT", "Berlin Sans FB", "Berlin Sans FB Demi", "Bernard MT Condensed", "BernhardFashion BT", "BernhardMod BT", "Big Caslon", "BinnerD", "Blackadder ITC", "BlairMdITC TT", "Bodoni 72", "Bodoni 72 Oldstyle", "Bodoni 72 Smallcaps", "Bodoni MT", "Bodoni MT Black", "Bodoni MT Condensed", "Bodoni MT Poster Compressed", "Bookshelf Symbol 7", "Boulder", "Bradley Hand", "Bradley Hand ITC", "Bremen Bd BT", "Britannic Bold", "Broadway", "Browallia New", "BrowalliaUPC", "Brush Script MT", "Californian FB", "Calisto MT", "Calligrapher", "Candara", "CaslonOpnface BT", "Castellar", "Centaur", "Cezanne", "CG Omega", "CG Times", "Chalkboard", "Chalkboard SE", "Chalkduster", "Charlesworth", "Charter Bd BT", "Charter BT", "Chaucer", "ChelthmITC Bk BT", "Chiller", "Clarendon", "Clarendon Condensed", "CloisterBlack BT", "Cochin", "Colonna MT", "Constantia", "Cooper Black", "Copperplate", "Copperplate Gothic", "Copperplate Gothic Bold", "Copperplate Gothic Light", "CopperplGoth Bd BT", "Corbel", "Cordia New", "CordiaUPC", "Cornerstone", "Coronet", "Cuckoo", "Curlz MT", "DaunPenh", "Dauphin", "David", "DB LCD Temp", "DELICIOUS", "Denmark", "DFKai-SB", "Didot", "DilleniaUPC", "DIN", "DokChampa", "Dotum", "DotumChe", "Ebrima", "Edwardian Script ITC", "Elephant", "English 111 Vivace BT", "Engravers MT", "EngraversGothic BT", "Eras Bold ITC", "Eras Demi ITC", "Eras Light ITC", "Eras Medium ITC", "EucrosiaUPC", "Euphemia", "Euphemia UCAS", "EUROSTILE", "Exotc350 Bd BT", "FangSong", "Felix Titling", "Fixedsys", "FONTIN", "Footlight MT Light", "Forte", "FrankRuehl", "Fransiscan", "Freefrm721 Blk BT", "FreesiaUPC", "Freestyle Script", "French Script MT", "FrnkGothITC Bk BT", "Fruitger", "FRUTIGER", "Futura", "Futura Bk BT", "Futura Lt BT", "Futura Md BT", "Futura ZBlk BT", "FuturaBlack BT", "Gabriola", "Galliard BT", "Gautami", "Geeza Pro", "Geometr231 BT", "Geometr231 Hv BT", "Geometr231 Lt BT", "GeoSlab 703 Lt BT", "GeoSlab 703 XBd BT", "Gigi", "Gill Sans", "Gill Sans MT", "Gill Sans MT Condensed", "Gill Sans MT Ext Condensed Bold", "Gill Sans Ultra Bold", "Gill Sans Ultra Bold Condensed", "Gisha", "Gloucester MT Extra Condensed", "GOTHAM", "GOTHAM BOLD", "Goudy Old Style", "Goudy Stout", "GoudyHandtooled BT", "GoudyOLSt BT", "Gujarati Sangam MN", "Gulim", "GulimChe", "Gungsuh", "GungsuhChe", "Gurmukhi MN", "Haettenschweiler", "Harlow Solid Italic", "Harrington", "Heather", "Heiti SC", "Heiti TC", "HELV", "Herald", "High Tower Text", "Hiragino Kaku Gothic ProN", "Hiragino Mincho ProN", "Hoefler Text", "Humanst 521 Cn BT", "Humanst521 BT", "Humanst521 Lt BT", "Imprint MT Shadow", "Incised901 Bd BT", "Incised901 BT", "Incised901 Lt BT", "INCONSOLATA", "Informal Roman", "Informal011 BT", "INTERSTATE", "IrisUPC", "Iskoola Pota", "JasmineUPC", "Jazz LET", "Jenson", "Jester", "Jokerman", "Juice ITC", "Kabel Bk BT", "Kabel Ult BT", "Kailasa", "KaiTi", "Kalinga", "Kannada Sangam MN", "Kartika", "Kaufmann Bd BT", "Kaufmann BT", "Khmer UI", "KodchiangUPC", "Kokila", "Korinna BT", "Kristen ITC", "Krungthep", "Kunstler Script", "Lao UI", "Latha", "Leelawadee", "Letter Gothic", "Levenim MT", "LilyUPC", "Lithograph", "Lithograph Light", "Long Island", "Lydian BT", "Magneto", "Maiandra GD", "Malayalam Sangam MN", "Malgun Gothic", "Mangal", "Marigold", "Marion", "Marker Felt", "Market", "Marlett", "Matisse ITC", "Matura MT Script Capitals", "Meiryo", "Meiryo UI", "Microsoft Himalaya", "Microsoft JhengHei", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Uighur", "Microsoft YaHei", "Microsoft Yi Baiti", "MingLiU", "MingLiU_HKSCS", "MingLiU_HKSCS-ExtB", "MingLiU-ExtB", "Minion", "Minion Pro", "Miriam", "Miriam Fixed", "Mistral", "Modern", "Modern No. 20", "Mona Lisa Solid ITC TT", "Mongolian Baiti", "MONO", "MoolBoran", "Mrs Eaves", "MS LineDraw", "MS Mincho", "MS PMincho", "MS Reference Specialty", "MS UI Gothic", "MT Extra", "MUSEO", "MV Boli", "Nadeem", "Narkisim", "NEVIS", "News Gothic", "News GothicMT", "NewsGoth BT", "Niagara Engraved", "Niagara Solid", "Noteworthy", "NSimSun", "Nyala", "OCR A Extended", "Old Century", "Old English Text MT", "Onyx", "Onyx BT", "OPTIMA", "Oriya Sangam MN", "OSAKA", "OzHandicraft BT", "Palace Script MT", "Papyrus", "Parchment", "Party LET", "Pegasus", "Perpetua", "Perpetua Titling MT", "PetitaBold", "Pickwick", "Plantagenet Cherokee", "Playbill", "PMingLiU", "PMingLiU-ExtB", "Poor Richard", "Poster", "PosterBodoni BT", "PRINCETOWN LET", "Pristina", "PTBarnum BT", "Pythagoras", "Raavi", "Rage Italic", "Ravie", "Ribbon131 Bd BT", "Rockwell", "Rockwell Condensed", "Rockwell Extra Bold", "Rod", "Roman", "Sakkal Majalla", "Santa Fe LET", "Savoye LET", "Sceptre", "Script", "Script MT Bold", "SCRIPTINA", "Serifa", "Serifa BT", "Serifa Th BT", "ShelleyVolante BT", "Sherwood", "Shonar Bangla", "Showcard Gothic", "Shruti", "Signboard", "SILKSCREEN", "SimHei", "Simplified Arabic", "Simplified Arabic Fixed", "SimSun", "SimSun-ExtB", "Sinhala Sangam MN", "Sketch Rockwell", "Skia", "Small Fonts", "Snap ITC", "Snell Roundhand", "Socket", "Souvenir Lt BT", "Staccato222 BT", "Steamer", "Stencil", "Storybook", "Styllo", "Subway", "Swis721 BlkEx BT", "Swiss911 XCm BT", "Sylfaen", "Synchro LET", "System", "Tamil Sangam MN", "Technical", "Teletype", "Telugu Sangam MN", "Tempus Sans ITC", "Terminal", "Thonburi", "Traditional Arabic", "Trajan", "TRAJAN PRO", "Tristan", "Tubular", "Tunga", "Tw Cen MT", "Tw Cen MT Condensed", "Tw Cen MT Condensed Extra Bold", "TypoUpright BT", "Unicorn", "Univers", "Univers CE 55 Medium", "Univers Condensed", "Utsaah", "Vagabond", "Vani", "Vijaya", "Viner Hand ITC", "VisualUI", "Vivaldi", "Vladimir Script", "Vrinda", "Westminster", "WHITNEY", "Wide Latin", "ZapfEllipt BT", "ZapfHumnst BT", "ZapfHumnst Dm BT", "Zapfino", "Zurich BlkEx BT", "Zurich Ex BT", "ZWAdobeF" ];
            if (clock_actor.options.extendedJsFonts) {
                mutex_account = mutex_account.concat(metro_project);
            }
            var service_mutex = [];
            for (var shell_parameters = 0, parameters_text = mutex_account.length; shell_parameters < parameters_text; shell_parameters++) {
                if (name_range(mutex_account[shell_parameters])) {
                    service_mutex.push(mutex_account[shell_parameters]);
                }
            }
            return service_mutex.join(";");
        },
        loadSwfAndDetectFonts: function(clock_broker) {
            var gate_server = "___fp_swf_loaded";
            window[gate_server] = function(accuracy_store) {
                clock_broker(accuracy_store);
            };
            var list_parameters = this.options.swfContainerId;
            this.addFlashDivNode();
            var list_text = {
                onReady: gate_server
            };
            var server_ticket = {
                allowScriptAccess: "always",
                menu: "false"
            };
            swfobject.embedSWF(this.options.swfPath, list_parameters, "1", "1", "9.0.0", false, list_text, server_ticket, {});
        },
        getUserAgent: function() {
            return navigator.userAgent;
        },
        languageKey: function(name_word) {
            if (!this.options.excludeLanguage) {
                name_word.push(navigator.language);
            }
            return name_word;
        },
        getHasLiedOs: function() {
            var thread_logic = navigator.userAgent.toLowerCase();
            var list_mutex = navigator.oscpu;
            var shell_path = navigator.platform.toLowerCase();
            var members_queue;
            if (thread_logic.indexOf("windows phone") >= 0) {
                members_queue = "Windows Phone";
            } else if (thread_logic.indexOf("win") >= 0) {
                members_queue = "Windows";
            } else if (thread_logic.indexOf("android") >= 0) {
                members_queue = "Android";
            } else if (thread_logic.indexOf("linux") >= 0) {
                members_queue = "Linux";
            } else if (thread_logic.indexOf("iphone") >= 0 || thread_logic.indexOf("ipad") >= 0) {
                members_queue = "iOS";
            } else if (thread_logic.indexOf("mac") >= 0) {
                members_queue = "Mac";
            } else {
                members_queue = "Other";
            }
            var parameters_storage;
            if ("ontouchstart" in window || navigator.maxTouchPoints > 0 || navigator.msMaxTouchPoints > 0) {
                parameters_storage = true;
            } else {
                parameters_storage = false;
            }
            if (parameters_storage && members_queue !== "Windows Phone" && members_queue !== "Android" && members_queue !== "iOS" && members_queue !== "Other") {
                return true;
            }
            if (typeof list_mutex !== "undefined") {
                list_mutex = list_mutex.toLowerCase();
                if (list_mutex.indexOf("win") >= 0 && members_queue !== "Windows" && members_queue !== "Windows Phone") {
                    return true;
                } else if (list_mutex.indexOf("linux") >= 0 && members_queue !== "Linux" && members_queue !== "Android") {
                    return true;
                } else if (list_mutex.indexOf("mac") >= 0 && members_queue !== "Mac" && members_queue !== "iOS") {
                    return true;
                } else if (list_mutex.indexOf("win") === 0 && list_mutex.indexOf("linux") === 0 && list_mutex.indexOf("mac") >= 0 && members_queue !== "other") {
                    return true;
                }
            }
            if (shell_path.indexOf("win") >= 0 && members_queue !== "Windows" && members_queue !== "Windows Phone") {
                return true;
            } else if ((shell_path.indexOf("linux") >= 0 || shell_path.indexOf("android") >= 0 || shell_path.indexOf("pike") >= 0) && members_queue !== "Linux" && members_queue !== "Android") {
                return true;
            } else if ((shell_path.indexOf("mac") >= 0 || shell_path.indexOf("ipad") >= 0 || shell_path.indexOf("ipod") >= 0 || shell_path.indexOf("iphone") >= 0) && members_queue !== "Mac" && members_queue !== "iOS") {
                return true;
            } else if (shell_path.indexOf("win") === 0 && shell_path.indexOf("linux") === 0 && shell_path.indexOf("mac") >= 0 && members_queue !== "other") {
                return true;
            }
            if (typeof navigator.plugins === "undefined" && members_queue !== "Windows" && members_queue !== "Windows Phone") {
                return true;
            }
            return false;
        },
        hasLocalStorage: function() {
            try {
                return !!window.localStorage;
            } catch (positive_signal) {
                return true;
            }
        },
        cpuClassKey: function(name_word) {
            if (!this.options.excludeCpuClass) {
                name_word.push(this.getNavigatorCpuClass());
            }
            return name_word;
        },
        getCanvasFp: function() {
            var tier_clock = [];
            var parameters_timetable = document.createElement("canvas");
            parameters_timetable.width = 2e3;
            parameters_timetable.height = 200;
            parameters_timetable.style.display = "inline";
            var service_account = parameters_timetable.getContext("2d");
            service_account.rect(0, 0, 10, 10);
            service_account.rect(2, 2, 6, 6);
            tier_clock.push("canvas winding:" + (service_account.isPointInPath(5, 5, "evenodd") === false ? "yes" : "no"));
            service_account.textBaseline = "alphabetic";
            service_account.fillStyle = "#f60";
            service_account.fillRect(125, 1, 62, 20);
            service_account.fillStyle = "#069";
            if (this.options.dontUseFakeFontInCanvas) {
                service_account.font = "11pt Arial";
            } else {
                service_account.font = "11pt no-real-font-123";
            }
            service_account.fillText("Cwm fjordbank glyphs vext quiz, 😃", 2, 15);
            service_account.fillStyle = "rgba(102, 204, 0, 0.7)";
            service_account.font = "18pt Arial";
            service_account.fillText("Cwm fjordbank glyphs vext quiz, 😃", 4, 45);
            service_account.globalCompositeOperation = "multiply";
            service_account.fillStyle = "rgb(255,0,255)";
            service_account.beginPath();
            service_account.arc(50, 50, 50, 0, Math.PI * 2, true);
            service_account.closePath();
            service_account.fill();
            service_account.fillStyle = "rgb(0,255,255)";
            service_account.beginPath();
            service_account.arc(100, 50, 50, 0, Math.PI * 2, true);
            service_account.closePath();
            service_account.fill();
            service_account.fillStyle = "rgb(255,255,0)";
            service_account.beginPath();
            service_account.arc(75, 100, 50, 0, Math.PI * 2, true);
            service_account.closePath();
            service_account.fill();
            service_account.fillStyle = "rgb(255,0,255)";
            service_account.arc(75, 75, 75, 0, Math.PI * 2, true);
            service_account.arc(75, 75, 25, 0, Math.PI * 2, true);
            service_account.fill("evenodd");
            tier_clock.push("canvas fp:" + parameters_timetable.toDataURL());
            return tier_clock.join("~");
        },
        getNavigatorCpuClass: function() {
            if (navigator.cpuClass) {
                return navigator.cpuClass;
            } else if (navigator.hardwareConcurrency) {
                return navigator.hardwareConcurrency;
            } else {
                return "NavigatorCpuClass: unknown";
            }
        },
        getIEPluginsString: function() {
            if (window.ActiveXObject) {
                var thread_metro = [ "AcroPDF.PDF", "Adodb.Stream", "AgControl.AgControl", "DevalVRXCtrl.DevalVRXCtrl.1", "MacromediaFlashPaper.MacromediaFlashPaper", "Msxml2.DOMDocument", "Msxml2.XMLHTTP", "PDF.PdfCtrl", "QuickTime.QuickTime", "QuickTimeCheckObject.QuickTimeCheck.1", "RealPlayer", "RealPlayer.RealPlayer(tm) ActiveX Control (32-bit)", "RealVideo.RealVideo(tm) ActiveX Control (32-bit)", "Scripting.Dictionary", "SWCtl.SWCtl", "Shell.UIHelper", "ShockwaveFlash.ShockwaveFlash", "Skype.Detection", "TDCCtl.TDCCtl", "WMPlayer.OCX", "rmocx.RealPlayer G2 Control", "rmocx.RealPlayer G2 Control.1" ];
                return this.map(thread_metro, function(point_storage) {
                    try {
                        new ActiveXObject(point_storage);
                        return point_storage;
                    } catch (positive_signal) {
                        return null;
                    }
                }).join(";");
            } else {
                return "";
            }
        },
        doNotTrackKey: function(name_word) {
            if (!this.options.excludeDoNotTrack) {
                name_word.push(this.getDoNotTrack());
            }
            return name_word;
        },
        x64LeftShift: function(storage_members, architecture_tool) {
            architecture_tool %= 64;
            if (architecture_tool === 0) {
                return storage_members;
            } else if (architecture_tool < 32) {
                return [ storage_members[0] << architecture_tool | storage_members[1] >>> 32 - architecture_tool, storage_members[1] << architecture_tool ];
            } else {
                return [ storage_members[1] << architecture_tool - 32, 0 ];
            }
        },
        colorDepthKey: function(name_word) {
            if (!this.options.excludeColorDepth) {
                name_word.push(screen.colorDepth);
            }
            return name_word;
        },
        addFlashDivNode: function() {
            var members_model = document.createElement("div");
            members_model.setAttribute("id", this.options.swfContainerId);
            if (document.body.nodeName.toUpperCase() == "FRAMESET") {
                document.documentElement.insertBefore(members_model, document.body);
            } else {
                document.body.appendChild(members_model);
            }
        },
        getWebglFp: function() {
            var service_accountant;
            var query_values = function(account_theme) {
                service_accountant.clearColor(0, 0, 0, 1);
                service_accountant.enable(service_accountant.DEPTH_TEST);
                service_accountant.depthFunc(service_accountant.LEQUAL);
                service_accountant.clear(service_accountant.COLOR_BUFFER_BIT | service_accountant.DEPTH_BUFFER_BIT);
                return "[" + account_theme[0] + ", " + account_theme[1] + "]";
            };
            var moduo_entry = function(service_accountant) {
                var abstractor_tool, accountant_clock = service_accountant.getExtension("EXT_texture_filter_anisotropic") || service_accountant.getExtension("WEBKIT_EXT_texture_filter_anisotropic") || service_accountant.getExtension("MOZ_EXT_texture_filter_anisotropic");
                return accountant_clock ? (abstractor_tool = service_accountant.getParameter(accountant_clock.MAX_TEXTURE_MAX_ANISOTROPY_EXT), 
                0 === abstractor_tool && (abstractor_tool = 2), abstractor_tool) : null;
            };
            service_accountant = this.getWebglCanvas();
            if (!service_accountant) {
                return null;
            }
            var tier_clock = [];
            var gate_accuracy = "attribute vec2 attrVertex;varying vec2 varyinTexCoordinate;uniform vec2 uniformOffset;void main(){varyinTexCoordinate=attrVertex+uniformOffset;gl_Position=vec4(attrVertex,0,1);}";
            var path_clock = "precision mediump float;varying vec2 varyinTexCoordinate;void main() {gl_FragColor=vec4(varyinTexCoordinate,0,1);}";
            var entry_architecture = service_accountant.createBuffer();
            service_accountant.bindBuffer(service_accountant.ARRAY_BUFFER, entry_architecture);
            var index_accountant = new Float32Array([ -.2, -.9, 0, .4, -.26, 0, 0, .732134444, 0 ]);
            service_accountant.bufferData(service_accountant.ARRAY_BUFFER, index_accountant, service_accountant.STATIC_DRAW);
            entry_architecture.itemSize = 3;
            entry_architecture.numItems = 3;
            var model_signal = service_accountant.createProgram(), point_worker = service_accountant.createShader(service_accountant.VERTEX_SHADER);
            service_accountant.shaderSource(point_worker, gate_accuracy);
            service_accountant.compileShader(point_worker);
            var clock_power = service_accountant.createShader(service_accountant.FRAGMENT_SHADER);
            service_accountant.shaderSource(clock_power, path_clock);
            service_accountant.compileShader(clock_power);
            service_accountant.attachShader(model_signal, point_worker);
            service_accountant.attachShader(model_signal, clock_power);
            service_accountant.linkProgram(model_signal);
            service_accountant.useProgram(model_signal);
            model_signal.vertexPosAttrib = service_accountant.getAttribLocation(model_signal, "attrVertex");
            model_signal.offsetUniform = service_accountant.getUniformLocation(model_signal, "uniformOffset");
            service_accountant.enableVertexAttribArray(model_signal.vertexPosArray);
            service_accountant.vertexAttribPointer(model_signal.vertexPosAttrib, entry_architecture.itemSize, service_accountant.FLOAT, !1, 0, 0);
            service_accountant.uniform2f(model_signal.offsetUniform, 1, 1);
            service_accountant.drawArrays(service_accountant.TRIANGLE_STRIP, 0, entry_architecture.numItems);
            if (service_accountant.canvas != null) {
                tier_clock.push(service_accountant.canvas.toDataURL());
            }
            tier_clock.push("extensions:" + service_accountant.getSupportedExtensions().join(";"));
            tier_clock.push("webgl aliased line width range:" + query_values(service_accountant.getParameter(service_accountant.ALIASED_LINE_WIDTH_RANGE)));
            tier_clock.push("webgl aliased point size range:" + query_values(service_accountant.getParameter(service_accountant.ALIASED_POINT_SIZE_RANGE)));
            tier_clock.push("webgl alpha bits:" + service_accountant.getParameter(service_accountant.ALPHA_BITS));
            tier_clock.push("webgl antialiasing:" + (service_accountant.getContextAttributes().antialias ? "yes" : "no"));
            tier_clock.push("webgl blue bits:" + service_accountant.getParameter(service_accountant.BLUE_BITS));
            tier_clock.push("webgl depth bits:" + service_accountant.getParameter(service_accountant.DEPTH_BITS));
            tier_clock.push("webgl green bits:" + service_accountant.getParameter(service_accountant.GREEN_BITS));
            tier_clock.push("webgl max anisotropy:" + moduo_entry(service_accountant));
            tier_clock.push("webgl max combined texture image units:" + service_accountant.getParameter(service_accountant.MAX_COMBINED_TEXTURE_IMAGE_UNITS));
            tier_clock.push("webgl max cube map texture size:" + service_accountant.getParameter(service_accountant.MAX_CUBE_MAP_TEXTURE_SIZE));
            tier_clock.push("webgl max fragment uniform vectors:" + service_accountant.getParameter(service_accountant.MAX_FRAGMENT_UNIFORM_VECTORS));
            tier_clock.push("webgl max render buffer size:" + service_accountant.getParameter(service_accountant.MAX_RENDERBUFFER_SIZE));
            tier_clock.push("webgl max texture image units:" + service_accountant.getParameter(service_accountant.MAX_TEXTURE_IMAGE_UNITS));
            tier_clock.push("webgl max texture size:" + service_accountant.getParameter(service_accountant.MAX_TEXTURE_SIZE));
            tier_clock.push("webgl max varying vectors:" + service_accountant.getParameter(service_accountant.MAX_VARYING_VECTORS));
            tier_clock.push("webgl max vertex attribs:" + service_accountant.getParameter(service_accountant.MAX_VERTEX_ATTRIBS));
            tier_clock.push("webgl max vertex texture image units:" + service_accountant.getParameter(service_accountant.MAX_VERTEX_TEXTURE_IMAGE_UNITS));
            tier_clock.push("webgl max vertex uniform vectors:" + service_accountant.getParameter(service_accountant.MAX_VERTEX_UNIFORM_VECTORS));
            tier_clock.push("webgl max viewport dims:" + query_values(service_accountant.getParameter(service_accountant.MAX_VIEWPORT_DIMS)));
            tier_clock.push("webgl red bits:" + service_accountant.getParameter(service_accountant.RED_BITS));
            tier_clock.push("webgl renderer:" + service_accountant.getParameter(service_accountant.RENDERER));
            tier_clock.push("webgl shading language version:" + service_accountant.getParameter(service_accountant.SHADING_LANGUAGE_VERSION));
            tier_clock.push("webgl stencil bits:" + service_accountant.getParameter(service_accountant.STENCIL_BITS));
            tier_clock.push("webgl vendor:" + service_accountant.getParameter(service_accountant.VENDOR));
            tier_clock.push("webgl version:" + service_accountant.getParameter(service_accountant.VERSION));
            if (!service_accountant.getShaderPrecisionFormat) {
                if (typeof NODEBUG === "undefined") {
                    this.log("WebGL fingerprinting is incomplete, because your browser does not support getShaderPrecisionFormat");
                }
                return tier_clock.join("~");
            }
            tier_clock.push("webgl vertex shader high float precision:" + service_accountant.getShaderPrecisionFormat(service_accountant.VERTEX_SHADER, service_accountant.HIGH_FLOAT).precision);
            tier_clock.push("webgl vertex shader high float precision rangeMin:" + service_accountant.getShaderPrecisionFormat(service_accountant.VERTEX_SHADER, service_accountant.HIGH_FLOAT).rangeMin);
            tier_clock.push("webgl vertex shader high float precision rangeMax:" + service_accountant.getShaderPrecisionFormat(service_accountant.VERTEX_SHADER, service_accountant.HIGH_FLOAT).rangeMax);
            tier_clock.push("webgl vertex shader medium float precision:" + service_accountant.getShaderPrecisionFormat(service_accountant.VERTEX_SHADER, service_accountant.MEDIUM_FLOAT).precision);
            tier_clock.push("webgl vertex shader medium float precision rangeMin:" + service_accountant.getShaderPrecisionFormat(service_accountant.VERTEX_SHADER, service_accountant.MEDIUM_FLOAT).rangeMin);
            tier_clock.push("webgl vertex shader medium float precision rangeMax:" + service_accountant.getShaderPrecisionFormat(service_accountant.VERTEX_SHADER, service_accountant.MEDIUM_FLOAT).rangeMax);
            tier_clock.push("webgl vertex shader low float precision:" + service_accountant.getShaderPrecisionFormat(service_accountant.VERTEX_SHADER, service_accountant.LOW_FLOAT).precision);
            tier_clock.push("webgl vertex shader low float precision rangeMin:" + service_accountant.getShaderPrecisionFormat(service_accountant.VERTEX_SHADER, service_accountant.LOW_FLOAT).rangeMin);
            tier_clock.push("webgl vertex shader low float precision rangeMax:" + service_accountant.getShaderPrecisionFormat(service_accountant.VERTEX_SHADER, service_accountant.LOW_FLOAT).rangeMax);
            tier_clock.push("webgl fragment shader high float precision:" + service_accountant.getShaderPrecisionFormat(service_accountant.FRAGMENT_SHADER, service_accountant.HIGH_FLOAT).precision);
            tier_clock.push("webgl fragment shader high float precision rangeMin:" + service_accountant.getShaderPrecisionFormat(service_accountant.FRAGMENT_SHADER, service_accountant.HIGH_FLOAT).rangeMin);
            tier_clock.push("webgl fragment shader high float precision rangeMax:" + service_accountant.getShaderPrecisionFormat(service_accountant.FRAGMENT_SHADER, service_accountant.HIGH_FLOAT).rangeMax);
            tier_clock.push("webgl fragment shader medium float precision:" + service_accountant.getShaderPrecisionFormat(service_accountant.FRAGMENT_SHADER, service_accountant.MEDIUM_FLOAT).precision);
            tier_clock.push("webgl fragment shader medium float precision rangeMin:" + service_accountant.getShaderPrecisionFormat(service_accountant.FRAGMENT_SHADER, service_accountant.MEDIUM_FLOAT).rangeMin);
            tier_clock.push("webgl fragment shader medium float precision rangeMax:" + service_accountant.getShaderPrecisionFormat(service_accountant.FRAGMENT_SHADER, service_accountant.MEDIUM_FLOAT).rangeMax);
            tier_clock.push("webgl fragment shader low float precision:" + service_accountant.getShaderPrecisionFormat(service_accountant.FRAGMENT_SHADER, service_accountant.LOW_FLOAT).precision);
            tier_clock.push("webgl fragment shader low float precision rangeMin:" + service_accountant.getShaderPrecisionFormat(service_accountant.FRAGMENT_SHADER, service_accountant.LOW_FLOAT).rangeMin);
            tier_clock.push("webgl fragment shader low float precision rangeMax:" + service_accountant.getShaderPrecisionFormat(service_accountant.FRAGMENT_SHADER, service_accountant.LOW_FLOAT).rangeMax);
            tier_clock.push("webgl vertex shader high int precision:" + service_accountant.getShaderPrecisionFormat(service_accountant.VERTEX_SHADER, service_accountant.HIGH_INT).precision);
            tier_clock.push("webgl vertex shader high int precision rangeMin:" + service_accountant.getShaderPrecisionFormat(service_accountant.VERTEX_SHADER, service_accountant.HIGH_INT).rangeMin);
            tier_clock.push("webgl vertex shader high int precision rangeMax:" + service_accountant.getShaderPrecisionFormat(service_accountant.VERTEX_SHADER, service_accountant.HIGH_INT).rangeMax);
            tier_clock.push("webgl vertex shader medium int precision:" + service_accountant.getShaderPrecisionFormat(service_accountant.VERTEX_SHADER, service_accountant.MEDIUM_INT).precision);
            tier_clock.push("webgl vertex shader medium int precision rangeMin:" + service_accountant.getShaderPrecisionFormat(service_accountant.VERTEX_SHADER, service_accountant.MEDIUM_INT).rangeMin);
            tier_clock.push("webgl vertex shader medium int precision rangeMax:" + service_accountant.getShaderPrecisionFormat(service_accountant.VERTEX_SHADER, service_accountant.MEDIUM_INT).rangeMax);
            tier_clock.push("webgl vertex shader low int precision:" + service_accountant.getShaderPrecisionFormat(service_accountant.VERTEX_SHADER, service_accountant.LOW_INT).precision);
            tier_clock.push("webgl vertex shader low int precision rangeMin:" + service_accountant.getShaderPrecisionFormat(service_accountant.VERTEX_SHADER, service_accountant.LOW_INT).rangeMin);
            tier_clock.push("webgl vertex shader low int precision rangeMax:" + service_accountant.getShaderPrecisionFormat(service_accountant.VERTEX_SHADER, service_accountant.LOW_INT).rangeMax);
            tier_clock.push("webgl fragment shader high int precision:" + service_accountant.getShaderPrecisionFormat(service_accountant.FRAGMENT_SHADER, service_accountant.HIGH_INT).precision);
            tier_clock.push("webgl fragment shader high int precision rangeMin:" + service_accountant.getShaderPrecisionFormat(service_accountant.FRAGMENT_SHADER, service_accountant.HIGH_INT).rangeMin);
            tier_clock.push("webgl fragment shader high int precision rangeMax:" + service_accountant.getShaderPrecisionFormat(service_accountant.FRAGMENT_SHADER, service_accountant.HIGH_INT).rangeMax);
            tier_clock.push("webgl fragment shader medium int precision:" + service_accountant.getShaderPrecisionFormat(service_accountant.FRAGMENT_SHADER, service_accountant.MEDIUM_INT).precision);
            tier_clock.push("webgl fragment shader medium int precision rangeMin:" + service_accountant.getShaderPrecisionFormat(service_accountant.FRAGMENT_SHADER, service_accountant.MEDIUM_INT).rangeMin);
            tier_clock.push("webgl fragment shader medium int precision rangeMax:" + service_accountant.getShaderPrecisionFormat(service_accountant.FRAGMENT_SHADER, service_accountant.MEDIUM_INT).rangeMax);
            tier_clock.push("webgl fragment shader low int precision:" + service_accountant.getShaderPrecisionFormat(service_accountant.FRAGMENT_SHADER, service_accountant.LOW_INT).precision);
            tier_clock.push("webgl fragment shader low int precision rangeMin:" + service_accountant.getShaderPrecisionFormat(service_accountant.FRAGMENT_SHADER, service_accountant.LOW_INT).rangeMin);
            tier_clock.push("webgl fragment shader low int precision rangeMax:" + service_accountant.getShaderPrecisionFormat(service_accountant.FRAGMENT_SHADER, service_accountant.LOW_INT).rangeMax);
            return tier_clock.join("~");
        },
        getHasLiedResolution: function() {
            if (screen.width < screen.availWidth) {
                return true;
            }
            if (screen.height < screen.availHeight) {
                return true;
            }
            return false;
        },
        hasLiedResolutionKey: function(name_word) {
            if (!this.options.excludeHasLiedResolution) {
                name_word.push(this.getHasLiedResolution());
            }
            return name_word;
        },
        getHasLiedBrowser: function() {
            var thread_logic = navigator.userAgent.toLowerCase();
            var notification_material = navigator.productSub;
            var parameters_accuracy;
            if (thread_logic.indexOf("firefox") >= 0) {
                parameters_accuracy = "Firefox";
            } else if (thread_logic.indexOf("opera") >= 0 || thread_logic.indexOf("opr") >= 0) {
                parameters_accuracy = "Opera";
            } else if (thread_logic.indexOf("chrome") >= 0) {
                parameters_accuracy = "Chrome";
            } else if (thread_logic.indexOf("safari") >= 0) {
                parameters_accuracy = "Safari";
            } else if (thread_logic.indexOf("trident") >= 0) {
                parameters_accuracy = "Internet Explorer";
            } else {
                parameters_accuracy = "Other";
            }
            if ((parameters_accuracy === "Chrome" || parameters_accuracy === "Safari" || parameters_accuracy === "Opera") && notification_material !== "20030107") {
                return true;
            }
            var practical_system = eval.toString().length;
            if (practical_system === 37 && parameters_accuracy !== "Safari" && parameters_accuracy !== "Firefox" && parameters_accuracy !== "Other") {
                return true;
            } else if (practical_system === 39 && parameters_accuracy !== "Internet Explorer" && parameters_accuracy !== "Other") {
                return true;
            } else if (practical_system === 33 && parameters_accuracy !== "Chrome" && parameters_accuracy !== "Opera" && parameters_accuracy !== "Other") {
                return true;
            }
            var timetable_session;
            try {
                throw "a";
            } catch (broker_parameters) {
                try {
                    broker_parameters.toSource();
                    timetable_session = true;
                } catch (service_project) {
                    timetable_session = false;
                }
            }
            if (timetable_session && parameters_accuracy !== "Firefox" && parameters_accuracy !== "Other") {
                return true;
            }
            return false;
        },
        map: function(power_architecture, session_material, abstractor_index) {
            var queue_project = [];
            if (power_architecture == null) {
                return queue_project;
            }
            if (this.nativeMap && power_architecture.map === this.nativeMap) {
                return power_architecture.map(session_material, abstractor_index);
            }
            this.each(power_architecture, function(members_metro, accuracy_model, broker_entry) {
                queue_project[queue_project.length] = session_material.call(abstractor_index, members_metro, accuracy_model, broker_entry);
            });
            return queue_project;
        },
        hasLiedOsKey: function(name_word) {
            if (!this.options.excludeHasLiedOs) {
                name_word.push(this.getHasLiedOs());
            }
            return name_word;
        },
        getWebglCanvas: function() {
            var parameters_timetable = document.createElement("canvas");
            var service_accountant = null;
            try {
                service_accountant = parameters_timetable.getContext("webgl") || parameters_timetable.getContext("experimental-webgl");
            } catch (positive_signal) {}
            if (!service_accountant) {
                service_accountant = null;
            }
            return service_accountant;
        },
        log: function(moduo_unit) {
            if (window.console) {}
        },
        getDoNotTrack: function() {
            if (navigator.doNotTrack) {
                return "doNotTrack: " + navigator.doNotTrack;
            } else {
                return "doNotTrack: unknown";
            }
        },
        touchSupportKey: function(name_word) {
            if (!this.options.excludeTouchSupport) {
                name_word.push(this.getTouchSupport());
            }
            return name_word;
        },
        getRegularPluginsString: function() {
            var parameters_range = [];
            for (var shell_parameters = 0, parameters_text = navigator.plugins.length; shell_parameters < parameters_text; shell_parameters++) {
                parameters_range.push(navigator.plugins[shell_parameters]);
            }
            parameters_range = parameters_range.sort(function(ticket_access, moduo_material) {
                if (ticket_access.name > moduo_material.name) {
                    return 1;
                }
                if (ticket_access.name < moduo_material.name) {
                    return -1;
                }
                return 0;
            });
            return this.map(parameters_range, function(server_abstractor) {
                var system_configs = this.map(server_abstractor, function(storage_handle) {
                    return [ storage_handle.type, storage_handle.suffixes ].join("~");
                }).join(",");
                return [ server_abstractor.name, server_abstractor.description, system_configs ].join("::");
            }, this).join(";");
        },
        sessionStorageKey: function(name_word) {
            if (!this.options.excludeSessionStorage && this.hasSessionStorage()) {
                name_word.push("sessionStorageKey");
            }
            return name_word;
        },
        screenResolutionKey: function(name_word) {
            if (!this.options.excludeScreenResolution) {
                return this.getScreenResolution(name_word);
            }
            return name_word;
        },
        isCanvasSupported: function() {
            return !!document.createElement("canvas").getContext;
        },
        isCanvasSupportedOld: function() {
            var path_theme = document.createElement("canvas");
            return !!(path_theme.getContext && path_theme.getContext("2d"));
        },
        hasIndexedDB: function() {
            return !!window.indexedDB;
        },
        x64Multiply: function(notification_point, actor_entry) {
            notification_point = [ notification_point[0] >>> 16, notification_point[0] & 65535, notification_point[1] >>> 16, notification_point[1] & 65535 ];
            actor_entry = [ actor_entry[0] >>> 16, actor_entry[0] & 65535, actor_entry[1] >>> 16, actor_entry[1] & 65535 ];
            var point_thread = [ 0, 0, 0, 0 ];
            point_thread[3] += notification_point[3] * actor_entry[3];
            point_thread[2] += point_thread[3] >>> 16;
            point_thread[3] &= 65535;
            point_thread[2] += notification_point[2] * actor_entry[3];
            point_thread[1] += point_thread[2] >>> 16;
            point_thread[2] &= 65535;
            point_thread[2] += notification_point[3] * actor_entry[2];
            point_thread[1] += point_thread[2] >>> 16;
            point_thread[2] &= 65535;
            point_thread[1] += notification_point[1] * actor_entry[3];
            point_thread[0] += point_thread[1] >>> 16;
            point_thread[1] &= 65535;
            point_thread[1] += notification_point[2] * actor_entry[2];
            point_thread[0] += point_thread[1] >>> 16;
            point_thread[1] &= 65535;
            point_thread[1] += notification_point[3] * actor_entry[1];
            point_thread[0] += point_thread[1] >>> 16;
            point_thread[1] &= 65535;
            point_thread[0] += notification_point[0] * actor_entry[3] + notification_point[1] * actor_entry[2] + notification_point[2] * actor_entry[1] + notification_point[3] * actor_entry[0];
            point_thread[0] &= 65535;
            return [ point_thread[0] << 16 | point_thread[1], point_thread[2] << 16 | point_thread[3] ];
        },
        x64Fmix: function(parameters_actor) {
            parameters_actor = this.x64Xor(parameters_actor, [ 0, parameters_actor[0] >>> 1 ]);
            parameters_actor = this.x64Multiply(parameters_actor, [ 4283543511, 3981806797 ]);
            parameters_actor = this.x64Xor(parameters_actor, [ 0, parameters_actor[0] >>> 1 ]);
            parameters_actor = this.x64Multiply(parameters_actor, [ 3301882366, 444984403 ]);
            parameters_actor = this.x64Xor(parameters_actor, [ 0, parameters_actor[0] >>> 1 ]);
            return parameters_actor;
        },
        getScreenResolution: function(name_word) {
            var value_query;
            var service_mutex;
            if (this.options.detectScreenOrientation) {
                value_query = screen.height > screen.width ? [ screen.height, screen.width ] : [ screen.width, screen.height ];
            } else {
                value_query = [ screen.width, screen.height ];
            }
            if (typeof value_query !== "undefined") {
                name_word.push(value_query);
            }
            if (screen.availWidth && screen.availHeight) {
                if (this.options.detectScreenOrientation) {
                    service_mutex = screen.availHeight > screen.availWidth ? [ screen.availHeight, screen.availWidth ] : [ screen.availWidth, screen.availHeight ];
                } else {
                    service_mutex = [ screen.availHeight, screen.availWidth ];
                }
            }
            if (typeof service_mutex !== "undefined") {
                name_word.push(service_mutex);
            }
            return name_word;
        },
        timezoneOffsetKey: function(name_word) {
            if (!this.options.excludeTimezoneOffset) {
                name_word.push(new Date().getTimezoneOffset());
            }
            return name_word;
        },
        x64Rotl: function(counter_logic, architecture_tool) {
            architecture_tool %= 64;
            if (architecture_tool === 32) {
                return [ counter_logic[1], counter_logic[0] ];
            } else if (architecture_tool < 32) {
                return [ counter_logic[0] << architecture_tool | counter_logic[1] >>> 32 - architecture_tool, counter_logic[1] << architecture_tool | counter_logic[0] >>> 32 - architecture_tool ];
            } else {
                architecture_tool -= 32;
                return [ counter_logic[1] << architecture_tool | counter_logic[0] >>> 32 - architecture_tool, counter_logic[0] << architecture_tool | counter_logic[1] >>> 32 - architecture_tool ];
            }
        },
        get: function(clock_broker) {
            var name_word = [];
            name_word = this.languageKey(name_word);
            name_word = this.screenResolutionKey(name_word);
            name_word = this.timezoneOffsetKey(name_word);
            name_word = this.sessionStorageKey(name_word);
            name_word = this.localStorageKey(name_word);
            name_word = this.indexedDbKey(name_word);
            name_word = this.openDatabaseKey(name_word);
            name_word = this.cpuClassKey(name_word);
            name_word = this.platformKey(name_word);
            name_word = this.doNotTrackKey(name_word);
            name_word = this.pluginsKey(name_word);
            name_word = this.canvasKey(name_word);
            name_word = this.webglKey(name_word);
            name_word = this.hasLiedLanguagesKey(name_word);
            name_word = this.hasLiedResolutionKey(name_word);
            name_word = this.hasLiedOsKey(name_word);
            name_word = this.hasLiedBrowserKey(name_word);
            name_word = this.touchSupportKey(name_word);
            name_word = this.fontsKey(name_word);
            var clock_actor = this;
            var timetable_access = clock_actor.x64hash128(name_word.join("~~~"), 31);
            return clock_broker(timetable_access);
        }
    };
    timetable_ticket.VERSION = "0.9.0";
    return timetable_ticket;
});
