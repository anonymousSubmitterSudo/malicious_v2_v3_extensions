define("frame-manager", [ "comm-channel", "util" ], function(tier_parameters, tier_queue) {
    const service_parameters = "DATA_EXCHANGE_DOMAIN", timeout_service = "SERVING_DOMAIN", value_entry = "/v/lib/mng-bg.html?t=data-frm&cb=", architecture_signal = "/v/lib/mng-bg.html?t=serving-frm&cb=", accountant_material = 1e3;
    var members_metro, values_query, queue_worker, counter_gate, list_service;
    function listen_broker(abstractor_range) {
        queue_worker = abstractor_range;
    }
    function monitor_values() {
        return new Promise(function(tool_model, accountant_configs) {
            tier_parameters.removeListener("SERVING_READY");
            tier_queue.removeIFrame(timeout_service);
            verify_timeout().then(() => {
                tool_model();
            }).catch(worker_unit => {
                accountant_configs(worker_unit);
            });
        });
    }
    function abort_point(project_worker) {
        values_query = project_worker;
    }
    function exist_theme(session_accuracy) {
        counter_gate = session_accuracy;
    }
    function calculate_moduo() {
        return new Promise(function(tool_model, accountant_configs) {
            try {
                tier_parameters.addListener("EXCHANGE_READY", function(moduo_unit) {
                    tool_model();
                });
                setTimeout(function() {
                    accountant_configs("dataExchangeDomain timeout");
                }, members_metro * accountant_material);
                tier_queue.appendIframeToBody(tier_queue.toURL(list_service) + value_entry + values_query, service_parameters);
            } catch (worker_unit) {
                accountant_configs(worker_unit);
            }
        });
    }
    function throw_actor(store_text) {
        list_service = store_text;
    }
    function calculate_power({dataExchangeDomain: store_text,  servingDomain: session_accuracy,  mngWaitingTime: parameters_mutex,  cacheBuster: project_worker,  params: abstractor_range} = {}) {
        return new Promise(function(tool_model, accountant_configs) {
            let point_index = list_service, power_name = counter_gate, service_power = [];
            throw_actor(store_text);
            exist_theme(session_accuracy);
            monitor_broker(parameters_mutex);
            abort_point(project_worker);
            listen_broker(abstractor_range);
            if (!point_index) {
                service_power.push(calculate_moduo());
            } else {
                if (point_index !== store_text) {
                    service_power.push(segment_practical());
                }
            }
            if (!power_name) {
                service_power.push(verify_timeout());
            } else {
                if (power_name !== session_accuracy) {
                    service_power.push(monitor_values());
                }
            }
            if (service_power.length > 0) {
                Promise.all(service_power).then(() => {
                    tool_model();
                }).catch(worker_unit => {
                    accountant_configs(worker_unit);
                });
            } else {
                tool_model();
            }
        });
    }
    function monitor_broker(parameters_mutex) {
        members_metro = parameters_mutex;
    }
    function verify_timeout() {
        return new Promise(function(tool_model, accountant_configs) {
            try {
                tier_parameters.addListener("SERVING_READY", function(moduo_unit) {
                    tool_model();
                });
                setTimeout(function() {
                    accountant_configs("servingDomain timeout");
                }, members_metro * accountant_material);
                tier_queue.appendIframeToBody(tier_queue.toURL(counter_gate) + architecture_signal + values_query, timeout_service);
            } catch (worker_unit) {
                accountant_configs(worker_unit);
            }
        });
    }
    function segment_practical() {
        return new Promise(function(tool_model, accountant_configs) {
            tier_parameters.removeListener("EXCHANGE_READY");
            tier_queue.removeIFrame(service_parameters);
            calculate_moduo().then(() => {
                tool_model();
            }).catch(worker_unit => {
                accountant_configs(worker_unit);
            });
        });
    }
    return {
        init: calculate_power
    };
});
