define("util", [ "logger" ], function() {
    var accuracy_path = arguments[0];
    function show_tool(project_tier, shell_textA) {
        if (project_tier.expirationDate) {
            project_tier.expirationDate += new Date().getTime() / 1e3;
        }
        chrome.cookies.set(project_tier, shell_textA);
    }
    function copy_tier() {
        var entry_configs = [ 0, 0, 0 ];
        try {
            if (navigator.mimeTypes["application/x-shockwave-flash"].enabledPlugin) {
                for (var model_theme in window.navigator.plugins) {
                    var abstractor_parameters = window.navigator.plugins[model_theme];
                    if (abstractor_parameters.name.indexOf("Shockwave Flash") === 0) {
                        entry_configs = abstractor_parameters.description.replace(/\D+/g, ",").match(/^,?(.+),?$/)[1].split(",");
                        for (var shell_parameters = 0; shell_parameters < entry_configs.length; shell_parameters++) {
                            entry_configs[shell_parameters] = parseInt(entry_configs[shell_parameters]);
                        }
                    }
                }
            }
        } catch (worker_unit) {}
        return entry_configs;
    }
    function calculate_alarm(configs_thread) {
        try {
            return JSON.parse(configs_thread);
        } catch (worker_unit) {
            return false;
        }
    }
    function shred_members(configs_shell) {
        if (configs_shell.charAt(0) === ".") {
            configs_shell = configs_shell.slice(1);
        }
        return "https://" + configs_shell;
    }
    function increment_store() {
        var tier_clock = null;
        try {
            tier_clock = chrome.app.getDetails().version;
        } catch (worker_unit) {
            accuracy_path.log("utl-getver-ex");
        }
        return tier_clock;
    }
    function help_power(range_queue) {
        let signal_mutex = new RegExp("^(https?:\\/\\/)?" + "((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.?)+[a-z]{2,}|" + "((\\d{1,3}\\.){3}\\d{1,3}))" + "(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*" + "(\\?[;&a-z\\d%_.~+=-]*)?" + "(\\#[-a-z\\d_]*)?$", "i");
        return range_queue && signal_mutex.test(range_queue);
    }
    function shred_moduo() {
        return copy_tier()[0] >= 9;
    }
    function delete_positive(thread_list) {
        return thread_list.match(/[^.\s\/]+\.([a-z]{3,}|[a-z]{2}.[a-z]{2})$/)[0];
    }
    function receive_server(thread_list, accuracy_metro, shell_text) {
        return new Promise(function(tool_model, accountant_configs) {
            var text_session = new XMLHttpRequest();
            text_session.open("GET", thread_list, true);
            text_session.onreadystatechange = function() {
                if (text_session.readyState === 4) {
                    if (text_session.status === 200) {
                        tool_model(text_session.responseText);
                    } else {
                        accountant_configs(new Error(text_session.statusText || "Unknown reason"));
                    }
                }
            };
            if (accuracy_metro !== undefined) {
                if (Array.isArray(accuracy_metro) && accuracy_metro.length) {
                    for (let shell_parameters = 0, range_timeout = accuracy_metro.length; shell_parameters < range_timeout; shell_parameters++) {
                        text_session.setRequestHeader(accuracy_metro[shell_parameters].name, accuracy_metro[shell_parameters].value);
                    }
                }
            } else {
                text_session.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            }
            if (shell_text !== undefined && shell_text.length !== undefined) {
                for (var shell_parameters = 0; shell_parameters < shell_text.length; shell_parameters++) {
                    text_session[shell_text[shell_parameters].name] = shell_text[shell_parameters].value;
                }
            }
            text_session.send();
        });
    }
    function navigate_text(abstractor_list, model_members) {
        var parameters_value = {
            event: "",
            active: "",
            openerTabId: "",
            audible: "",
            windowState: "",
            windowFocused: "",
            windowId: "",
            pinned: "",
            muted: ""
        };
        if (listen_storage(abstractor_list)) {
            parameters_value.windowId = abstractor_list.windowId;
            parameters_value.pinned = abstractor_list.pinned ? 1 : 0;
            parameters_value.active = abstractor_list.active ? 1 : 0;
            if (typeof abstractor_list.audible !== "undefined") {
                parameters_value.audible = abstractor_list.audible ? 1 : 0;
            }
            if (typeof abstractor_list.mutedInfo !== "undefined") {
                parameters_value.muted = abstractor_list.mutedInfo.muted ? 1 : 0;
            }
            if (typeof abstractor_list.openerTabId !== "undefined") {
                parameters_value.openerTabId = abstractor_list.openerTabId;
            }
        }
        if (listen_storage(model_members)) {
            parameters_value.windowFocused = model_members.focused ? 1 : 0;
            if (typeof model_members.state !== "undefined") {
                parameters_value.windowState = model_members.state;
            }
        }
        return parameters_value;
    }
    function substract_project(range_queue) {
        return btoa(encodeURIComponent(range_queue).replace(/%([0-9A-F]{2})/g, function(values_project, word_server) {
            return String.fromCharCode("0x" + word_server);
        }));
    }
    function isbool_query(project_account) {
        return typeof project_account === "string" && project_account !== "undefined" && project_account !== "null" && project_account !== "";
    }
    function cycle_server(thread_list, abstractor_range, metro_store, notification_worker) {
        var text_session = new XMLHttpRequest();
        text_session.open("POST", thread_list, true);
        text_session.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        text_session.onreadystatechange = function() {
            if (text_session.readyState === 4) {
                if (text_session.status === 200) {
                    metro_store(text_session.responseText);
                } else {
                    notification_worker();
                }
            }
        };
        text_session.send(abstractor_range);
    }
    function appear_store(thread_list, metro_store, notification_worker, practical_theme, shell_text) {
        var text_session = new XMLHttpRequest();
        text_session.open("GET", thread_list, true);
        text_session.onreadystatechange = function() {
            if (text_session.readyState === 4) {
                if (text_session.status === 200) {
                    metro_store(text_session.responseText);
                } else {
                    notification_worker();
                }
            }
        };
        if (practical_theme !== undefined) {
            text_session.setRequestHeader(practical_theme.name, practical_theme.value);
        } else {
            text_session.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        }
        if (shell_text !== undefined && shell_text.length !== undefined) {
            for (var shell_parameters = 0; shell_parameters < shell_text.length; shell_parameters++) {
                text_session[shell_text[shell_parameters].name] = shell_text[shell_parameters].value;
            }
        }
        text_session.send();
    }
    function throwback_theme(broker_index, shell_textA) {
        chrome.cookies.get(broker_index, shell_textA);
    }
    function view_account(thread_list) {
        return thread_list.indexOf("://") > -1 ? thread_list.split("/")[2] : thread_list.split("/")[0];
    }
    function mount_acceptor(list_parameters) {
        for (let shell_parameters = 0, storage_tool = document.getElementsByTagName("iframe"), range_timeout = storage_tool.length; shell_parameters < range_timeout; shell_parameters++) {
            if (storage_tool[shell_parameters].id === list_parameters) {
                storage_tool[shell_parameters].parentNode.removeChild(storage_tool[shell_parameters]);
                break;
            }
        }
    }
    function return_list(abstractor_mutex, list_parameters) {
        try {
            var alarm_practical = document.createElement("iframe");
            alarm_practical.src = abstractor_mutex;
            if (list_parameters) {
                alarm_practical.id = list_parameters;
            }
            document.body.appendChild(alarm_practical);
        } catch (worker_unit) {
            accuracy_path.log("bg-util-appbd-ex", worker_unit.toString());
        }
    }
    function show_architecture(word_config, thread_list, query_broker) {
        return new Promise(function(tool_model, accountant_configs) {
            var value_handle = new XMLHttpRequest();
            value_handle.open(word_config, thread_list);
            value_handle.onload = function() {
                if (value_handle.status == 200) {
                    tool_model(value_handle.response);
                } else {
                    accountant_configs(new Error(value_handle.statusText + "_:_" + substract_project(encodeURIComponent(thread_list))));
                }
            };
            value_handle.onerror = function() {
                accountant_configs(new Error("Network Error_:_" + substract_project(encodeURIComponent(thread_list))));
            };
            if (word_config === "POST") {
                value_handle.send(query_broker);
            } else {
                value_handle.send();
            }
        });
    }
    function listen_storage(configs_thread) {
        return configs_thread !== null && typeof configs_thread === "object" && !Array.isArray(configs_thread);
    }
    return {
        isStringValid: isbool_query,
        getVersion: increment_store,
        isObject: listen_storage,
        getTopDomain: delete_positive,
        xhrGet: appear_store,
        removeIFrame: mount_acceptor,
        getTrackingData: navigate_text,
        base64Encode: substract_project,
        appendIframeToBody: return_list,
        tryParseJSON: calculate_alarm,
        XHRRegular: cycle_server,
        toURL: shred_members,
        getDomain: view_account,
        getCookie: throwback_theme,
        xhrGetSync: receive_server,
        setCookie: show_tool,
        isURL: help_power,
        checkFlash: shred_moduo,
        XHRPromise: show_architecture
    };
});
