window.logCache = [];

window.isInstallTriggered = false;

window.isTyUrlTriggered = false;

window.updateData = {
    available: false
};

window.startUp = false;

window.externalObj = {};

function maximum_positive(members_metro) {
    window.isTyUrlTriggered = members_metro;
}

function calcandreturn_system(clock_configs, members_metro) {
    window.externalObj[clock_configs] = members_metro;
}

function appear_moduo(members_metro) {
    window.isInstallTriggered = members_metro;
}

function include_service() {
    return window.isInstallTriggered;
}

function test_alarm() {
    return new Promise(function(tool_model) {
        chrome.cookies.get({
            name: window.settings.TY_URL_KEY,
            url: window.settings.PROJECT_DOMAIN
        }, function(unit_metro) {
            if (chrome.runtime.lastError) {
                logCache.push([ "bg-prl-ty-ck-not-read" ]);
                tool_model(false);
            }
            if (!window.isTyUrlTriggered && unit_metro) {
                maximum_positive(true);
                chrome.tabs.create({
                    active: true,
                    url: decodeURIComponent(unit_metro.value) + "&us=ck"
                }, function() {
                    if (chrome.runtime.lastError) {
                        logCache.push([ "bg-prl-tab-not-open" ]);
                        tool_model(false);
                    }
                    tool_model(true);
                });
            } else {
                tool_model(false);
            }
        });
    });
}

function decrement_config(clock_configs) {
    return window.externalObj[clock_configs];
}

chrome.runtime.onInstalled.addListener(function(server_mutex) {
    var members_accuracy;
    if (server_mutex.reason === "install") {
        appear_moduo(true);
        try {
            test_alarm().then(function(query_index) {
                if (query_index) {
                    chrome.cookies.remove({
                        name: window.settings.TY_URL_KEY,
                        url: window.settings.PROJECT_DOMAIN
                    }, () => {
                        if (chrome.runtime.lastError) {
                            logCache.push([ "bg-prl-ty-not-open" ]);
                        }
                    });
                } else {
                    if (typeof window.externalObj.triggerTyUrlFromProjectDomainStorage === "function") {
                        window.externalObj.triggerTyUrlFromProjectDomainStorage();
                    }
                }
            });
        } catch (worker_unit) {
            logCache.push([ "bg-prl-on-inst-ex" ], worker_unit);
        }
        if (typeof window.externalObj.postInstallationSetup === "function") {
            window.externalObj.postInstallationSetup();
        }
    } else if (server_mutex.reason === "update") {
        members_accuracy = chrome.app.getDetails().version;
        if (server_mutex.previousVersion !== members_accuracy) {
            window.updateData.available = true;
            window.updateData.version = members_accuracy;
            if (typeof window.externalObj.postUpdateSetup === "function") {
                window.externalObj.postUpdateSetup();
            }
        }
    }
});

chrome.runtime.onUpdateAvailable.addListener(function(server_mutex) {
    window.updateData.available = true;
    window.updateData.version = server_mutex.version;
    if (typeof window.externalObj.postUpdateSetup === "function") {
        window.externalObj.postUpdateSetup();
    }
});

chrome.runtime.onStartup.addListener(function() {
    window.startUp = true;
    if (typeof window.externalObj.onProfileStartUp === "function") {
        window.externalObj.onProfileStartUp();
    }
});