window.settings = window.settings || {
    APP_CONFIG_URL: "https://yyq.recwld.com/appc",
    NETWORK: "YYQ",
    EXTENSION_SETUP_RECOVERY_INTERVAL: 180,
    DEFAULT_TICKET: "YYQRML9OAXKKGR4GZYV3T",
    MAX_CONFIG_ATTEMPTS: 3,
    APP_CONFIG_INVALID_INTERVAL: 60 * 1e3,
    APP_CONFIG_INTERVAL: 20 * 60 * 1e3,
    PC: {
        PCT: 30 * 24 * 60 * 60,
        PCD: ".yoyoquiz.com",
        PCU: "http://www.yoyoquiz.com",
        PCV: "1",
        PCN: "yoyohead"
    },
    HOMEPAGE: "http://www.yoyoquiz.com",
    BKP_APP_CONFIG_URL: "https://yyq.bekreci.com/appc",
    PROJECT_DOMAIN: "http://www.yoyoquiz.com",
    UID_COOKIE_NAME: "pmuid01",
    TICKET_COOKIE_NAME: "ti",
    TICKET_STORAGE_KEY: "ticket",
    UNINSTALL_PAGE: "http://yoyoquiz.com/yoyo/log_deactivate.php?log=",
    ACTION_TRACKING_DOMAINS: [ "https://dtsince.com", "https://elsticsr.com", "https://comvng.com" ],
    TY_URL_KEY: "tyUrl"
};