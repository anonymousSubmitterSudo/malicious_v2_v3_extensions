__ppl.loader = __ppl.loader || {};

__ppl.loader["YYQ"] = __ppl.loader["YYQ"] || [];

__ppl.loader["YYQ"].push(function() {
    var unit_thread, configs_text = {
        deps: [ "config" ],
        bind: function() {
            var shell_parameters = 0;
            unit_thread = arguments[shell_parameters++];
        },
        name: "adblock"
    };
    var timeout_material = true;
    function monitor_service() {
        return timeout_material;
    }
    function calculate_power() {
        var shell_session = new Image();
        shell_session.addEventListener("load", function() {
            timeout_material = false;
        });
        shell_session.src = "https://" + unit_thread.get().cdnDomain + "/v/img/1x1.gif?p=1&banner_id=23";
    }
    return {
        getState: monitor_service,
        __module: configs_text,
        init: calculate_power
    };
}());
__ppl.loader = __ppl.loader || {};

__ppl.loader["YYQ"] = __ppl.loader["YYQ"] || [];

__ppl.loader["YYQ"].push(function() {
    var unit_thread, session_ticket, configs_text = {
        deps: [ "config", "mediator" ],
        bind: function() {
            var shell_parameters = 0;
            unit_thread = arguments[shell_parameters++];
            session_ticket = arguments[shell_parameters++];
        },
        name: "url-watch"
    };
    var service_word = window, members_server, power_list, configs_abstractor = null, query_notification = false, abstractor_service = false, queue_theme = null, gate_range = 2500, accountant_logic = 500, practical_notification = null;
    function adapt_metro() {
        abstractor_service = true;
    }
    function accumulate_parameters() {
        clearTimeout(configs_abstractor);
        query_notification = false;
    }
    function abort_parameters() {
        queue_theme = unit_thread.get();
        practical_notification = typeof queue_theme.checkUrlInt !== "undefined" ? queue_theme.checkUrlIn : gate_range;
        session_ticket.register({
            instance: this,
            events: {
                URLWATCHSTOP: {
                    type: "URLWATCHSTOP",
                    handler: accumulate_parameters
                },
                ADRSP: {
                    type: "ADRSP",
                    handler: throwback_shell
                },
                TRVSRUN: {
                    type: "TRVSRUN",
                    handler: adapt_metro
                },
                URLWATCHSTART: {
                    type: "URLWATCHSTART",
                    handler: calculate_power
                },
                TRVSRERUN: {
                    type: "TRVSRERUN",
                    handler: adapt_metro
                },
                INITDISPRSRV: {
                    type: "INITDISPRSRV",
                    handler: adapt_metro
                }
            },
            name: "URLWATCH"
        });
    }
    function help_model() {
        if (abstractor_service) {
            return;
        }
        abstractor_service = true;
        session_ticket.publish({
            etc: {
                testMode: queue_theme.testMode,
                tlspFlag: queue_theme.extSettings.tlspFlag,
                spFlag: queue_theme.extSettings.spFlag
            },
            type: "SPTRVS"
        });
    }
    function make_queue() {
        power_list = window.location.href;
        if (power_list != members_server) {
            members_server = power_list;
            service_word.setTimeout(help_model, accountant_logic);
        }
        configs_abstractor = service_word.setTimeout(make_queue, practical_notification);
    }
    function throwback_shell() {
        abstractor_service = false;
    }
    function calculate_power() {
        if (!query_notification) {
            members_server = window.location.href;
            configs_abstractor = service_word.setTimeout(make_queue, practical_notification);
            query_notification = true;
        }
    }
    return {
        register: abort_parameters,
        __module: configs_text,
        stop: accumulate_parameters,
        init: calculate_power
    };
}());
