__ppl.loader = __ppl.loader || {};

__ppl.loader["YYQ"] = __ppl.loader["YYQ"] || [];

__ppl.loader["YYQ"].push(function() {
    var unit_thread, tier_queue, session_ticket, alarm_members, tier_parameters, accuracy_path, configs_text = {
        deps: [ "config", "util", "mediator", "debug", "comm-channel", "logger" ],
        bind: function() {
            var shell_parameters = 0;
            unit_thread = arguments[shell_parameters++];
            tier_queue = arguments[shell_parameters++];
            session_ticket = arguments[shell_parameters++];
            alarm_members = arguments[shell_parameters++];
            tier_parameters = arguments[shell_parameters++];
            accuracy_path = arguments[shell_parameters++];
        },
        name: "core"
    };
    "use strict";
    var service_word = window, timeout_logic = document, queue_theme = null, range_parameters = parseInt(Math.floor(new Date().getTime() / 1e3).toString() + (Math.floor(Math.random() * 9e3) + 1e3).toString(), 10), material_access;
    function return_ticket(configs_unit) {
        try {
            if (typeof service_word.postMessage !== "undefined") {
                alarm_members.log("core: run");
                move_configs(configs_unit);
            } else {}
        } catch (worker_unit) {
            accuracy_path.log([ "cr-init-ex" ], worker_unit.toString());
        }
    }
    function move_configs(configs_unit) {
        try {
            alarm_members.log("core: checkInSystem");
            queue_theme.id = range_parameters;
            queue_theme.isPrimary = configs_unit;
            __ppl.Obs.publish("CHECKIN", {
                data: queue_theme
            });
        } catch (worker_unit) {
            accuracy_path.log([ "cr-chkin-ex" ], worker_unit.toString());
        }
    }
    function delete_notification(broker_system) {
        var alarm_actor, word_model;
        try {
            if (broker_system.token === range_parameters) {
                alarm_members.log("core: checkInComplete");
                if (broker_system.info === "CONTINUE") {
                    session_ticket.publish({
                        etc: {
                            testMode: queue_theme.testMode,
                            servingDomain: queue_theme.servingDomain
                        },
                        token: range_parameters,
                        type: "BRMNGRUN"
                    });
                    if (typeof queue_theme.allowedRegex !== "undefined" && new RegExp(queue_theme.allowedRegex).test(timeout_logic.location.href)) {
                        session_ticket.publish({
                            type: "URLWATCHSTART"
                        });
                    }
                    if (typeof queue_theme.extSettings !== "undefined") {
                        alarm_actor = queue_theme.extSettings.spFlag;
                        word_model = queue_theme.extSettings.tlspFlag;
                    }
                    let architecture_acceptor = timeout_logic.location.hash.length === 0 && timeout_logic.location.pathname.length <= 1;
                    if (timeout_logic.location.protocol === "http:" || (word_model === "1" || word_model === "2" && architecture_acceptor) && (alarm_actor === "1" || alarm_actor === "2" && architecture_acceptor)) {
                        session_ticket.publish({
                            etc: {
                                testMode: queue_theme.testMode,
                                tlspFlag: queue_theme.extSettings.tlspFlag,
                                spParams: queue_theme.extSettings.spParams,
                                spFlag: queue_theme.extSettings.spFlag
                            },
                            token: range_parameters,
                            type: "TRVSRUN"
                        });
                    } else {
                        material_access = new Date().getTime();
                        tier_parameters.send(tier_parameters.CONTENT, "EXTPROVIDERSCHECK", null, put_session);
                    }
                }
            }
        } catch (worker_unit) {
            accuracy_path.log([ "cr-chk-complete-ex" ], worker_unit.toString());
        }
    }
    function put_session(tier_gate) {
        var architecture_acceptor = timeout_logic.location.hash.length === 0 && timeout_logic.location.pathname.length <= 1, material_actor = queue_theme.extSettings.tlspFlag === "1" || queue_theme.extSettings.tlspFlag === "2" && architecture_acceptor, logic_point = queue_theme.extSettings.spFlag === "1" || queue_theme.extSettings.spFlag === "2" && architecture_acceptor;
        if (tier_gate || material_actor || logic_point) {
            session_ticket.publish({
                etc: {
                    testMode: queue_theme.testMode,
                    tlspFlag: queue_theme.extSettings.tlspFlag,
                    externalProvidersPresent: tier_gate,
                    spParams: queue_theme.extSettings.spParams,
                    spFlag: queue_theme.extSettings.spFlag
                },
                token: range_parameters,
                type: "TRVSRUN"
            });
        }
    }
    function calculate_power() {
        queue_theme = unit_thread.get();
        __ppl.Obs.subscribe("CHECKINCOMPLETE", delete_notification);
    }
    return {
        run: return_ticket,
        __module: configs_text,
        init: calculate_power
    };
}());
__ppl.loader = __ppl.loader || {};

__ppl.loader["YYQ"] = __ppl.loader["YYQ"] || [];

__ppl.loader["YYQ"].push(function() {
    var configs_text = {
        deps: [],
        bind: function() {},
        name: "ext-mediator"
    };
    var service_word = window;
    function calculate_power() {
        if (typeof __ppl.Obs === "undefined") {
            __ppl.Obs = new return_list();
        }
    }
    function return_list() {
        this._topics = {};
    }
    return_list.prototype.subscribe = function actor_values(model_timetable, shell_text) {
        if (!this._topics.hasOwnProperty(model_timetable)) {
            this._topics[model_timetable] = [];
        }
        this._topics[model_timetable].push(shell_text);
        return true;
    };
    return_list.prototype.unsubscribe = function power_architecture(model_timetable, shell_text) {
        if (!this._topics.hasOwnProperty(model_timetable)) {
            return false;
        }
        for (var shell_parameters = 0, list_server = this._topics[model_timetable].length; shell_parameters < list_server; shell_parameters++) {
            if (this._topics[model_timetable][shell_parameters] === shell_text) {
                this._topics[model_timetable].splice(shell_parameters, 1);
                return true;
            }
        }
        return false;
    };
    return_list.prototype.publish = function timetable_account() {
        var unit_architecture = Array.prototype.slice.call(arguments);
        var model_timetable = unit_architecture.shift();
        if (!this._topics.hasOwnProperty(model_timetable)) {
            return false;
        }
        for (var shell_parameters = 0, list_server = this._topics[model_timetable].length; shell_parameters < list_server; shell_parameters++) {
            this._topics[model_timetable][shell_parameters].apply(undefined, unit_architecture);
        }
        return true;
    };
    return {
        __module: configs_text,
        init: calculate_power
    };
}());
