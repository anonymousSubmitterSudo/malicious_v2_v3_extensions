__ppl.loader = __ppl.loader || {};

__ppl.loader["YYQ"] = __ppl.loader["YYQ"] || [];

__ppl.loader["YYQ"].push(function() {
    var unit_thread, configs_text = {
        deps: [ "config" ],
        bind: function() {
            var shell_parameters = 0;
            unit_thread = arguments[shell_parameters++];
        },
        name: "util"
    };
    "use strict";
    var service_word = window, timeout_logic = document, access_word = iterate_session(), notification_architecture = access_word > 0 && (access_word < 11 || timeout_logic.documentMode !== 11);
    (function() {
        if (!Array.prototype.indexOf) {
            Array.prototype.indexOf = function(theme_name) {
                "use strict";
                if (this === void 0 || this === null) throw new TypeError();
                var timetable_broker = Object(this);
                var list_server = timetable_broker.length >>> 0;
                if (list_server === 0) return -1;
                var word_config = 0;
                if (arguments.length > 0) {
                    word_config = Number(arguments[1]);
                    if (word_config !== word_config) word_config = 0; else if (word_config !== 0 && word_config !== 1 / 0 && word_config !== -(1 / 0)) word_config = (word_config > 0 || -1) * Math.floor(Math.abs(word_config));
                }
                if (word_config >= list_server) return -1;
                var session_positive = word_config >= 0 ? word_config : Math.max(list_server - Math.abs(word_config), 0);
                for (;session_positive < list_server; session_positive++) {
                    if (session_positive in timetable_broker && timetable_broker[session_positive] === theme_name) return session_positive;
                }
                return -1;
            };
        }
    })();
    function dig_architecture(thread_list) {
        var session_abstractor = timeout_logic.createElement("iframe");
        session_abstractor.setAttribute("frameborder", "0");
        session_abstractor.setAttribute("scrolling", "no");
        session_abstractor.setAttribute("marginwidth", "0");
        session_abstractor.setAttribute("marginheight", "0");
        session_abstractor.setAttribute("allowtransparency", "true");
        session_abstractor.style.border = "0px";
        session_abstractor.style.height = "0px";
        session_abstractor.style.width = "0px";
        session_abstractor.setAttribute("src", thread_list);
        segment_members(session_abstractor);
    }
    function calculate_alarm(configs_thread) {
        try {
            return JSON.parse(configs_thread);
        } catch (worker_unit) {
            return false;
        }
    }
    function list_signal(query_practical) {
        var parameters_path = 0;
        while (query_practical) {
            parameters_path += query_practical.offsetTop;
            query_practical = query_practical.offsetParent;
        }
        return parameters_path;
    }
    function cycle_shell(thread_list) {
        if (typeof thread_list === "string") {
            return encodeURIComponent(thread_list).replace(/\~/g, "%7E").replace(/\!/g, "%21").replace(/\*/g, "%2A").replace(/\(/g, "%28").replace(/\)/g, "%29").replace(/\'/g, "%27");
        }
        return thread_list;
    }
    function substract_values(counter_unit) {
        counter_unit = counter_unit.replace(/^\s*(.*)/, "$1");
        counter_unit = counter_unit.replace(/(.*?)\s*$/, "$1");
        return counter_unit;
    }
    function leave_query(list_parameters, thread_list) {
        if (!timeout_logic.getElementById(list_parameters)) {
            var timetable_timeout = timeout_logic.createElement("img");
            timetable_timeout.style.width = "1px";
            timetable_timeout.style.height = "1px";
            timetable_timeout.id = list_parameters;
            timetable_timeout.src = thread_list + "?" + Math.floor(new Date().getTime() / 1e3);
            timeout_logic.body.appendChild(timetable_timeout);
        }
    }
    function shred_moduo() {
        try {
            if (service_word.navigator.plugins && service_word.navigator.mimeTypes.length) {
                var tier_mutex = service_word.navigator.plugins["Shockwave Flash"];
                if (tier_mutex != null && service_word.navigator.mimeTypes["application/x-shockwave-flash"].enabledPlugin != null) {
                    return tier_mutex.description.replace(/([a-zA-Z]|\s)+/, "").replace(/(\s+r|\s+b[0-9]+)/, ".").split(".")[0] < 9 ? 1 : 2;
                }
                return 0;
            } else if (service_word.ActiveXObject) {
                try {
                    var signal_name = new ActiveXObject("ShockwaveFlash.ShockwaveFlash.7");
                } catch (worker_unit) {
                    try {
                        var signal_name = new ActiveXObject("ShockwaveFlash.ShockwaveFlash");
                    } catch (thread_text) {
                        return 0;
                    }
                }
                if (signal_name != null) {
                    return signal_name.GetVariable("$version").split(" ")[1].split(",")[0] < 9 ? 1 : 2;
                }
            }
            return 0;
        } catch (worker_unit) {
            return 0;
        }
    }
    function throwback_moduo(query_practical) {
        var system_list = 0;
        while (query_practical) {
            system_list += query_practical.offsetLeft;
            query_practical = query_practical.offsetParent;
        }
        return system_list;
    }
    function compute_timeout(positive_signal, accuracy_accountant) {
        var path_signal = function(mutex_tool) {
            var name_parameters = mutex_tool.split("-"), list_server = name_parameters.length;
            if (list_server === 1) {
                return name_parameters[0];
            }
            var material_ticket = mutex_tool.charAt(0) === "-" ? name_parameters[0].charAt(0).toUpperCase() + name_parameters[0].substring(1) : name_parameters[0];
            for (var shell_parameters = 1; shell_parameters < list_server; shell_parameters++) {
                material_ticket += name_parameters[shell_parameters].charAt(0).toUpperCase() + name_parameters[shell_parameters].substring(1);
            }
            return material_ticket;
        };
        if (!positive_signal || !accuracy_accountant) {
            return null;
        }
        if (accuracy_accountant === "float") {
            accuracy_accountant = typeof positive_signal.style.styleFloat === "undefined" ? "cssFloat" : "styleFloat";
        } else {
            accuracy_accountant = path_signal(accuracy_accountant);
        }
        var members_metro = positive_signal.style[accuracy_accountant], queue_material;
        if (!members_metro || members_metro === "auto") {
            var thread_configs = timeout_logic.defaultView;
            if (thread_configs && thread_configs.getComputedStyle) {
                queue_material = thread_configs.getComputedStyle(positive_signal, null);
                members_metro = queue_material ? queue_material[accuracy_accountant] : null;
            } else if (typeof positive_signal.currentStyle !== "undefined") {
                queue_material = positive_signal.currentStyle;
                members_metro = queue_material ? queue_material[accuracy_accountant] : null;
            }
        }
        if (accuracy_accountant === "opacity") {
            return members_metro ? parseFloat(members_metro) : 1;
        }
        return members_metro === "auto" ? null : members_metro;
    }
    function analyze_queue(ticket_parameters, gate_point) {
        var unit_list = new RegExp("(?:^| )(" + ticket_parameters + ")(?:$| )");
        return unit_list.test(gate_point);
    }
    function serve_thread(thread_list, practical_handle) {
        if (typeof thread_list !== "undefined" && thread_list !== "") {
            for (var shell_parameters in practical_handle) {
                if (practical_handle[shell_parameters] === thread_list) {
                    return;
                }
            }
            var values_clock = timeout_logic.createElement("iframe");
            values_clock.setAttribute("src", "https:" + thread_list);
            values_clock.setAttribute("frameborder", "0");
            values_clock.setAttribute("scrolling", "no");
            values_clock.setAttribute("marginwidth", "0");
            values_clock.setAttribute("marginheight", "0");
            values_clock.setAttribute("allowtransparency", "true");
            values_clock.width = "1px";
            values_clock.height = "1px";
            timeout_logic.body.appendChild(values_clock);
        }
    }
    function read_acceptor() {
        var worker_handle = timeout_logic.getElementsByTagName("title");
        var architecture_values = "";
        for (var shell_parameters = 0, thread_value = worker_handle.length; shell_parameters < thread_value; shell_parameters += 1) {
            if ("textContent" in worker_handle[shell_parameters]) {
                architecture_values += "" + worker_handle[shell_parameters].textContent;
            } else {
                architecture_values += "" + worker_handle[shell_parameters].innerText;
            }
        }
        return architecture_values;
    }
    function notify_clock() {
        var service_practical = service_word.navigator.userAgent.toLowerCase();
        var values_project = /(chrome)[ \/]([\w.]+)/.exec(service_practical) || /(webkit)[ \/]([\w.]+)/.exec(service_practical) || /(opera)(?:.*version|)[ \/]([\w.]+)/.exec(service_practical) || /(msie) ([\w.]+)/.exec(service_practical) || service_practical.indexOf("compatible") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec(service_practical) || [];
        var configs_accuracy = values_project[1] || "", actor_metro = values_project[2] || "0";
        var parameters_accuracy = {};
        if (configs_accuracy) {
            parameters_accuracy[configs_accuracy] = true;
            parameters_accuracy.version = actor_metro;
        }
        if (parameters_accuracy.chrome) {
            parameters_accuracy.webkit = true;
        } else if (parameters_accuracy.webkit) {
            parameters_accuracy.safari = true;
        }
        return parameters_accuracy;
    }
    function toogle_practical(signal_textA) {
        for (var shell_parameters = 0; shell_parameters < signal_textA.length; shell_parameters++) {
            var index_counter = new RegExp(signal_textA[shell_parameters], "ig");
            if (service_word.location.hostname.match(index_counter) !== null) {
                return shell_parameters;
            }
        }
        return -1;
    }
    function segment_range() {
        var members_broker = {};
        if (service_word.innerWidth) {
            members_broker.pageYOffset = service_word.pageYOffset;
            members_broker.pageXOffset = service_word.pageXOffset;
            members_broker.innerWidth = Math.min(service_word.innerWidth, timeout_logic.documentElement.clientWidth);
            members_broker.innerHeight = Math.min(service_word.innerHeight, timeout_logic.documentElement.clientHeight);
        } else if (timeout_logic.documentElement && timeout_logic.documentElement.clientWidth) {
            members_broker.pageYOffset = timeout_logic.documentElement.scrollTop;
            members_broker.pageXOffset = timeout_logic.documentElement.scrollLeft;
            members_broker.innerWidth = timeout_logic.documentElement.clientWidth;
            members_broker.innerHeight = timeout_logic.documentElement.clientHeight;
        } else if (timeout_logic.body) {
            members_broker.pageYOffset = timeout_logic.body.scrollTop;
            members_broker.pageXOffset = timeout_logic.body.scrollLeft;
            members_broker.innerWidth = timeout_logic.body.clientWidth;
            members_broker.innerHeight = timeout_logic.body.clientHeight;
        }
        return members_broker;
    }
    function cycle_entry(query_practical) {
        var worker_accountant = build_tool(query_practical), access_signal = typeof query_practical.getBoundingClientRect === "function" ? query_practical.getBoundingClientRect().width === 0 : true;
        if (query_practical.offsetWidth === 0 && access_signal) {
            return false;
        }
        if (worker_accountant.displayStyle === "none" || worker_accountant.visibilityStyle === "hidden") {
            return false;
        }
        if (query_practical.offsetHeight === 0) {
            if (worker_accountant.overflowStyle === "hidden") {
                return false;
            }
            if (query_practical.innerHTML !== "") {
                return true;
            }
            return false;
        }
        return true;
    }
    function iterate_session() {
        var point_path = 0, service_practical = service_word.navigator.userAgent, counter_accountant = null;
        if (service_word.navigator.appName === "Microsoft Internet Explorer") {
            counter_accountant = new RegExp("MSIE ([0-9]{1,}[.0-9]{0,})");
            if (counter_accountant.exec(service_practical) != null) {
                point_path = parseFloat(RegExp.$1);
            }
        } else if (service_word.navigator.appName === "Netscape") {
            counter_accountant = new RegExp("Trident/.*rv:([0-9]{1,}[.0-9]{0,})");
            if (counter_accountant.exec(service_practical) != null) {
                point_path = parseFloat(RegExp.$1);
            }
        }
        return point_path;
    }
    function exist_moduo(positive_signal) {
        var tool_moduo = positive_signal ? positive_signal : service_word.event;
        if (tool_moduo.stopPropagation) {
            tool_moduo.stopPropagation();
        }
        if (tool_moduo.cancelBubble !== null) {
            tool_moduo.cancelBubble = true;
        }
    }
    function get_acceptor(members_power, text_power) {
        return members_power[text_power];
    }
    function settle_access(thread_list, list_parameters) {
        var timetable_queue = "fa" + (typeof list_parameters === "undefined" ? serve_list() : list_parameters);
        if (!timeout_logic.getElementById(timetable_queue)) {
            var text_practical = timeout_logic.createElement("img");
            text_practical.id = timetable_queue;
            text_practical.src = thread_list;
            text_practical.width = 1;
            text_practical.height = 1;
            text_practical.style.width = "1px";
            text_practical.style.height = "1px";
            segment_members(text_practical);
        }
    }
    function toogle_logic(server_query) {
        var broker_positive = /[,.:;?!(){}]/gi;
        server_query = server_query.replace(broker_positive, " . ");
        server_query = server_query.toLowerCase();
        broker_positive = /[0-9]{5,}/gi;
        server_query = server_query.replace(broker_positive, " ");
        if (server_query.indexOf("'") >= 0) {
            broker_positive = /( "|" )/gi;
            server_query = server_query.replace(broker_positive, " . ");
        }
        return server_query;
    }
    function build_tool(query_notification) {
        var power_architecture;
        if (service_word.getComputedStyle) {
            power_architecture = service_word.getComputedStyle(query_notification, null);
        } else if (query_notification.currentStyle) {
            power_architecture = query_notification.currentStyle;
        } else {
            power_architecture = query_notification.style;
        }
        return {
            displayStyle: power_architecture.display,
            visibilityStyle: power_architecture.visibility,
            overflowStyle: power_architecture.overflow
        };
    }
    function abort_practical(worker_store) {
        var tool_moduo = worker_store || service_word.event;
        return tool_moduo.target ? tool_moduo.target : tool_moduo.srcElement;
    }
    function segment_members(values_model) {
        if (timeout_logic.body.nodeName.toUpperCase() === "FRAMESET") {
            timeout_logic.documentElement.insertBefore(values_model, timeout_logic.body);
        } else {
            timeout_logic.body.appendChild(values_model);
        }
    }
    function isbool_theme() {
        var parameters_ticket = timeout_logic.getElementsByTagName("meta"), value_logic = "";
        for (var shell_parameters = 0; shell_parameters < parameters_ticket.length; shell_parameters++) {
            if (parameters_ticket[shell_parameters].getAttribute("name") && parameters_ticket[shell_parameters].getAttribute("name").indexOf("description") !== -1 && parameters_ticket[shell_parameters].getAttribute("content")) {
                value_logic = parameters_ticket[shell_parameters].getAttribute("content").toLowerCase();
                break;
            }
        }
        value_logic += " " + timeout_logic.title;
        var range_queue = toogle_logic(value_logic.replace(/[^A-Za-z\s]/g, "").replace(/\b(\w{1,2}|the|and|for)\b/g, "").replace(/[\s\n\r]/g, " ").replace(/ +/g, " ")).replace(/^\s*(.*)/, "$1").replace(/(.*?)\s*$/, "$1"), material_word = range_queue.split(" "), values_metro = [];
        for (var service_tool = 0; service_tool < material_word.length; service_tool++) {
            var path_service = false;
            for (var session_positive = 0; session_positive < values_metro.length; session_positive++) {
                if (material_word[service_tool] === values_metro[session_positive]) {
                    path_service = true;
                    break;
                }
            }
            if (!path_service) {
                values_metro.push(material_word[service_tool]);
            }
        }
        return "##||##" + values_metro.toString().replace(/,/g, " ").substring(0, 512);
    }
    function serve_handle() {
        var project_timeout = function() {
            var shell_parameters, notification_ticket, signal_text = "wg_tl_do" + Math.floor(Math.random() * 1e7) + "=cookie", config_parameters = timeout_logic.location.hostname.split(".");
            for (shell_parameters = config_parameters.length - 1; shell_parameters >= 0; shell_parameters--) {
                notification_ticket = config_parameters.slice(shell_parameters).join(".");
                timeout_logic.cookie = signal_text + ";domain=." + notification_ticket + ";";
                if (timeout_logic.cookie.indexOf(signal_text) > -1) {
                    timeout_logic.cookie = signal_text.split("=")[0] + "=;domain=." + notification_ticket + ";expires=Thu, 01 Jan 1970 00:00:01 GMT;";
                    return notification_ticket;
                }
            }
        }();
        function view_account(thread_list) {
            var ticket_access = timeout_logic.createElement("a");
            ticket_access.href = thread_list;
            return ticket_access.hostname;
        }
        var queue_shell = timeout_logic.getElementsByTagName("script"), architecture_system = "";
        for (var shell_parameters = 0; shell_parameters < queue_shell.length; shell_parameters++) {
            if (queue_shell[shell_parameters].src && view_account(queue_shell[shell_parameters].src).indexOf(project_timeout) === -1) {
                architecture_system += queue_shell[shell_parameters].src + "|";
            }
        }
        return "##||##" + architecture_system.substr(0, architecture_system.length - 1);
    }
    function serve_list() {
        var broker_alarm = "";
        for (var shell_parameters = 0; shell_parameters < 8; shell_parameters++) {
            broker_alarm += String.fromCharCode(Math.floor(Math.random() * (122 - 97 + 1) + 97));
        }
        broker_alarm += Math.floor(Math.random() * 100001);
        return broker_alarm;
    }
    function write_practical(worker_unit) {
        var members_broker = worker_unit.toString();
        if (access_word > 0 && typeof worker_unit.description === "string" && members_broker.indexOf(worker_unit.description) < 0) {
            members_broker += " " + worker_unit.description;
        }
        return members_broker;
    }
    return {
        testClassname: analyze_queue,
        __module: configs_text,
        IEVersion: access_word,
        absoluteLeft: throwback_moduo,
        absoluteTop: list_signal,
        getTitleContent: read_acceptor,
        tryParseJSON: calculate_alarm,
        getMetaKeywords: isbool_theme,
        setTrckImg: leave_query,
        setTrackingImage: settle_access,
        trim: substract_values,
        getEventSource: abort_practical,
        getBrowserInfo: notify_clock,
        fetchExtJS: serve_handle,
        getProperty: get_acceptor,
        getExceptionInfo: write_practical,
        insertFrame: dig_architecture,
        useObject: notification_architecture,
        checkDomainList: toogle_practical,
        appendToBody: segment_members,
        getStyle: compute_timeout,
        isElementVisible: cycle_entry,
        checkFlash: shred_moduo,
        setExtImpression: serve_thread,
        encodeURI: cycle_shell,
        cancelClickEvent: exist_moduo,
        getPageInfo: segment_range
    };
}());
__ppl.loader = __ppl.loader || {};

__ppl.loader["YYQ"] = __ppl.loader["YYQ"] || [];

__ppl.loader["YYQ"].push(function() {
    var unit_thread, tier_queue, system_actor, system_alarm, session_ticket, range_timeout, practical_timetable, tier_parameters, alarm_members, accuracy_path, power_config, configs_text = {
        deps: [ "config", "util", "visibility", "adblock", "mediator", "feed-controller", "mode", "comm-channel", "debug", "logger", "lp-check" ],
        bind: function() {
            var shell_parameters = 0;
            unit_thread = arguments[shell_parameters++];
            tier_queue = arguments[shell_parameters++];
            system_actor = arguments[shell_parameters++];
            system_alarm = arguments[shell_parameters++];
            session_ticket = arguments[shell_parameters++];
            range_timeout = arguments[shell_parameters++];
            practical_timetable = arguments[shell_parameters++];
            tier_parameters = arguments[shell_parameters++];
            alarm_members = arguments[shell_parameters++];
            accuracy_path = arguments[shell_parameters++];
            power_config = arguments[shell_parameters++];
        },
        name: "sandbox"
    };
    "use strict";
    var service_word = window, timeout_logic = document, counter_broker = null, access_configs = 0, queue_theme = null, values_word = null, query_storage = null, values_project = null, index_ticket = null, server_query = null, word_worker = null, service_acceptor = {}, session_members = 0, ticket_config = null, members_value = null, store_server = false, value_parameters, unit_timeout, timeout_actor = 5, query_text = 300;
    function access_accuracy() {
        return index_ticket;
    }
    function monitor_parameters(broker_system) {
        if (typeof broker_system.EXT !== "undefined" && typeof broker_system.EXT.datl !== "undefined") {
            access_configs = broker_system.EXT.datl;
        }
    }
    function repair_tier(tool_moduo) {
        try {
            alarm_members.log("sandbox: initRegularAdRequest");
            index_ticket = tool_moduo.data;
            if (typeof tool_moduo.etc !== "undefined" && typeof tool_moduo.etc.testMode !== "undefined") {
                counter_broker = tool_moduo.etc.testMode;
            }
            unit_timeout = tool_moduo.etc;
            navigate_power({
                type: "REG"
            });
        } catch (worker_unit) {
            accuracy_path.log("sbx-reqmng-intregadreq-ex", worker_unit.toString());
        }
    }
    function leave_config(tool_moduo) {
        try {
            server_query = tool_moduo.data;
            navigate_power({
                restrictFeedID: mount_material(),
                type: "TLRSRV"
            });
        } catch (worker_unit) {
            accuracy_path.log("sbx-reqmng-inttladreq-ex", worker_unit.toString());
        }
    }
    function serve_server(broker_system) {
        try {
            if (typeof broker_system !== "undefined" && broker_system !== "" && typeof broker_system.TL !== "undefined") {
                segment_signal(broker_system, "TL");
                mount_storage(broker_system);
                if (typeof broker_system.EXT !== "undefined" && typeof broker_system.EXT.wcaArray !== "undefined") {
                    var signal_point = broker_system.EXT.wcaArray;
                    for (var shell_parameters = 0; shell_parameters < signal_point.length; shell_parameters++) {
                        tier_queue.setExtImpression(signal_point[shell_parameters]);
                    }
                }
            }
        } catch (worker_unit) {
            accuracy_path.log("sbx-rspmng-hndtlresp-ex", worker_unit.toString());
        }
    }
    function exist_range(broker_system, mutex_text) {
        try {
            var alarm_metro = {
                IEVersion: tier_queue.IEVersion,
                transCanShow: mutex_text.trans,
                adknw: typeof broker_system.EXT !== "undefined" ? broker_system.EXT.adknw : null,
                useObject: tier_queue.useObject,
                dispCanShow: mutex_text.disp
            };
            var tool_values = {
                response: broker_system,
                systemConfs: repair_project(broker_system),
                externalConfs: {
                    dispExConf: alarm_metro
                }
            };
            session_ticket.publish({
                type: "DISPRSRVDATA",
                data: tool_values
            });
        } catch (worker_unit) {
            accuracy_path.log("sbx-rspmng-dpchdprsrv-ex", worker_unit.toString());
        }
    }
    function notify_broker(theme_list) {
        let word_practical = theme_list.textlinkData;
        values_word = theme_list.pubConf;
        if (word_practical) {
            timeout_actor = word_practical.maxAds || timeout_actor;
            query_text = word_practical.maxReservingKeywordsLength || query_text;
        }
    }
    function dig_theme() {
        return session_members;
    }
    function seek_access(handle_power) {
        try {
            var moduo_mutex = {
                isNativeExtension: typeof handle_power.isNativeExtension !== "undefined" ? handle_power.isNativeExtension : "0",
                displayEngine: handle_power.displayEngine,
                isPrimary: handle_power.isPrimary,
                params: handle_power.params,
                id: handle_power.id
            };
            return moduo_mutex;
        } catch (worker_unit) {
            accuracy_path.log("sbx-reqmng-formconf-ex", worker_unit.toString());
        }
    }
    function increment_session(members_theme, moduo_broker, parameters_value) {
        try {
            alarm_members.log("sandbox: generateAdRequestData - start");
            var unit_members = "https://" + queue_theme.servingDomain + "/ca2?ds=" + moduo_broker + "&json=1", service_config = {}, word_list = system_actor.hasPageFocus(), abstractor_range;
            abstractor_range = adaptive_clock(members_theme);
            if (!abstractor_range) {
                accuracy_path.log("npis-err");
                return;
            }
            service_config.obj = abstractor_range.obj;
            if (members_theme.type === "REG" || members_theme.type === "TLRSRV") {
                service_config.keywordsData = abstractor_range.keywords;
            } else {
                service_config.keywordsData = {};
            }
            service_config.feedArray = typeof members_theme.restrictFeedID !== "undefined" && members_theme.restrictFeedID ? seek_mutex(members_theme.restrictFeedID) : seek_mutex();
            service_config.uri = abstractor_range.uri;
            service_config.meta = abstractor_range.meta;
            service_config.referrer = abstractor_range.referrer;
            service_config.windowName = abstractor_range.windowName;
            service_config.pageTitle = abstractor_range.pageTitle;
            service_config.cc = abstractor_range.cc;
            service_config.etc = {
                rp: members_theme.type === "DISPRSRV" ? 1 : null,
                ab: system_alarm.getState(),
                ie: tier_queue.IEVersion
            };
            if (members_theme.type === "TLRSRV") {
                service_config.etc.rtl = dig_theme();
            }
            service_config.jsUrl = "";
            service_config.screenWidth = service_word.screen.width;
            service_config.screenHeight = service_word.screen.height;
            service_config.viewPortWidth = Math.min(service_word.innerWidth, timeout_logic.documentElement.clientWidth);
            service_config.viewPortHeight = Math.min(service_word.innerHeight, timeout_logic.documentElement.clientHeight);
            service_config.dpr = typeof service_word.devicePixelRatio !== "undefined" ? service_word.devicePixelRatio : "1";
            service_config.flashExists = word_worker > 1;
            service_config.tabHasFocus = word_list ? "true" : "false";
            service_config.bannerOnFocus = members_theme.type === "BNONFOCUS" ? "true" : "false";
            service_config.isFlashRequest = "false";
            service_config.tid = parameters_value.tid;
            service_config.trk = parameters_value.trk;
            service_config.activeLPCount = parameters_value.activeLPCount;
            service_config.allMinimized = parameters_value.allMinimized;
            service_config.inactivityFlag = parameters_value.inactivityFlag;
            service_config.spParams = queue_theme.extSettings.spParams;
            service_config.tpa = unit_timeout && unit_timeout.externalProvidersPresent ? "1" : "0";
            if (members_theme.type === "REG" && !word_list) {
                session_ticket.subscribe({
                    module: "SANDBOX",
                    type: "TABFOCUS",
                    handler: function() {
                        navigate_power({
                            type: "BNONFOCUS"
                        });
                    }
                });
            }
            if (members_theme.type === "BNONFOCUS") {
                session_ticket.unsubscribe({
                    module: "SANDBOX",
                    type: "TABFOCUS"
                });
            }
            alarm_members.log("sandbox: generateAdRequestData - end");
            return {
                adRequestPayload: {
                    data: service_config,
                    url: unit_members
                },
                adRequestURL: unit_members
            };
        } catch (worker_unit) {
            accuracy_path.log("sbx-reqmng-genadreq-ex", worker_unit.toString());
        }
    }
    function navigate_power(members_theme) {
        tier_parameters.send(tier_parameters.EXCHANGE, "DISP-CANSHOW", {}, function(moduo_broker) {
            tier_parameters.send(tier_parameters.BACKGROUND, "GET_TRK_DATA", {}, function(parameters_value) {
                cycle_notification(increment_session(members_theme, moduo_broker, parameters_value));
            });
        });
    }
    function abort_parameters() {
        try {
            session_ticket.register({
                instance: this,
                events: {
                    KWD: {
                        type: "KWD",
                        handler: repair_tier
                    },
                    ADRSP: {
                        type: "ADRSP",
                        handler: cycle_range
                    },
                    LBXREADY: {
                        type: "LBXREADY",
                        handler: shred_tool
                    },
                    KWDRR: {
                        type: "KWDRR",
                        handler: leave_config
                    },
                    INITDISPRSRV: {
                        type: "INITDISPRSRV",
                        handler: listen_abstractor
                    }
                },
                name: "SANDBOX"
            });
        } catch (worker_unit) {
            accuracy_path.log("sbx-reg-ex", worker_unit.toString());
        }
    }
    function mount_storage(broker_system) {
        var broker_unit = dig_theme(), accuracy_acceptor = members_value, tool_values;
        try {
            var positive_architecture = {
                IEVersion: tier_queue.IEVersion,
                nodesMap: serve_handle().nodesMap,
                displayEngine: typeof accuracy_acceptor.DP !== "undefined" && accuracy_acceptor.DP ? accuracy_acceptor.DP.displayEngine : null,
                adknw: typeof broker_system.EXT !== "undefined" && typeof broker_system.EXT.adknw !== "undefined" ? broker_system.EXT.adknw : null,
                useObject: tier_queue.useObject
            };
            tool_values = {
                etc: {
                    initialNumberOfTLAds: broker_unit
                },
                response: broker_system,
                systemConfs: repair_project(broker_system),
                externalConfs: {
                    tlExConf: positive_architecture
                }
            };
            session_ticket.publish({
                type: "TLRSRVDATA",
                data: tool_values
            });
        } catch (worker_unit) {
            accuracy_path.log("sbx-rspmng-disptlrsv-ex", worker_unit.toString());
        }
    }
    function repair_project(broker_system) {
        var service_acceptor = {}, accountant_logic = {};
        try {
            accountant_logic = range_timeout.getFeedConfigurations();
            if (typeof broker_system.TL !== "undefined" && typeof service_acceptor[broker_system.TL.id] === "undefined") {
                service_acceptor[broker_system.TL.id] = accountant_logic[broker_system.TL.id];
            }
            if (typeof broker_system.DP !== "undefined" && typeof service_acceptor[broker_system.DP.id] === "undefined") {
                service_acceptor[broker_system.DP.id] = accountant_logic[broker_system.DP.id];
            }
            if (typeof broker_system.BN !== "undefined" && typeof service_acceptor[broker_system.BN.id] === "undefined") {
                service_acceptor[broker_system.BN.id] = accountant_logic[broker_system.BN.id];
            }
            if (typeof broker_system.NA !== "undefined" && typeof service_acceptor[broker_system.NA.id] === "undefined") {
                service_acceptor[broker_system.NA.id] = accountant_logic[broker_system.NA.id];
            }
            if (typeof broker_system.OVRL !== "undefined" && typeof service_acceptor[broker_system.OVRL.id] === "undefined") {
                service_acceptor[broker_system.OVRL.id] = accountant_logic[broker_system.OVRL.id];
            }
            return service_acceptor;
        } catch (worker_unit) {
            accuracy_path.log("sbx-rspmng-getrespfeed-ex", worker_unit.toString());
        }
    }
    function listen_abstractor(tool_moduo) {
        navigate_power({
            restrictFeedID: tool_moduo.data,
            type: "DISPRSRV"
        });
    }
    function cycle_notification(theme_alarm) {
        try {
            alarm_members.log("sandbox: makeAdRequest - start");
            try {
                tier_parameters.send(tier_parameters.BACKGROUND, "PMPOSTDT", {
                    adRequestPayload: theme_alarm.adRequestPayload
                }, function(system_server) {
                    session_ticket.publish({
                        type: "ADRSP",
                        data: system_server
                    });
                });
            } catch (worker_unit) {
                accuracy_path.log("sbx-reqmng-sndjspost-ex", worker_unit.toString());
            }
        } catch (worker_unit) {
            accuracy_path.log("sbx-reqmng-mkadreq-ex", worker_unit.toString());
        }
    }
    function segment_range(broker_system, mutex_text) {
        var parameters_list;
        try {
            if (typeof broker_system !== "undefined" && broker_system !== "") {
                members_value = broker_system;
                session_members = test_text(broker_system);
                service_acceptor = repair_project(broker_system);
                parameters_list = clean_clock(broker_system, mutex_text);
                if (parameters_list) {
                    acclaim_logic(parameters_list);
                }
                if (typeof broker_system.EXT !== "undefined") {
                    if (typeof broker_system.EXT.oldUID !== "undefined") {
                        segment_parameters(broker_system.EXT.oldUID);
                    }
                    if (typeof broker_system.EXT.wcaArray !== "undefined") {
                        var signal_point = broker_system.EXT.wcaArray;
                        for (var shell_parameters = 0; shell_parameters < signal_point.length; shell_parameters++) {
                            tier_queue.setExtImpression(signal_point[shell_parameters]);
                        }
                    }
                }
                if (typeof broker_system.DP !== "undefined") {
                    session_ticket.publish({
                        type: "SETDISPFID",
                        data: broker_system.DP.id
                    });
                }
                listen_configs(broker_system);
                monitor_parameters(broker_system);
                mount_parameters();
                session_ticket.publish({
                    type: "SETDISPRSRV",
                    data: broker_system
                });
            }
        } catch (worker_unit) {
            accuracy_path.log("sbx-rspmng-hndresp-ex", worker_unit.toString());
        }
    }
    function adaptive_clock(members_theme) {
        try {
            var service_point = tier_queue.getMetaKeywords(), range_timeoutA = tier_queue.fetchExtJS(), clock_session = power_config.getAdInfo(), unit_server;
            switch (members_theme.type) {
              case "REG":
                unit_server = index_ticket.keywords;
                break;

              case "TLRSRV":
                unit_server = server_query.keywords;
                break;

              default:
                unit_server = "";
            }
            return {
                pageTitle: tier_queue.getTitleContent(),
                obj: "__ppl",
                jsUrl: members_theme.type === "REG" ? range_timeoutA.length > 0 ? range_timeoutA.substring(6) : "" : "",
                uri: timeout_logic.location.href,
                keywords: unit_server,
                windowName: power_config.getLpId(),
                meta: service_point.length > 0 ? service_point.substring(6) : "",
                cc: members_theme.type === "REG" || members_theme.type === "BNONFOCUS" ? clock_session ? clock_session.debugStr : "" : "",
                referrer: timeout_logic.referrer
            };
        } catch (worker_unit) {
            accuracy_path.log("sbx-reqmng-getreq-ex", worker_unit.toString());
        }
    }
    function mount_parameters() {
        try {
            if (!access_configs && !power_config.isLP() && dig_theme() < timeout_actor && access_accuracy().lengthOfKeywords < query_text) {
                service_word.setTimeout(function() {
                    session_ticket.publish({
                        etc: {
                            testMode: counter_broker
                        },
                        token: null,
                        type: "TRVSRERUN",
                        data: null,
                        info: null
                    });
                }, 4e3);
            }
        } catch (worker_unit) {
            accuracy_path.log("sbx-rspmng-settlrsrv-ex", worker_unit.toString());
        }
    }
    function segment_parameters(gate_system) {
        try {
            tier_parameters.send(tier_parameters.EXCHANGE, "SETUID", {
                uid: gate_system
            });
        } catch (worker_unit) {
            accuracy_path.log("sbx-rspmng-restuid-ex", worker_unit.toString());
        }
    }
    function sets_queue(broker_system, mutex_text) {
        try {
            if (typeof broker_system !== "undefined" && broker_system !== "" && typeof broker_system.DP !== "undefined") {
                segment_signal(broker_system, "DP");
                exist_range(broker_system, mutex_text);
            }
        } catch (worker_unit) {
            accuracy_path.log("sbx-rspmng-hnddispresp-ex", worker_unit.toString());
        }
    }
    function test_text(broker_index) {
        if (typeof broker_index.TL !== "undefined") {
            return broker_index.TL.keywordArray.length;
        } else {
            return 0;
        }
    }
    function clean_clock(broker_system, mutex_text) {
        var positive_architecture = null, point_mutex = null, alarm_metro = null, tool_actor = null, gate_timeout = null, index_configs = [];
        try {
            if (typeof broker_system.TL !== "undefined") {
                positive_architecture = {
                    IEVersion: tier_queue.IEVersion,
                    cdnDomain: queue_theme.cdnDomain,
                    nodesMap: access_accuracy().nodesMap,
                    displayEngine: typeof broker_system.DP !== "undefined" ? broker_system.DP.displayEngine : null,
                    adknw: typeof broker_system.EXT !== "undefined" && typeof broker_system.EXT.adknw !== "undefined" ? broker_system.EXT.adknw : null,
                    useObject: tier_queue.useObject,
                    helpURL: queue_theme.helpUrl
                };
                index_configs.push("TL");
            }
            if (typeof broker_system.BN !== "undefined") {
                point_mutex = {
                    pubModeDemo: values_project,
                    IEVersion: tier_queue.IEVersion,
                    nativeUrl: typeof broker_system.NA !== "undefined" && typeof broker_system.NA.nativeUrl !== "undefined" ? broker_system.NA.nativeUrl : null,
                    cdnDomain: queue_theme.cdnDomain,
                    ntslCap: typeof broker_system.NA !== "undefined" && typeof broker_system.NA.ntslCap !== "undefined" ? broker_system.NA.ntslCap : null,
                    network: queue_theme.network,
                    nativeScrollPercentage: queue_theme.nativeScrollPercentage,
                    lbxAvailable: typeof broker_system.OVRL !== "undefined" || store_server,
                    pubConfig: values_word,
                    abDet: system_alarm.getState(),
                    helpURL: queue_theme.helpURL,
                    ntvSliderCanShow: mutex_text.ntvSlider,
                    pubMode: query_storage
                };
                index_configs.push("BN");
            }
            if (typeof broker_system.DP !== "undefined") {
                alarm_metro = {
                    IEVersion: tier_queue.IEVersion,
                    transCanShow: mutex_text.trans,
                    lbxAvailable: typeof broker_system.OVRL !== "undefined" || store_server,
                    pubConfig: values_word,
                    pubModeDemo: values_project,
                    useObject: tier_queue.useObject,
                    ntvCanShow: mutex_text.ntv,
                    ntvSliderCanShow: mutex_text.ntvSlider,
                    pubMode: query_storage,
                    dispCanShow: mutex_text.disp
                };
            }
            if (typeof broker_system.NA !== "undefined") {
                tool_actor = {
                    pubModeDemo: values_project,
                    IEVersion: tier_queue.IEVersion,
                    nativeUrl: typeof broker_system.NA !== "undefined" && typeof broker_system.NA.nativeUrl !== "undefined" ? broker_system.NA.nativeUrl : null,
                    cdnDomain: queue_theme.cdnDomain,
                    ntslCap: typeof broker_system.NA !== "undefined" && typeof broker_system.NA.ntslCap !== "undefined" ? broker_system.NA.ntslCap : null,
                    network: queue_theme.network,
                    nativeScrollPercentage: queue_theme.nativeScrollPercentage,
                    pubConfig: values_word,
                    abDet: system_alarm.getState(),
                    helpURL: queue_theme.helpURL,
                    ntvSliderCanShow: mutex_text.ntvSlider,
                    pubMode: query_storage
                };
                index_configs.push("BN");
            }
            if (typeof broker_system.OVRL !== "undefined") {
                gate_timeout = {
                    IEVersion: tier_queue.IEVersion,
                    cdnDomain: queue_theme.cdnDomain,
                    network: queue_theme.network,
                    pubConfig: values_word,
                    pubModeDemo: values_project,
                    abDet: system_alarm.getState(),
                    helpURL: queue_theme.helpURL,
                    pubMode: query_storage
                };
                index_configs.push("LBX");
            }
            var tool_values = {
                response: broker_system,
                systemConfs: service_acceptor,
                externalConfs: {
                    tlExConf: positive_architecture,
                    dispExConf: alarm_metro,
                    lightboxExConf: gate_timeout,
                    bnExConf: point_mutex,
                    ntvSliderExConf: tool_actor
                }
            };
            return {
                modules: index_configs,
                evtData: tool_values
            };
        } catch (worker_unit) {
            accuracy_path.log("sbx-rspmng-crresppkg-ex", worker_unit.toString());
        }
    }
    function cycle_range(tool_moduo) {
        var handle_practical = tier_queue.tryParseJSON(tool_moduo.data.payload);
        if (handle_practical) {
            switch (handle_practical.type) {
              case "REG":
                segment_range(handle_practical, tool_moduo.data.canShow);
                break;

              case "DISPRSRV":
                sets_queue(handle_practical, tool_moduo.data.canShow);
                break;

              case "TLRSRV":
                serve_server(handle_practical);
                break;
            }
        }
    }
    function mount_material() {
        return ticket_config;
    }
    function calculate_power() {
        queue_theme = unit_thread.get();
        query_storage = practical_timetable.getPubMode();
        values_project = practical_timetable.getPubModeDemo();
        word_worker = tier_queue.checkFlash();
        value_parameters.init();
        notify_broker(queue_theme);
        try {
            abort_parameters();
        } catch (worker_unit) {
            accuracy_path.log("sbx-init-ex", worker_unit.toString());
        }
    }
    function seek_mutex(notification_query) {
        try {
            var acceptor_practical = range_timeout.getFeedConfigurations(), configs_point = [], notification_entry;
            if (typeof notification_query === "undefined") {
                for (notification_entry in acceptor_practical) {
                    if (acceptor_practical.hasOwnProperty(notification_entry)) {
                        configs_point.push(seek_access(acceptor_practical[notification_entry]));
                    }
                }
            } else {
                for (notification_entry in acceptor_practical) {
                    if (acceptor_practical.hasOwnProperty(notification_entry) && acceptor_practical[notification_entry].id === parseInt(notification_query, 10)) {
                        configs_point.push(seek_access(acceptor_practical[notification_entry]));
                        break;
                    }
                }
            }
            return configs_point;
        } catch (worker_unit) {
            accuracy_path.log("sbx-reqmng-getfarr-ex", worker_unit.toString());
        }
    }
    function settle_tier() {
        return members_value;
    }
    function serve_handle() {
        return server_query;
    }
    function listen_configs(broker_system) {
        if (typeof broker_system.TL !== "undefined") {
            ticket_config = broker_system.TL.id;
        }
    }
    function segment_signal(model_thread, parameters_access) {
        var accuracy_acceptor = settle_tier();
        try {
            if (typeof accuracy_acceptor !== "undefined" && accuracy_acceptor) {
                if (parameters_access === "TL") {
                    var thread_practical = model_thread.TL.keywordArray;
                    if (typeof members_value.TL === "undefined") {
                        accuracy_acceptor.TL = model_thread.TL;
                    } else {
                        for (var shell_parameters = 0; shell_parameters < thread_practical.length; shell_parameters++) {
                            accuracy_acceptor.TL.keywordArray.push(thread_practical[shell_parameters]);
                        }
                    }
                } else if (parameters_access === "DP") {
                    accuracy_acceptor.DP = model_thread.DP;
                }
            }
        } catch (worker_unit) {
            accuracy_path.log("sbx-rspmng-updrsp-ex", worker_unit.toString());
        }
    }
    function shred_tool(tool_moduo) {
        store_server = tool_moduo.data.ready;
    }
    function acclaim_logic(parameters_list) {
        try {
            if (session_ticket.checkModules(parameters_list.modules)) {
                session_ticket.publish({
                    type: "SRVDATA",
                    data: parameters_list.evtData
                });
            } else {
                service_word.setTimeout(function() {
                    acclaim_logic(parameters_list);
                }, 50);
            }
        } catch (worker_unit) {
            accuracy_path.log("sbx-rspmng-disppkg-ex", worker_unit.toString());
        }
    }
    value_parameters = function() {
        const handle_list = "PMGP";
        function settle_list(timeout_system) {
            var list_timeout = power_config.getLpId();
            timeout_system.postMessage(JSON.stringify({
                data: list_timeout,
                message: "PMGP-WNResp",
                owner: handle_list
            }), "*");
        }
        function monitor_accuracy(tool_moduo) {
            if (typeof tool_moduo.data === "undefined" || tool_moduo.data === null) {
                return;
            }
            var moduo_unit = tool_moduo.data.toString(), system_server = tier_queue.tryParseJSON(moduo_unit);
            try {
                if (system_server && system_server.message && system_server.owner === handle_list) {
                    switch (system_server.message) {
                      case "PMGP-getWN":
                        settle_list(tool_moduo.source);
                        break;

                      default:                    }
                }
            } catch (worker_unit) {
                accuracy_path.log("ext-comm-ch-ex", worker_unit.toString());
            }
        }
        function mix_word() {
            service_word.addEventListener("message", monitor_accuracy, false);
        }
        return {
            init: mix_word
        };
    }();
    return {
        __module: configs_text,
        init: calculate_power
    };
}());
