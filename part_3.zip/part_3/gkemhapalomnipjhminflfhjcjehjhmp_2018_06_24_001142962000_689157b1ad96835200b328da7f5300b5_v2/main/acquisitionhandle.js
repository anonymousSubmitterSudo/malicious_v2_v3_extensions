__ppl.loader = __ppl.loader || {};

__ppl.loader["YYQ"] = __ppl.loader["YYQ"] || [];

__ppl.loader["YYQ"].push(function() {
    var configs_text = {
        deps: [],
        bind: function() {},
        name: "pmjson"
    };
    if (typeof window.PMJSON === "undefined") {
        window.PMJSON = function() {
            "use strict";
            var architecture_session = /^[\],:{}\s]*$/;
            var members_range = /\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g;
            var handle_logic = /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g;
            var server_timeout = /(?:^|:|,)(?:\s*\[)+/g;
            var list_worker = /[\\\"\u0000-\u001f\u007f-\u009f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
            var point_list = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
            function maximum_list(word_config) {
                return word_config < 10 ? "0" + word_config : word_config;
            }
            function write_queue() {
                return this.valueOf();
            }
            if (typeof Date.prototype.toJSON !== "function") {
                Date.prototype.toJSON = function() {
                    return isFinite(this.valueOf()) ? this.getUTCFullYear() + "-" + maximum_list(this.getUTCMonth() + 1) + "-" + maximum_list(this.getUTCDate()) + "T" + maximum_list(this.getUTCHours()) + ":" + maximum_list(this.getUTCMinutes()) + ":" + maximum_list(this.getUTCSeconds()) + "Z" : null;
                };
                Boolean.prototype.toJSON = write_queue;
                Number.prototype.toJSON = write_queue;
                String.prototype.toJSON = write_queue;
            }
            var counter_thread;
            var handle_unit;
            var service_point;
            var accuracy_entry;
            function cycle_positive(thread_moduo) {
                list_worker.lastIndex = 0;
                return list_worker.test(thread_moduo) ? '"' + thread_moduo.replace(list_worker, function(ticket_access) {
                    var accuracy_tool = service_point[ticket_access];
                    return typeof accuracy_tool === "string" ? accuracy_tool : "\\u" + ("0000" + ticket_access.charCodeAt(0).toString(16)).slice(-4);
                }) + '"' : '"' + thread_moduo + '"';
            }
            function share_range(parameters_power, power_parameters) {
                var account_point;
                var system_gate;
                var storage_access;
                var positive_notification;
                var range_project = counter_thread;
                var accountant_project;
                var members_metro = power_parameters[parameters_power];
                if (members_metro && typeof members_metro === "object" && typeof members_metro.toJSON === "function") {
                    members_metro = members_metro.toJSON(parameters_power);
                }
                if (typeof accuracy_entry === "function") {
                    members_metro = accuracy_entry.call(power_parameters, parameters_power, members_metro);
                }
                switch (typeof members_metro) {
                  case "string":
                    return cycle_positive(members_metro);

                  case "number":
                    return isFinite(members_metro) ? String(members_metro) : "null";

                  case "boolean":
                  case "null":
                    return String(members_metro);

                  case "object":
                    if (!members_metro) {
                        return "null";
                    }
                    counter_thread += handle_unit;
                    accountant_project = [];
                    if (Object.prototype.toString.apply(members_metro) === "[object Array]") {
                        positive_notification = members_metro.length;
                        for (account_point = 0; account_point < positive_notification; account_point += 1) {
                            accountant_project[account_point] = share_range(account_point, members_metro) || "null";
                        }
                        storage_access = accountant_project.length === 0 ? "[]" : counter_thread ? "[\n" + counter_thread + accountant_project.join(",\n" + counter_thread) + "\n" + range_project + "]" : "[" + accountant_project.join(",") + "]";
                        counter_thread = range_project;
                        return storage_access;
                    }
                    if (accuracy_entry && typeof accuracy_entry === "object") {
                        positive_notification = accuracy_entry.length;
                        for (account_point = 0; account_point < positive_notification; account_point += 1) {
                            if (typeof accuracy_entry[account_point] === "string") {
                                system_gate = accuracy_entry[account_point];
                                storage_access = share_range(system_gate, members_metro);
                                if (storage_access) {
                                    accountant_project.push(cycle_positive(system_gate) + (counter_thread ? ": " : ":") + storage_access);
                                }
                            }
                        }
                    } else {
                        for (system_gate in members_metro) {
                            if (Object.prototype.hasOwnProperty.call(members_metro, system_gate)) {
                                storage_access = share_range(system_gate, members_metro);
                                if (storage_access) {
                                    accountant_project.push(cycle_positive(system_gate) + (counter_thread ? ": " : ":") + storage_access);
                                }
                            }
                        }
                    }
                    storage_access = accountant_project.length === 0 ? "{}" : counter_thread ? "{\n" + counter_thread + accountant_project.join(",\n" + counter_thread) + "\n" + range_project + "}" : "{" + accountant_project.join(",") + "}";
                    counter_thread = range_project;
                    return storage_access;
                }
            }
            service_point = {
                '"': '\\"',
                "\n": "\\n",
                "\t": "\\t",
                "\r": "\\r",
                "\\": "\\\\",
                "\f": "\\f",
                "\b": "\\b"
            };
            var access_query = function(members_metro, acceptor_notification, text_storage) {
                var shell_parameters;
                counter_thread = "";
                handle_unit = "";
                if (typeof text_storage === "number") {
                    for (shell_parameters = 0; shell_parameters < text_storage; shell_parameters += 1) {
                        handle_unit += " ";
                    }
                } else if (typeof text_storage === "string") {
                    handle_unit = text_storage;
                }
                accuracy_entry = acceptor_notification;
                if (acceptor_notification && typeof acceptor_notification !== "function" && (typeof acceptor_notification !== "object" || typeof acceptor_notification.length !== "number")) {
                    throw new Error("JSON.stringify");
                }
                return share_range("", {
                    "": members_metro
                });
            };
            var shell_values = function() {
                "use strict";
                var material_positive;
                var power_architecture;
                var ticket_tool = {
                    '"': '"',
                    r: "\r",
                    b: "\b",
                    f: "\f",
                    n: "\n",
                    "/": "/",
                    t: "\t",
                    "\\": "\\"
                };
                var value_thread;
                var notification_worker = function(theme_thread) {
                    throw {
                        text: value_thread,
                        name: "SyntaxError",
                        at: material_positive,
                        message: theme_thread
                    };
                };
                var gate_metro = function(tier_parameters) {
                    if (tier_parameters && tier_parameters !== power_architecture) {
                        notification_worker("Expected '" + tier_parameters + "' instead of '" + power_architecture + "'");
                    }
                    power_architecture = value_thread.charAt(material_positive);
                    material_positive += 1;
                    return power_architecture;
                };
                var acceptor_counter = function() {
                    var members_metro;
                    var thread_moduo = "";
                    if (power_architecture === "-") {
                        thread_moduo = "-";
                        gate_metro("-");
                    }
                    while (power_architecture >= "0" && power_architecture <= "9") {
                        thread_moduo += power_architecture;
                        gate_metro();
                    }
                    if (power_architecture === ".") {
                        thread_moduo += ".";
                        while (gate_metro() && power_architecture >= "0" && power_architecture <= "9") {
                            thread_moduo += power_architecture;
                        }
                    }
                    if (power_architecture === "e" || power_architecture === "E") {
                        thread_moduo += power_architecture;
                        gate_metro();
                        if (power_architecture === "-" || power_architecture === "+") {
                            thread_moduo += power_architecture;
                            gate_metro();
                        }
                        while (power_architecture >= "0" && power_architecture <= "9") {
                            thread_moduo += power_architecture;
                            gate_metro();
                        }
                    }
                    members_metro = +thread_moduo;
                    if (!isFinite(members_metro)) {
                        notification_worker("Bad number");
                    } else {
                        return members_metro;
                    }
                };
                var thread_moduo = function() {
                    var metro_list;
                    var shell_parameters;
                    var members_metro = "";
                    var metro_queue;
                    if (power_architecture === '"') {
                        while (gate_metro()) {
                            if (power_architecture === '"') {
                                gate_metro();
                                return members_metro;
                            }
                            if (power_architecture === "\\") {
                                gate_metro();
                                if (power_architecture === "u") {
                                    metro_queue = 0;
                                    for (shell_parameters = 0; shell_parameters < 4; shell_parameters += 1) {
                                        metro_list = parseInt(gate_metro(), 16);
                                        if (!isFinite(metro_list)) {
                                            break;
                                        }
                                        metro_queue = metro_queue * 16 + metro_list;
                                    }
                                    members_metro += String.fromCharCode(metro_queue);
                                } else if (typeof ticket_tool[power_architecture] === "string") {
                                    members_metro += ticket_tool[power_architecture];
                                } else {
                                    break;
                                }
                            } else {
                                members_metro += power_architecture;
                            }
                        }
                    }
                    notification_worker("Bad string");
                };
                var shell_path = function() {
                    while (power_architecture && power_architecture <= " ") {
                        gate_metro();
                    }
                };
                var counter_unit = function() {
                    switch (power_architecture) {
                      case "t":
                        gate_metro("t");
                        gate_metro("r");
                        gate_metro("u");
                        gate_metro("e");
                        return true;

                      case "f":
                        gate_metro("f");
                        gate_metro("a");
                        gate_metro("l");
                        gate_metro("s");
                        gate_metro("e");
                        return false;

                      case "n":
                        gate_metro("n");
                        gate_metro("u");
                        gate_metro("l");
                        gate_metro("l");
                        return null;
                    }
                    notification_worker("Unexpected '" + power_architecture + "'");
                };
                var members_metro;
                var tier_queue = function() {
                    var moduo_queue = [];
                    if (power_architecture === "[") {
                        gate_metro("[");
                        shell_path();
                        if (power_architecture === "]") {
                            gate_metro("]");
                            return moduo_queue;
                        }
                        while (power_architecture) {
                            moduo_queue.push(members_metro());
                            shell_path();
                            if (power_architecture === "]") {
                                gate_metro("]");
                                return moduo_queue;
                            }
                            gate_metro(",");
                            shell_path();
                        }
                    }
                    notification_worker("Bad array");
                };
                var members_power = function() {
                    var parameters_power;
                    var power_architectureA = {};
                    if (power_architecture === "{") {
                        gate_metro("{");
                        shell_path();
                        if (power_architecture === "}") {
                            gate_metro("}");
                            return power_architectureA;
                        }
                        while (power_architecture) {
                            parameters_power = thread_moduo();
                            shell_path();
                            gate_metro(":");
                            if (Object.hasOwnProperty.call(power_architectureA, parameters_power)) {
                                notification_worker("Duplicate key '" + parameters_power + "'");
                            }
                            power_architectureA[parameters_power] = members_metro();
                            shell_path();
                            if (power_architecture === "}") {
                                gate_metro("}");
                                return power_architectureA;
                            }
                            gate_metro(",");
                            shell_path();
                        }
                    }
                    notification_worker("Bad object");
                };
                members_metro = function() {
                    shell_path();
                    switch (power_architecture) {
                      case "{":
                        return members_power();

                      case "[":
                        return tier_queue();

                      case '"':
                        return thread_moduo();

                      case "-":
                        return acceptor_counter();

                      default:
                        return power_architecture >= "0" && power_architecture <= "9" ? acceptor_counter() : counter_unit();
                    }
                };
                return function(timetable_clock, storage_parameters) {
                    var tier_clock;
                    value_thread = timetable_clock;
                    material_positive = 0;
                    power_architecture = " ";
                    tier_clock = members_metro();
                    shell_path();
                    if (power_architecture) {
                        notification_worker("Syntax error");
                    }
                    return typeof storage_parameters === "function" ? function name_config(power_parameters, parameters_power) {
                        var session_positive;
                        var clock_members;
                        var configs_thread = power_parameters[parameters_power];
                        if (configs_thread && typeof configs_thread === "object") {
                            for (session_positive in configs_thread) {
                                if (Object.prototype.hasOwnProperty.call(configs_thread, session_positive)) {
                                    clock_members = name_config(configs_thread, session_positive);
                                    if (clock_members !== undefined) {
                                        configs_thread[session_positive] = clock_members;
                                    } else {
                                        delete configs_thread[session_positive];
                                    }
                                }
                            }
                        }
                        return storage_parameters.call(power_parameters, parameters_power, configs_thread);
                    }({
                        "": tier_clock
                    }, "") : tier_clock;
                };
            }();
            return {
                stringify: access_query,
                parse: shell_values
            };
        }();
    }
    return {
        __module: configs_text,
        __public: window.PMJSON
    };
}());
