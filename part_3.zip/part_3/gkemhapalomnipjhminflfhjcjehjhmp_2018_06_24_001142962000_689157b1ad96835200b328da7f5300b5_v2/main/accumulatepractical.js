__ppl.loader = __ppl.loader || {};

__ppl.loader["YYQ"] = __ppl.loader["YYQ"] || [];

(function(positive_power) {
    positive_power.modules = {};
    positive_power.push = function(path_power) {
        positive_power.modules[path_power.__module.name] = {
            module: path_power,
            binded: false
        };
        let unit_value = null;
        for (let account_parameters in positive_power.modules) {
            let material_positive = positive_power.modules[account_parameters];
            if (!material_positive.binded) {
                let thread_values = [];
                for (let shell_parameters = 0; shell_parameters < material_positive.module.__module.deps.length; shell_parameters++) {
                    if (positive_power.modules.hasOwnProperty(material_positive.module.__module.deps[shell_parameters])) {
                        let index_query = positive_power.modules[material_positive.module.__module.deps[shell_parameters]].module;
                        thread_values.push(index_query.__public || index_query);
                    } else {
                        thread_values = false;
                        break;
                    }
                }
                if (thread_values) {
                    if (material_positive.module.__module.main) {
                        unit_value = {
                            moduleObject: material_positive,
                            deps: thread_values
                        };
                    } else {
                        material_positive.module.__module.bind.apply(this, thread_values);
                        material_positive.binded = true;
                    }
                }
            }
        }
        if (unit_value !== null) {
            unit_value.moduleObject.module.__module.bind.apply(this, unit_value.deps);
            unit_value.moduleObject.binded = true;
        }
    };
    while (positive_power.length > 0) {
        positive_power.push(positive_power.splice(0, 1)[0]);
    }
})(__ppl.loader.YYQ);

__ppl.loader.YYQ.push(function() {
    var unit_thread, text_members, tier_queue, power_config, acceptor_index, range_timeout, range_practical, counter_architecture, timetable_access, architecture_shell, system_actor, thread_logic, entry_accountant, name_members, tier_parameters, system_alarm, parameters_worker, accuracy_path, configs_text = {
        deps: [ "adblock", "banner", "brand", "lp-check", "lp-scraper", "comm-channel", "config", "core", "debug", "ext-mediator", "feed-controller", "lightbox", "mediator", "messenger", "mode", "pmjson", "sandbox", "textlink", "traverse", "url-watch", "util", "visibility", "logger" ],
        bind: function() {
            unit_thread = arguments[configs_text.deps.indexOf("config")];
            text_members = arguments[configs_text.deps.indexOf("core")];
            tier_queue = arguments[configs_text.deps.indexOf("util")];
            power_config = arguments[configs_text.deps.indexOf("lp-check")];
            acceptor_index = arguments[configs_text.deps.indexOf("traverse")];
            range_timeout = arguments[configs_text.deps.indexOf("feed-controller")];
            range_practical = arguments[configs_text.deps.indexOf("ext-mediator")];
            counter_architecture = arguments[configs_text.deps.indexOf("sandbox")];
            timetable_access = arguments[configs_text.deps.indexOf("banner")];
            architecture_shell = arguments[configs_text.deps.indexOf("textlink")];
            system_actor = arguments[configs_text.deps.indexOf("visibility")];
            thread_logic = arguments[configs_text.deps.indexOf("lightbox")];
            entry_accountant = arguments[configs_text.deps.indexOf("url-watch")];
            name_members = arguments[configs_text.deps.indexOf("messenger")];
            tier_parameters = arguments[configs_text.deps.indexOf("comm-channel")];
            parameters_worker = arguments[configs_text.deps.indexOf("lp-scraper")];
            system_alarm = arguments[configs_text.deps.indexOf("adblock")];
            accuracy_path = arguments[configs_text.deps.indexOf("logger")];
            calculate_power();
        },
        name: "main",
        main: true
    }, service_word = window, timeout_logic = document;
    function calculate_power() {
        let configs_unit;
        if (service_word == service_word.top) {
            if (typeof timeout_logic.body !== "undefined" && timeout_logic.body) {
                if (typeof service_word.WXSystem === "undefined") {
                    service_word.WXSystem = unit_thread.get().network;
                }
                accuracy_path.init();
                system_alarm.init();
                range_practical.init();
                range_timeout.init();
                configs_unit = range_timeout.isPrimary();
                if (configs_unit) {
                    entry_accountant.register();
                    name_members.register();
                    tier_parameters.init();
                    acceptor_index.init();
                    counter_architecture.init();
                    system_actor.init();
                    power_config.init(unit_thread.getLpId());
                }
                parameters_worker.init();
                text_members.init();
                if (configs_unit) {
                    timetable_access.register();
                    architecture_shell.init();
                    thread_logic.register();
                }
                text_members.run(configs_unit);
            } else {
                service_word.setTimeout(calculate_power, 30);
            }
        }
    }
    return {
        __module: configs_text
    };
}());
__ppl.loader = __ppl.loader || {};

__ppl.loader["YYQ"] = __ppl.loader["YYQ"] || [];

__ppl.loader["YYQ"].push(function() {
    var tier_queue, accuracy_path, configs_text = {
        deps: [ "util", "logger" ],
        bind: function() {
            var shell_parameters = 0;
            tier_queue = arguments[shell_parameters++];
            accuracy_path = arguments[shell_parameters++];
        },
        name: "mediator"
    };
    var index_configs = {};
    function repair_accuracy(tool_moduo) {
        try {
            for (var project_architecture in index_configs) {
                if (index_configs.hasOwnProperty(project_architecture)) {
                    if (index_configs[project_architecture].events && index_configs[project_architecture].events[tool_moduo.type]) {
                        if (typeof index_configs[project_architecture].events[tool_moduo.type].handler !== "undefined") {
                            if (typeof index_configs[project_architecture].events[tool_moduo.type].handler !== "function") {
                                var worker_server = index_configs[project_architecture].instance;
                                var entry_metro = index_configs[project_architecture].events[tool_moduo.type].handler;
                                worker_server[entry_metro](tool_moduo.data[0], tool_moduo.data[1], tool_moduo.data[2], tool_moduo.data[3], tool_moduo.data[4], tool_moduo.data[5], tool_moduo.data[6], tool_moduo.data[7], tool_moduo.data[8], tool_moduo.data[9]);
                            } else {
                                index_configs[project_architecture].events[tool_moduo.type].handler(tool_moduo);
                            }
                        }
                    }
                }
            }
        } catch (worker_unit) {
            accuracy_path.log("cr-trigg-evt-ex", worker_unit.toString(), typeof project_architecture !== "undefined" ? project_architecture : "unknown module");
        }
    }
    function verify_values(account_parameters) {
        for (var project_architecture in index_configs) {
            if (index_configs[project_architecture].name === account_parameters) {
                return index_configs[project_architecture];
            }
        }
        return null;
    }
    function acquisition_signal() {
        return index_configs;
    }
    function acclaim_values(store_accuracy) {
        var unit_theme = acquisition_signal();
        for (var shell_parameters = 0; shell_parameters < store_accuracy.length; shell_parameters++) {
            if (!unit_theme[store_accuracy[shell_parameters]]) {
                return false;
            }
        }
        return true;
    }
    function adaptive_system(tool_moduo) {
        try {
            if (tool_moduo.type && tool_moduo.module) {
                if (index_configs[tool_moduo.module] && index_configs[tool_moduo.module].events && index_configs[tool_moduo.module].events[tool_moduo.type]) {
                    delete index_configs[tool_moduo.module].events[tool_moduo.type];
                }
            }
        } catch (worker_unit) {
            accuracy_path.log("cr-rmv-evt-ex", worker_unit.toString());
        }
    }
    function monitor_counter(account_parameters) {
        return account_parameters in index_configs;
    }
    function increment_name(path_power) {
        if (index_configs.hasOwnProperty(path_power.name)) {
            for (var configs_value in path_power.events) {
                index_configs[path_power.name].events[configs_value] = path_power.events[configs_value];
            }
        } else {
            index_configs[path_power.name] = path_power;
        }
    }
    function cycle_clock(tool_moduo) {
        try {
            if (tool_moduo.type && tool_moduo.module && tool_moduo.handler) {
                if (index_configs[tool_moduo.module]) {
                    if (typeof index_configs[tool_moduo.module].events === "undefined") {
                        index_configs[tool_moduo.module].events = {};
                    }
                    index_configs[tool_moduo.module].events[tool_moduo.type] = tool_moduo;
                }
            }
        } catch (worker_unit) {
            accuracy_path.log("cr-reg-evt-ex", worker_unit.toString());
        }
    }
    return {
        checkModule: monitor_counter,
        register: increment_name,
        subscribe: cycle_clock,
        checkModules: acclaim_values,
        __module: configs_text,
        unsubscribe: adaptive_system,
        getAllModules: acquisition_signal,
        publish: repair_accuracy,
        getModule: verify_values
    };
}());
__ppl.loader = __ppl.loader || {};

__ppl.loader["YYQ"] = __ppl.loader["YYQ"] || [];

__ppl.loader["YYQ"].push(function() {
    var tier_queue, accuracy_path, configs_text = {
        deps: [ "util", "logger" ],
        bind: function() {
            var shell_parameters = 0;
            tier_queue = arguments[shell_parameters++];
            accuracy_path = arguments[shell_parameters++];
        },
        name: "feed-controller"
    };
    var service_word = window, config_power = 0, timeout_service = null, unit_system = false;
    function acquisition_list(tool_moduo) {
        try {
            var access_range = parseInt(compute_members(), 10);
            if (access_range === 0 && typeof service_word.WXSystem2 == "undefined") {
                notify_timeout(tool_moduo.data, access_range);
                __ppl.Obs.publish("CHECKINCOMPLETE", {
                    token: tool_moduo.data.id,
                    data: tool_moduo.data,
                    info: "CONTINUE"
                });
            } else {
                notify_timeout(tool_moduo.data, access_range);
                __ppl.Obs.publish("CHECKINCOMPLETE", {
                    token: tool_moduo.data.id,
                    data: tool_moduo.data,
                    info: "STOP"
                });
            }
        } catch (worker_unit) {
            accuracy_path.log("sbx-feedmng-chkin-err", worker_unit.toString());
        }
    }
    function move_entry() {
        return unit_system;
    }
    function acquisition_account() {
        return timeout_service;
    }
    function isbool_server(tier_parameters) {
        if (timeout_service === null) {
            timeout_service = {};
        }
        timeout_service[tier_parameters.id] = tier_parameters;
        config_power++;
    }
    function notify_timeout(tier_parameters, access_range) {
        try {
            if (access_range !== null && access_range !== "null") {
                access_range = parseInt(access_range, 10) + 1;
            } else {
                access_range = 1;
            }
            isbool_server(tier_parameters);
            return access_range;
        } catch (worker_unit) {
            accuracy_path.log("sbx-feedmng-storeconf-ex", worker_unit.toString());
        }
    }
    function calculate_power() {
        if (typeof __ppl.Feeder === "undefined") {
            __ppl.Feeder = true;
            unit_system = true;
            __ppl.Obs.subscribe("CHECKIN", acquisition_list);
        }
    }
    function compute_members() {
        return config_power;
    }
    return {
        checkInFeed: acquisition_list,
        isPrimary: move_entry,
        getFeedConfigurations: acquisition_account,
        __module: configs_text,
        init: calculate_power
    };
}());
