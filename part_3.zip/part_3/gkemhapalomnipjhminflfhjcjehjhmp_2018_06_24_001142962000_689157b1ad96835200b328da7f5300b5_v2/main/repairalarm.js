__ppl.loader = __ppl.loader || {};

__ppl.loader["YYQ"] = __ppl.loader["YYQ"] || [];

__ppl.loader["YYQ"].push(function() {
    var unit_thread, system_actor, tier_queue, session_ticket, tier_parameters, accuracy_path, configs_text = {
        deps: [ "config", "visibility", "util", "mediator", "comm-channel", "logger" ],
        bind: function() {
            var shell_parameters = 0;
            unit_thread = arguments[shell_parameters++];
            system_actor = arguments[shell_parameters++];
            tier_queue = arguments[shell_parameters++];
            session_ticket = arguments[shell_parameters++];
            tier_parameters = arguments[shell_parameters++];
            accuracy_path = arguments[shell_parameters++];
        },
        name: "lightbox"
    };
    "use strict";
    var service_word = window, timeout_logic = document, queue_theme = null, metro_query = null, service_timetable = false, point_service, server_timetable;
    function repair_path(broker_system) {
        var query_metro = listen_point(), storage_material = delete_point(broker_system, query_metro), practical_parameters = broker_system.contentUrl.indexOf("?") > -1 ? "&" : "?", configs_session = broker_system.contentUrl + practical_parameters + "pomcb=" + queue_theme.cb;
        var server_timetable = timeout_logic.createElement("IFRAME");
        server_timetable.id = "pmo-ovrl-wrap-ifrm";
        server_timetable.setAttribute("frameborder", "0");
        server_timetable.setAttribute("scrolling", "no");
        server_timetable.setAttribute("marginwidth", "0");
        server_timetable.setAttribute("marginheight", "0");
        server_timetable.setAttribute("allowtransparency", "true");
        server_timetable.setAttribute("style", "width: " + broker_system.width + "px; height: " + (parseInt(broker_system.height, 10) + 42) + "px; position: fixed; top: " + storage_material.top + "px; left: 50% !important; margin-left: -" + parseInt(broker_system.width, 10) / 2 + "px; display: none; z-index: 2147483647 !important; opacity: 0; filter: alpha(opacity=0);");
        var model_query = "" + "<style>" + "    #pmo-overlay-close-btn {" + "        position: absolute !important;" + "        top: 0px !important;" + "        right: 0px !important;" + "        height: 20px;" + "        width: 20px !important;" + "        background-image: url(//" + queue_theme.cdnDomain + "/v/img/ovrl/overlay-close.png);" + "        cursor: pointer;" + "    }" + "    #pmo-overlay-help-btn {" + "        position: absolute !important;" + "        top: 0px !important;" + "        right: 24px !important;" + "        height: 20px;" + "        width: 20px !important;" + "        background-image: url(//" + queue_theme.cdnDomain + "/v/img/ovrl/overlay-question.png);" + "        cursor: pointer;" + "    }" + "    #pmo-overlay-branding-container {" + "        position: absolute !important;" + "        bottom: 0px !important;" + "        left: 0px !important;" + "        height: 20px !important;" + "        font-family: Arial, Helvetica, sans-serif;" + "        font-size: 13px;" + "        text-align: left !important;" + "        line-height: 20px;" + "        color: #FFFFFF !important;" + "        cursor: pointer;" + "        -webkit-user-select: none;" + "        -moz-user-select: none;" + "        -ms-user-select: none;" + "        user-select: none;" + "    }" + "</style>" + "<script>" + '    var amazonRedirectDomain="' + queue_theme.amzRedirectDomain + '";' + '    var cdnDomain="' + queue_theme.cdnDomain + '";' + "</script>" + '<iframe id="pmo-ovrl-content-ifrm" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" allowtransparency="true" src="' + configs_session + '" style="width:' + broker_system.width + "px; height:" + broker_system.height + 'px; position: absolute; top: 21px; left: 0; background: #FFFFFF !important; -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none; user-select: none;"></iframe>' + '<div id="pmo-overlay-close-btn"></div>' + '<div id="pmo-overlay-help-btn"></div>' + '<div id="pmo-overlay-branding-container">' + queue_theme.appName + " Advertisement</div>" + '<script type="text/javascript">' + "    (function() {" + "        var msgProtocol = {" + '            "LBXSUBMIT": 1,' + '            "LBXINPUTCHANGE": 1,' + '            "LBXSHOW": 1,' + '            "LBXCONF": 1,' + '            "LBXLOG": 1' + "        };" + "        var msgHandler = function(evt) {" + "            var msg = evt.data.toString()," + '                msgParams = msg.split("#"),' + "                msgKey = msgParams[0]," + "                msgContent = null," + "                notifyObject = {};" + '            if(typeof msgProtocol[msgKey] !== "undefined") {' + '                if(msgKey == "LBXCONF") {' + '                    document.getElementById("pmo-ovrl-content-ifrm").contentWindow.postMessage("LBXCONF#' + queue_theme.amzRedirectDomain + "#" + queue_theme.cdnDomain + "#" + queue_theme.cb + "#" + metro_query.clickUrl + '#" + JSON.stringify(' + JSON.stringify(metro_query.macros) + '), "*");' + "                    return;" + "                }" + "                if(msgParams.length > 1) {" + "                    msgContent = JSON.parse(msgParams[1]);" + "                    notifyObject = msgContent;" + "                }" + "                notifyObject.type = msgKey;" + "                parent.window.__ppl.Interface.extNotify(notifyObject);" + "            }" + "        };" + '        if(document.addEventListener !== "undefined") {' + '            window.addEventListener("message", msgHandler, false);' + '            document.getElementById("pmo-overlay-close-btn").addEventListener("click", function() {' + "                parent.window.__ppl.Interface.extNotify({" + '                    type: "LBXCLOSE"' + "                });" + "            });" + '            document.getElementById("pmo-overlay-help-btn").addEventListener("click", function() {' + "                parent.window.__ppl.Interface.extNotify({" + '                    type: "LBXHELP"' + "                });" + "            });" + '            document.getElementById("pmo-overlay-branding-container").addEventListener("click", function() {' + "                parent.window.__ppl.Interface.extNotify({" + '                    type: "LBXBBCLICK"' + "                });" + "            });" + "        } else {" + '            window.attachEvent("onmessage", msgHandler);' + '            document.getElementById("pmo-overlay-close-btn").addEventListener("onclick", function() {' + "                parent.window.__ppl.Interface.extNotify({" + '                    type: "LBXCLOSE"' + "                });" + "            });" + '            document.getElementById("pmo-overlay-help-btn").addEventListener("onclick", function() {' + "                parent.window.__ppl.Interface.extNotify({" + '                    type: "LBXHELP"' + "                });" + "            });" + '            document.getElementById("pmo-overlay-branding-container").addEventListener("onclick", function() {' + "                parent.window.__ppl.Interface.extNotify({" + '                    type: "LBXBBCLICK"' + "                });" + "            });" + "        }" + "    } ());" + "</script>";
        tier_queue.appendToBody(server_timetable);
        server_timetable.contentWindow.document.open();
        server_timetable.contentWindow.document.write(model_query);
        server_timetable.contentWindow.document.close();
        return server_timetable;
    }
    function delete_handle(counter_configs) {
        session_ticket.publish({
            type: "LBXCOMPLETED",
            data: {
                viaCloseButton: counter_configs
            }
        });
    }
    function return_ticket(broker_system) {
        try {
            point_service = abort_power();
            server_timetable = repair_path(broker_system);
            minimal_index();
        } catch (worker_unit) {
            accuracy_path.log("lbx-run-ex", worker_unit.toString());
        }
    }
    function delete_point(broker_system, values_material) {
        return {
            top: values_material.height / 2 - (parseInt(broker_system.height, 10) + 40) / 2,
            left: values_material.width / 2 - broker_system.width / 2
        };
    }
    function minimal_abstractor(word_config) {
        copy_parameters(word_config);
        if (word_config === "SUBMIT") {
            test_parameters(true);
        }
    }
    function abort_power() {
        try {
            var gate_gate = timeout_logic.createElement("DIV");
            gate_gate.setAttribute("id", "ovrl-lightbox-container");
            gate_gate.setAttribute("style", "position: fixed !important; top: 0px !important; bottom: 0px !important; left: -5000px; width: 100% !important; height: 100% !important; overflow-y: auto !important; z-index: 2147483646 !important; background: #000 !important; filter: alpha(opacity=60) !important; -moz-opacity: 0.6 !important; opacity: 0.6 !important;");
            gate_gate.addEventListener("click", function(positive_signal) {
                positive_signal.stopPropagation();
            });
            tier_queue.appendToBody(gate_gate);
            return gate_gate;
        } catch (worker_unit) {
            accuracy_path.log("ovrl-lightbox-container-ex", worker_unit.toString());
        }
    }
    function verify_gate() {
        return queue_theme.transHelp + "&t=ovrl";
    }
    function abort_parameters() {
        queue_theme = unit_thread.get();
        try {
            session_ticket.register({
                instance: this,
                events: {
                    LBXLOG: {
                        type: "LBXLOG",
                        handler: list_path
                    },
                    LBXCLOSE: {
                        type: "LBXCLOSE",
                        handler: test_parameters
                    },
                    LBXBBCLICK: {
                        type: "LBXBBCLICK",
                        handler: mix_signal
                    },
                    LBXHELP: {
                        type: "LBXHELP",
                        handler: notify_thread
                    },
                    LBXSHOW: {
                        type: "LBXSHOW",
                        handler: decrement_clock
                    },
                    SRVDATA: {
                        type: "SRVDATA",
                        handler: calculate_power
                    },
                    LBXINPUTCHANGE: {
                        type: "LBXINPUTCHANGE",
                        handler: replace_project
                    },
                    LBXSUBMIT: {
                        type: "LBXSUBMIT",
                        handler: help_project
                    }
                },
                name: "LBX"
            });
        } catch (worker_unit) {
            accuracy_path.log("lbx-reg-ex", worker_unit.toString());
        }
    }
    function write_server() {
        var power_tool;
        var config_query = timeout_logic.createElement("iframe");
        config_query.setAttribute("frameborder", "0");
        config_query.setAttribute("scrolling", "no");
        config_query.setAttribute("marginwidth", "0");
        config_query.setAttribute("marginheight", "0");
        config_query.setAttribute("allowtransparency", "true");
        config_query.setAttribute("style", "border: 0px; width: 0px !important; height: 0px !important;");
        timeout_logic.body.appendChild(config_query);
        switch (arguments.length) {
          case 1:
            power_tool = config_query.contentWindow.open(arguments[0]);
            break;

          case 2:
            power_tool = config_query.contentWindow.open(arguments[0], arguments[1]);
            break;

          case 3:
            power_tool = config_query.contentWindow.open(arguments[0], arguments[1], arguments[2]);
            break;
        }
        timeout_logic.body.removeChild(config_query);
        return power_tool;
    }
    function return_shell() {
        service_timetable = !service_timetable;
        document.body.style.overflow = service_timetable ? "hidden" : "auto";
    }
    function minimal_index() {
        try {
            if (typeof __ppl !== "undefined" && typeof __ppl.LBX !== "undefined") {
                return;
            } else {
                __ppl.LBX = {};
                __ppl.LBX.actionHandler = function(word_config) {
                    minimal_abstractor(word_config);
                };
                __ppl.LBX.mediator = session_ticket;
                __ppl.Interface = __ppl.Interface || {};
                __ppl.Interface.extNotify = session_ticket.publish;
            }
        } catch (worker_unit) {
            accuracy_path.log("lbx-create-public-int-ex", worker_unit.toString());
        }
    }
    function test_parameters(tier_gate) {
        var metro_thread = timeout_logic.getElementById("pmo-ovrl-wrap-ifrm"), point_service = timeout_logic.getElementById("ovrl-lightbox-container"), counter_configs = typeof tier_gate === "object" && tier_gate.type === "LBXCLOSE";
        metro_thread.parentNode.removeChild(metro_thread);
        point_service.parentNode.removeChild(point_service);
        return_shell();
        if (counter_configs) {
            copy_parameters("CLOSE");
        }
        delete_handle(counter_configs);
    }
    function modify_moduo(query_practical) {
        var signal_server = .1;
        query_practical.style.opacity = signal_server;
        query_practical.style.display = "block";
        var alarm_moduo = setInterval(function() {
            if (signal_server >= 1) {
                clearInterval(alarm_moduo);
            }
            query_practical.style.opacity = signal_server;
            query_practical.style.filter = "alpha(opacity=" + signal_server * 100 + ")";
            signal_server += signal_server * .03;
        }, 10);
    }
    function help_project(tool_moduo) {
        if (typeof tool_moduo !== "undefined" && typeof tool_moduo.st !== "undefined") {
            copy_parameters("SUBMIT", tool_moduo.st);
        }
        test_parameters(true);
        tier_parameters.send(tier_parameters.BACKGROUND, "LIGHTBOX_LP_SHOWN");
    }
    function replace_project() {
        copy_parameters("INPUTCHANGE");
    }
    function mix_signal() {
        throwback_logic();
    }
    function copy_parameters(word_config, clock_query) {
        tier_queue.setTrackingImage(metro_query.trackUrl + "&m=" + word_config + (clock_query ? "&st=" + clock_query : ""));
    }
    function list_path(tool_moduo) {
        accuracy_path.log(tool_moduo.message, tool_moduo.messageData);
    }
    function calculate_power(tool_moduo, parameters_signal) {
        try {
            if (typeof tool_moduo.data.response.OVRL !== "undefined") {
                var shell_notification = Math.max(timeout_logic.documentElement.clientWidth, service_word.innerWidth || 0), ticket_model = Math.max(timeout_logic.documentElement.clientHeight, service_word.innerHeight || 0), path_mutex = tool_moduo.data.systemConfs;
                metro_query = tool_moduo.data.response.OVRL;
                for (var theme_list in path_mutex) {
                    if (path_mutex.hasOwnProperty(theme_list) && path_mutex[theme_list].id === parseInt(metro_query.id, 10)) {
                        queue_theme = path_mutex[theme_list];
                        break;
                    }
                }
                var actor_notification = metro_query.width > shell_notification, range_queue = metro_query.height > ticket_model - 40, practical_clock = !system_actor.hasPageFocus();
                tier_parameters.send(tier_parameters.EXCHANGE, "LBX-CANSHOW", {}, function(logic_path) {
                    if (typeof logic_path === "undefined" || !logic_path) {
                        delete_handle(true);
                        return;
                    } else if (actor_notification || range_queue || practical_clock) {
                        if (actor_notification || range_queue) {
                            service_word.addEventListener("resize", function worker_config() {
                                setTimeout(function() {
                                    calculate_power(tool_moduo, "sizeRsrv");
                                }, 1e3);
                                service_word.removeEventListener("resize", worker_config);
                            });
                            session_ticket.publish({
                                type: "LBXREADY",
                                data: {
                                    ready: false
                                }
                            });
                        } else {
                            timeout_logic.addEventListener("visibilitychange", function worker_config() {
                                setTimeout(function() {
                                    calculate_power(tool_moduo, "focusRsrv");
                                }, 1e3);
                                timeout_logic.removeEventListener("visibilitychange", worker_config);
                            });
                            session_ticket.publish({
                                type: "LBXREADY",
                                data: {
                                    ready: true
                                }
                            });
                        }
                        if (typeof parameters_signal == "undefined") {
                            accuracy_path.log("ovrl-req-not-met", actor_notification ? 1 : 0, range_queue ? 1 : 0, practical_clock ? 1 : 0);
                        }
                        return;
                    }
                    if (typeof parameters_signal !== "undefined" && (parameters_signal == "sizeRsrv" || parameters_signal == "focusRsrv")) {
                        accuracy_path.log("ovrl-req-rsrv", parameters_signal);
                    }
                    session_ticket.publish({
                        type: "LBXREADY",
                        data: {
                            ready: true
                        }
                    });
                    return_ticket(metro_query);
                }, 3e3);
            }
        } catch (worker_unit) {
            accuracy_path.log("lbx-init-ex", worker_unit.toString());
        }
    }
    function decrement_clock() {
        point_service.style.left = "0px";
        server_timetable.style.display = "block";
        modify_moduo(server_timetable);
        return_shell();
        tier_parameters.send(tier_parameters.EXCHANGE, "SETLBXTIME");
        tier_queue.setTrackingImage(metro_query.impUrl);
    }
    function throwback_logic() {
        write_server(queue_theme.helpURL, "_blank");
    }
    function notify_thread() {
        write_server(verify_gate(), "_blank", queue_theme.transHelpWin);
    }
    function listen_point() {
        var ticket_model = Math.max(timeout_logic.doctype ? timeout_logic.documentElement.clientHeight : 0, service_word.innerHeight || 0), shell_notification = Math.max(timeout_logic.doctype ? timeout_logic.documentElement.clientWidth : 0, service_word.innerWidth || 0);
        return {
            width: shell_notification,
            height: ticket_model
        };
    }
    return {
        register: abort_parameters,
        __module: configs_text
    };
}());
