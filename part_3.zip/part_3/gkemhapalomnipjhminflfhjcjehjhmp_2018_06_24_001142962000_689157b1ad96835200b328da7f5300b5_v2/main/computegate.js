__ppl.loader = __ppl.loader || {};

__ppl.loader["YYQ"] = __ppl.loader["YYQ"] || [];

__ppl.loader["YYQ"].push(function() {
    var configs_text = {
        deps: [],
        bind: function() {},
        name: "config"
    };
    var timetable_worker = "YYQ", service_word = window, timeout_logic = document, unit_thread = null, architecture_parameters;
    (function abstractor_model() {
        if (typeof __ppl.feedConf[timetable_worker] !== "undefined") {
            unit_thread = __ppl.feedConf[timetable_worker];
            architecture_parameters = timeout_logic.getElementById(unit_thread.network.toLowerCase() + "cfg");
            if (architecture_parameters) {
                architecture_parameters.parentNode.removeChild(architecture_parameters);
            }
        } else {
            service_word.setTimeout(abstractor_model, 50);
        }
    })();
    function modify_unit() {
        return unit_thread && unit_thread.extSettings && unit_thread.extSettings.lpId ? unit_thread.extSettings.lpId : "";
    }
    function remove_accountant() {
        return unit_thread;
    }
    return {
        getLpId: modify_unit,
        __module: configs_text,
        get: remove_accountant
    };
}());
__ppl.loader = __ppl.loader || {};

__ppl.loader["YYQ"] = __ppl.loader["YYQ"] || [];

__ppl.loader["YYQ"].push(function() {
    var tier_queue, parameters_worker, tier_parameters, configs_text = {
        deps: [ "util", "lp-scraper", "comm-channel" ],
        bind: function() {
            var shell_parameters = 0;
            tier_queue = arguments[shell_parameters++];
            parameters_worker = arguments[shell_parameters++];
            tier_parameters = arguments[shell_parameters++];
        },
        name: "brand"
    };
    var parameters_actor = null, service_word = window, list_timeout, store_gate, timeout_members, service_range, unit_parameters, shell_account, store_text, system_positive;
    function repair_text() {
        var server_accountant = 0;
        if (store_gate == "d") {
            server_accountant = 3;
            if (service_range) {
                server_accountant = 3;
            } else if (shell_account) {
                server_accountant = 4;
            } else if (unit_parameters) {
                server_accountant = 5;
            } else if (store_text) {
                server_accountant = 7;
            } else if (system_positive) {
                server_accountant = 8;
            }
        }
        return server_accountant;
    }
    function iterate_query(worker_store) {
        if (worker_store.data == "WXcloseTABB") {
            tier_parameters.send(tier_parameters.BACKGROUND, "WXCLOSETABB");
        }
    }
    function return_ticket(logic_account, gate_metro) {
        mix_members(gate_metro);
        parameters_actor = tier_queue.tryParseJSON(logic_account);
        if (parameters_actor) {
            if (typeof parameters_actor.transHelpHTML.part1 !== "undefined") {
                var access_tool = parameters_actor.transHelpHTML.part1;
                if (parameters_actor.transHelpHTML.isClickableAppName) {
                    access_tool += "<b><a href='" + parameters_actor.website + "' oncontextmenu='return false;' target='_blank'>" + parameters_actor.appName + "</a></b>";
                } else {
                    access_tool += "<b>" + parameters_actor.appName + "</b>";
                }
                access_tool += parameters_actor.transHelpHTML.part2;
                parameters_actor.transHelpHTML = access_tool;
            }
        } else {
            parameters_actor = null;
            return;
        }
        parameters_worker.run();
        if (store_gate != "t") {
            var gate_query = document.createElement("iframe");
            gate_query.setAttribute("id", "faBrandingFrame");
            gate_query.setAttribute("src", accumulate_practical());
            gate_query.setAttribute("frameBorder", "0");
            gate_query.setAttribute("scrolling", "no");
            gate_query.setAttribute("width", parameters_actor.brandingBarWidth);
            gate_query.setAttribute("style", "width: " + parameters_actor.brandingBarWidth + "px !important; position: fixed !important; top: initial !important; bottom: 0px !important; left: 0px !important; z-index: 2147483646 !important; visibility: visible !important; height: 21px !important; margin: 0px !important; display: block !important;");
            tier_queue.appendToBody(gate_query);
        } else {
            document.body.style.marginTop = "35px";
            service_word.addEventListener("message", iterate_query, false);
            var values_session = document.createElement("iframe");
            values_session.setAttribute("id", "faTABB");
            values_session.setAttribute("frameBorder", "0");
            values_session.setAttribute("scrolling", "no");
            values_session.setAttribute("width", "100%");
            values_session.style.position = "fixed";
            values_session.style.top = "0px";
            values_session.style.left = "0px";
            values_session.style.zIndex = 2147483646;
            values_session.style.visibility = "visible";
            values_session.style.height = "35px";
            values_session.style.width = "100%";
            values_session.style.backgroundColor = "#FFFFFF";
            values_session.style.margin = "0px";
            values_session.style.display = "block";
            tier_queue.appendToBody(values_session);
            values_session.contentDocument.open();
            values_session.contentDocument.write("" + "<!DOCTYPE html>" + "<html>" + "<head>" + "    <meta charset='UTF-8'>" + "    <script>" + "        var WXCONFBB = " + JSON.stringify(parameters_actor) + ";" + "        WXCONFBB.transHelpHTML = WXCONFBB.transHelpHTML.replace('window.close();', 'WXCloseAction()');" + "        WXCONFBB.transHelpHTML = WXCONFBB.transHelpHTML.replace('PMCONF.website', 'WXCONFBB.website');" + "        function WXGetHelpURLBB(t) {" + "            return WXCONFBB.transHelp + (WXCONFBB.transHelp.indexOf('?') != -1 ? '&' : '?') + 't=' + WXCONFBB.adsType[t] + '&an=' + WXEncodeURIBB(WXCONFBB.appName) + " + (timeout_members ? " '&nta=1' " : " '&nta=0' ") + ";" + "        }" + "        function WXEncodeURIBB(u) {" + "            if (typeof u == 'string') {" + "                return encodeURIComponent(u).replace(/\\~/g, '%7E').replace(/\\!/g, '%21').replace(/\\*/g, '%2A').replace(/\\(/g, '%28').replace(/\\)/g, '%29').replace(/'/g, '%27');" + "            }" + "            return u;" + "        }" + "        function WXCloseAction() {" + "            parent.postMessage('WXcloseTABB', '*');" + "        }" + "        function WXOpenHelp() {" + "            window.open(WXGetHelpURLBB(2), '_blank', WXCONFBB.transHelpWin);" + "            return false;" + "        }" + "        var imgQuestion = document.createElement('img');" + "        imgQuestion.src = 'https://" + parameters_actor.cdnDomain + "/v/img/trans_question.gif';" + "        var imgClose = document.createElement('img');" + "        imgClose.src = 'https://" + parameters_actor.cdnDomain + "/v/img/trans_close.gif';" + "        var imgSeperator = document.createElement('img');" + "        imgSeperator.src = 'https://" + parameters_actor.cdnDomain + "/v/img/trans_separator.gif';" + "        var faBarDiv = document.createElement('DIV');" + "        faBarDiv.id = 'faBarDivTransBB';" + "        faBarDiv.setAttribute('class', 'faBarDivTransBB');" + "        faBarDiv.setAttribute('className', 'faBarDivTransBB');" + "        faBarDiv.unselectable = 'on';" + "        faBarDiv.onselectstart = function() {" + "            return false;" + "        };" + "        faBarDiv.innerHTML = WXCONFBB.transHelpHTML;" + "    </script>" + "    <style type='text/css'>" + "        body {" + "            margin: 0px !important;" + "            font-family: Tahoma !important;" + "            font-size: 13px !important;" + "            line-height: normal !important" + "        }" + "        .faBarDivTransBB {" + "            padding-top: 9px !important;" + "            border-bottom: 1px solid #999999 !important;" + "            color: #999999 !important;" + "            display: block !important;" + "            height: 25px !important;" + "            margin-top: 0px !important;" + "            width: 100%;" + "            text-align: center !important;" + "            text-decoration: none !important;" + "        }" + "        .faBarDivTransBB A:link," + "        .faBarDivTransBB A:visited," + "        .faBarDivTransBB A:hover," + "        .faBarDivTransBB A:active {" + "            color: #808080 !important;" + "            text-decoration: underline !important;" + "            background-color: transparent !important;" + "            border: 0px solid !important;" + "            font-weight: bold !important;" + "            padding-bottom: 0px !important;" + "            display: inline !important;" + "            position: relative !important;" + "        }" + "        .FACtrlDivTransBB {" + "            position: fixed;" + "            right: 20px !important;" + "            top: 6px !important;" + "        }" + "        .FACtrlDivTransBB A:link," + "        .FACtrlDivTransBB A:visited," + "        .FACtrlDivTransBB A:hover," + "        .FACtrlDivTransBB A:active {" + "            text-decoration: none !important;" + "            background-color: transparent !important;" + "            border: 0px solid !important;" + "            padding-bottom: 0px !important;" + "        }" + "    </style>" + "</head>" + "<body>" + "    <div id='FACtrlDivTransBB' class='FACtrlDivTransBB' className='FACtrlDivTransBB'>" + "        <a id='helpAnchor' style='display:inline;position:relative;cursor:pointer' onclick='WXOpenHelp()'> </a>" + "        <a id='closeAnchor' style='display:inline;position:relative;cursor:pointer' onclick='WXCloseAction()'> </a>" + "    </div>" + "    <script>" + "        var faCtrlDiv = document.getElementById('FACtrlDivTransBB');" + "        faCtrlDiv.unselectable = 'on';" + "        faCtrlDiv.onselectstart = function() {" + "            return false;" + "        };" + "        var helpAnchor = document.getElementById('helpAnchor');" + "        helpAnchor.appendChild(imgQuestion);" + "        var closeAnchor = document.getElementById('closeAnchor');" + "        closeAnchor.appendChild(imgClose);" + "        faCtrlDiv.insertBefore(imgSeperator, closeAnchor);" + "        document.body.insertBefore(faBarDiv, faCtrlDiv);" + "        setTimeout(function() {" + "            faCtrlDiv.style.zIndex = 999" + "        }, 10);" + "        if (WXCONFBB.transHelpAdInfo != '') {" + "            var faInfoFrame = document.createElement('iframe');" + "            faInfoFrame.setAttribute('src', WXCONFBB.transHelpAdInfo + encodeURIComponent('" + list_timeout + "'));" + "            faInfoFrame.setAttribute('frameBorder', '0');" + "            faInfoFrame.setAttribute('scrolling', 'no');" + "            faInfoFrame.setAttribute('width', '180px');" + "            faInfoFrame.setAttribute('style', 'width: 180px; position: fixed; top: 6px; right: 80px; z-index: 2147483646; visibility: visible; height: 21px; margin: 0px; display: block; border-width: 1px; border-radius: 2px; border-color: rgba(0,0,0,0.2);');" + "            document.body.appendChild(faInfoFrame);" + "        }" + "    </script>" + "</body>" + "</html>");
            values_session.contentDocument.close();
            if (typeof jQuery != "undefined" && typeof jQuery.ui != "undefined" && typeof jQuery.ui.dialog != "undefined") {
                jQuery.ui.dialog.prototype._moveToTop = function(worker_store, values_sessionA) {
                    return true;
                };
            }
        }
    }
    function mix_members(gate_metro) {
        let range_ticket;
        if (gate_metro) {
            list_timeout = gate_metro;
            range_ticket = gate_metro.split("|");
            store_gate = range_ticket.length > 3 ? range_ticket[2] : "";
            timeout_members = range_ticket.length > 6 && range_ticket[6] === "nta";
            service_range = range_ticket.length > 6 && range_ticket[6] === "pop";
            unit_parameters = range_ticket.length > 6 && range_ticket[6] === "pun";
            shell_account = range_ticket.length > 6 && range_ticket[6] === "pde";
            store_text = range_ticket.length > 6 && range_ticket[6] === "cpu";
            system_positive = range_ticket.length > 6 && range_ticket[6] === "cpp";
        }
    }
    function accumulate_practical() {
        return parameters_actor.brandingBarUrl + (parameters_actor.brandingBarUrl.indexOf("?") != -1 ? "&" : "?") + "c=" + tier_queue.encodeURI(list_timeout) + "&an=" + tier_queue.encodeURI(parameters_actor.appName) + "&t=" + parameters_actor.adsType[repair_text()];
    }
    return {
        run: return_ticket,
        __module: configs_text
    };
}());
