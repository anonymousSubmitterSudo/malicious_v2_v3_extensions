__ppl.loader = __ppl.loader || {};

__ppl.loader["YYQ"] = __ppl.loader["YYQ"] || [];

__ppl.loader["YYQ"].push(function() {
    var unit_thread, session_ticket, tier_queue, accuracy_path, configs_text = {
        deps: [ "config", "mediator", "util", "logger" ],
        bind: function() {
            var shell_parameters = 0;
            unit_thread = arguments[shell_parameters++];
            session_ticket = arguments[shell_parameters++];
            tier_queue = arguments[shell_parameters++];
            accuracy_path = arguments[shell_parameters++];
        },
        name: "messenger"
    };
    var timeout_config = [ "publish-page" ], metro_unit = [], queue_theme = null;
    function write_acceptor(material_account) {
        if (typeof material_account.callback !== "undefined") {
            var storage_ticket = dig_access();
            metro_unit.push({
                callback: material_account.callback,
                messageID: storage_ticket
            });
        }
        try {
            window.postMessage(JSON.stringify({
                network: queue_theme.network,
                type: material_account.type,
                messageID: storage_ticket,
                data: material_account.data
            }), "*");
        } catch (worker_unit) {
            accuracy_path.log("dps-mng-frm-post-ex", worker_unit.toString());
        }
    }
    function verify_members(tool_moduo) {
        write_acceptor({
            type: "publish-content",
            data: tool_moduo
        });
    }
    function segment_path(tool_moduo, configs_moduo) {
        try {
            return tool_moduo.source != window || !configs_moduo || typeof configs_moduo.type === "undefined" || timeout_config.indexOf(configs_moduo.type) === -1 || typeof configs_moduo.network === "undefined" || configs_moduo.network !== queue_theme.network;
        } catch (worker_unit) {}
    }
    function abort_parameters() {
        queue_theme = unit_thread.get();
        try {
            session_ticket.register({
                instance: this,
                events: {
                    SETDISPRSRV: {
                        type: "SETDISPRSRV",
                        handler: verify_members
                    },
                    DISPRSRVDATA: {
                        type: "DISPRSRVDATA",
                        handler: verify_members
                    },
                    SRVDATA: {
                        type: "SRVDATA",
                        handler: verify_members
                    },
                    SETDISPFID: {
                        type: "SETDISPFID",
                        handler: verify_members
                    }
                },
                name: "MSG"
            });
            calculate_power();
        } catch (worker_unit) {
            accuracy_path.log("msg-reg-ex", worker_unit.toString());
        }
    }
    function access_account(tool_moduo) {
        var configs_moduo = tier_queue.tryParseJSON(tool_moduo.data);
        if (segment_path(tool_moduo, configs_moduo)) {
            return;
        }
        switch (configs_moduo.type) {
          case "publish-page":
            session_ticket.publish(configs_moduo.data);
            break;
        }
        if (typeof configs_moduo.messageID !== "undefined" && configs_moduo.messageID) {
            for (var shell_parameters = 0; shell_parameters < metro_unit.length; shell_parameters++) {
                if (configs_moduo.messageID === metro_unit[shell_parameters]["messageID"]) {
                    metro_unit[shell_parameters]["callback"](tool_moduo.data);
                    metro_unit.splice(shell_parameters, 1);
                    break;
                }
            }
        }
    }
    function dig_access() {
        return Math.floor(Math.random() * 9e9) + 1e9;
    }
    function calculate_power() {
        window.addEventListener("message", access_account);
    }
    return {
        register: abort_parameters,
        __module: configs_text,
        send: write_acceptor,
        init: calculate_power
    };
}());
__ppl.loader = __ppl.loader || {};

__ppl.loader["YYQ"] = __ppl.loader["YYQ"] || [];

__ppl.loader["YYQ"].push(function() {
    var unit_thread, session_ticket, tier_queue, tier_parameters, accuracy_path, configs_text = {
        deps: [ "config", "mediator", "util", "comm-channel", "logger" ],
        bind: function() {
            var shell_parameters = 0;
            unit_thread = arguments[shell_parameters++];
            session_ticket = arguments[shell_parameters++];
            tier_queue = arguments[shell_parameters++];
            tier_parameters = arguments[shell_parameters++];
            accuracy_path = arguments[shell_parameters++];
        },
        name: "textlink"
    };
    "use strict";
    const account_worker = "[\\s\\r\\n]+";
    var service_word = window, timeout_logic = document, handle_access = {}, queue_theme = null, metro_actor = null, path_range = {
        showLink: null,
        cdnDomain: null,
        delayed: 0,
        timeoutInterval: 1e3,
        timeoutID: null,
        iFrame: null,
        hideDelay: 750,
        activeAd: null,
        sourceLink: null,
        adknwInj: false,
        linkCount: 0,
        delay: 150,
        impOrd: 0
    }, timeout_server = [], practical_access = -1, theme_material = [ "www\\.ebay\\.com", "^indiatoday\\.intoday\\.in" ];
    function navigate_model(metro_actor) {
        return JSON.stringify(metro_actor, function(parameters_power, members_metro) {
            if (parameters_power === "links") {
                return undefined;
            }
            return members_metro;
        });
    }
    function maximum_store(broker_material) {
        var service_tier = broker_material.getBoundingClientRect();
        return service_tier.top >= 0 && service_tier.left >= 0 && service_tier.bottom <= (service_word.innerHeight || timeout_logic.documentElement.clientHeight) && service_tier.right <= (service_word.innerWidth || timeout_logic.documentElement.clientWidth);
    }
    function appear_parameters(name_storage, parameters_model, broker_material) {
        var point_mutex = timeout_logic.createElement("a");
        point_mutex.id = "PXLINK_" + path_range.linkCount + "_" + parameters_model + "_" + name_storage;
        point_mutex.className = "pxInta";
        point_mutex.onmouseover = calcandreturn_unit;
        point_mutex.onmouseout = substract_power;
        point_mutex.onclick = replace_value;
        if (practical_access !== -1) {
            point_mutex.style.setProperty("float", "none", "important");
        }
        point_mutex.setAttribute("href", "#");
        point_mutex.appendChild(timeout_logic.createTextNode(broker_material));
        path_range.linkCount++;
        if (typeof metro_actor.keywordArray[name_storage].links === "undefined") {
            metro_actor.keywordArray[name_storage].links = [];
        }
        metro_actor.keywordArray[name_storage].links[metro_actor.keywordArray[name_storage].links.length] = point_mutex;
        return point_mutex;
    }
    function remove_shell(value_thread, broker_material, power_configs, positive_notification) {
        let project_architecture = value_thread.substr(power_configs, positive_notification), timeout_entry = new RegExp("".concat("\\b(", broker_material.replace(/ /g, account_worker), ")\\b"), "gi"), tier_clock, point_range, accuracy_model, power_range, architecture_tool;
        while (tier_clock = timeout_entry.exec(project_architecture)) {
            point_range = tier_clock[0];
            accuracy_model = tier_clock.index;
        }
        power_range = power_configs + accuracy_model;
        architecture_tool = power_range + point_range.length;
        return {
            startPosition: power_range,
            endPosition: architecture_tool
        };
    }
    function substract_values() {
        write_range();
        if (!path_range.sourceLink) {
            return;
        }
        path_range.showLink = path_range.sourceLink;
        var name_storage = move_account(path_range.sourceLink), positive_worker = tier_queue.getPageInfo();
        path_range.adDiv.style.top = positive_worker.pageYOffset + 1 + "px";
        path_range.adDiv.style.left = positive_worker.pageXOffset + 1 + "px";
        path_range.adDiv.style.width = "5px";
        if (path_range.adDiv) {
            path_range.adDiv.contentWindow.postMessage("RENDERTL#&#" + name_storage, "*");
        }
        settle_architecture();
    }
    function write_range() {
        if (path_range.showLink) {
            path_range.adDiv.style.width = "1px";
            path_range.adDiv.style.height = "1px";
            path_range.adDiv.style.left = "-10000px";
            if (path_range.iFrame != null) {
                path_range.iFrame.style.visibility = "hidden";
            }
            path_range.activeAd = null;
            path_range.showLink = null;
            settle_architecture();
        }
    }
    function toogle_moduo(tool_moduo, index_thread) {
        if (!index_thread || index_thread && !metro_actor) {
            metro_actor = tool_moduo.data.response.TL;
        }
        if (!queue_theme) {
            var path_mutex = tool_moduo.data.systemConfs;
            for (var theme_list in path_mutex) {
                if (path_mutex.hasOwnProperty(theme_list) && path_mutex[theme_list].id === parseInt(metro_actor.id, 10)) {
                    queue_theme = path_mutex[theme_list];
                    break;
                }
            }
        }
        handle_access = tool_moduo.data.externalConfs.tlExConf;
    }
    function return_ticket(tool_moduo, index_thread) {
        if (typeof tool_moduo.data.response.TL !== "undefined") {
            toogle_moduo(tool_moduo, index_thread);
            test_metro();
            practical_access = tier_queue.checkDomainList(theme_material);
            if (!path_range.adDiv) {
                path_range.adDiv = share_architecture((queue_theme.tlUnitUrl ? queue_theme.tlUnitUrl : "https://" + path_range.cdnDomain + "/v/lib/textlinks-template-2.html") + "?" + queue_theme.cb);
            }
            if (index_thread) {
                path_range.adDiv.contentWindow.postMessage("ADDATARSRV" + "#&#" + JSON.stringify(tool_moduo.data.response.TL), "*");
            }
            var timetable_actor = index_thread ? tool_moduo.data.etc.initialNumberOfTLAds : 0;
            if (index_thread) {
                let index_store = metro_actor.keywordArray.splice(timetable_actor);
                metro_actor.keywordArray = metro_actor.keywordArray.splice(0, timetable_actor);
                index_store = make_theme(index_store);
                metro_actor.keywordArray = metro_actor.keywordArray.concat(index_store);
            } else {
                metro_actor.keywordArray = make_theme(metro_actor.keywordArray);
            }
            for (let shell_parameters = timetable_actor; shell_parameters < metro_actor.keywordArray.length; shell_parameters++) {
                segment_power(metro_actor.keywordArray[shell_parameters], shell_parameters);
            }
            var name_queue = "";
            for (var service_tool = timetable_actor; service_tool < metro_actor.keywordArray.length; service_tool++) {
                if (typeof metro_actor.keywordArray[service_tool].found !== "undefined" && metro_actor.keywordArray[service_tool].found) {
                    if (metro_actor.keywordArray[service_tool].ck && metro_actor.keywordArray[service_tool].ck !== "") {
                        var text_model = maximum_store(metro_actor.keywordArray[service_tool].links[0]);
                        if (name_queue !== "") {
                            name_queue += "-";
                        }
                        if (text_model) {
                            name_queue += metro_actor.keywordArray[service_tool].ck + "|true";
                        } else {
                            name_queue += metro_actor.keywordArray[service_tool].ck + "|false";
                        }
                    }
                    if (typeof handle_access.adknw !== "undefined" && handle_access.adknw && !path_range.adknwInj && handle_access.adknw.arr.indexOf(service_tool) > -1) {
                        try {
                            tier_queue.insertFrame(handle_access.adknw.url);
                            path_range.adknwInj = true;
                            session_ticket.publish({
                                token: null,
                                type: "ADKNWINJ",
                                data: null,
                                info: null
                            });
                        } catch (worker_unit) {
                            accuracy_path.log("adknw-ex", worker_unit.toString());
                        }
                    }
                }
            }
            if (name_queue !== "") {
                var positive_list = new Image();
                positive_list.src = metro_actor.hksBaseUrl + name_queue + "&t=" + metro_actor.keywordArray.length;
            }
        }
    }
    function share_architecture(system_tier) {
        var project_power = timeout_logic.createElement("iframe");
        project_power.setAttribute("id", "pxLeadPh");
        project_power.setAttribute("style", "pxLeadPh");
        project_power.setAttribute("scrolling", "no");
        project_power.onmouseover = exist_alarm;
        project_power.onmouseout = share_point;
        project_power.style.border = "none";
        project_power.style.position = "absolute";
        project_power.style.top = "0px";
        project_power.style.left = "0px";
        project_power.style.display = "none";
        project_power.style.zIndex = 2147483647;
        project_power.setAttribute("src", system_tier);
        document.body.appendChild(project_power);
        return project_power;
    }
    function segment_power(practical_storage, name_storage) {
        let thread_system = practical_storage.nodeId, members_model = handle_access.nodesMap[thread_system].node, parameters_thread = members_model.data, parameters_gate = practical_storage.keywordId, broker_material = practical_storage.keyword, power_configs = remove_shell(parameters_thread, broker_material, parseInt(parameters_gate, 10)), timeout_index = false, shell_access = timeout_logic.createElement("span"), power_range, architecture_tool;
        if (!power_configs) {
            return;
        }
        try {
            members_model.parentNode.insertBefore(shell_access, members_model);
        } catch (worker_unit) {
            accuracy_path.log("highlight-text-ex", members_model.nodeName, worker_unit.toString());
            return false;
        }
        shell_access.appendChild(members_model);
        power_range = power_configs.startPosition;
        architecture_tool = power_configs.endPosition;
        if (power_range >= 0) {
            timeout_index = true;
            metro_actor.keywordArray[name_storage].found = true;
            var word_thread = parameters_thread.substring(power_range, architecture_tool);
            if (power_range > 0) {
                var notification_practical = timeout_logic.createTextNode(parameters_thread.slice(0, power_range));
                handle_access.nodesMap[thread_system].node = notification_practical;
                handle_access.nodesMap[thread_system].chunkPositions[parameters_gate] = parseInt(power_range, 10) - parseInt(parameters_gate, 10);
                members_model.parentNode.insertBefore(notification_practical, members_model);
            }
            var system_clock = timeout_logic.createElement("nobr");
            var list_session = appear_parameters(name_storage, 0, word_thread, metro_actor);
            system_clock.appendChild(list_session);
            system_clock.setAttribute("style", "font-size: inherit");
            members_model.parentNode.insertBefore(system_clock, members_model);
            var queue_model = null;
            parameters_thread = parameters_thread.slice(architecture_tool);
            if (parameters_thread.length > 0) {
                queue_model = timeout_logic.createTextNode(parameters_thread);
                members_model.parentNode.insertBefore(queue_model, members_model);
            }
            members_model.parentNode.removeChild(members_model);
        }
        while (shell_access.hasChildNodes()) {
            shell_access.parentNode.insertBefore(shell_access.firstChild, shell_access);
        }
        shell_access.parentNode.removeChild(shell_access);
        return timeout_index;
    }
    function insert_point() {
        path_range.timeoutID = null;
        if (path_range.sourceLink) {
            if (path_range.showLink === path_range.sourceLink) {
                settle_architecture();
            } else {
                if (metro_actor.keywordArray[move_account(path_range.sourceLink)].displayItem.logoFormat === "5") {
                    settle_architecture();
                } else {
                    substract_values();
                }
            }
        } else if (path_range.activeAd) {
            settle_architecture();
        } else if (path_range.showLink && path_range.delayed <= path_range.hideDelay) {
            path_range.delayed += path_range.delay;
            settle_architecture();
            return;
        } else if (path_range.showLink) {
            write_range();
        }
        path_range.delayed = 0;
    }
    function verify_gate(timetable_broker) {
        return queue_theme.transHelp + (queue_theme.transHelp.indexOf("?") !== -1 ? "&" : "?") + "t=" + queue_theme.adsType[timetable_broker] + (queue_theme.appName !== "" ? "&an=" + tier_queue.encodeURI(queue_theme.appName) : "");
    }
    function replace_value(worker_store) {
        var tool_moduo = worker_store || service_word.event, path_theme = tier_queue.getBrowserInfo();
        if ((typeof path_theme.chrome !== "undefined" || typeof path_theme.mozilla !== "undefined" && handle_access.IEVersion === 0) && tool_moduo.button === 1) {
            return;
        }
        if (handle_access.displayEngine === 98 || handle_access.displayEngine === 99) {
            tier_queue.cancelClickEvent(tool_moduo);
        }
        path_range.sourceLink = tier_queue.getEventSource(worker_store);
        var configs_notification = path_range.sourceLink.id.substring(path_range.sourceLink.id.lastIndexOf("_") + 1);
        if (metro_actor.keywordArray[configs_notification].displayItem.clickUrl.length < 2) {
            return false;
        }
        view_value(metro_actor.keywordArray[configs_notification].displayItem.clickUrl + "&l=1&a=" + (typeof metro_actor.keywordArray[configs_notification].viewed === "undefined" ? "0" : "1") + "&d=" + (typeof metro_actor.noDisplay === "undefined" ? "0" : "1") + "&st=" + queue_theme.optParams);
        return false;
    }
    function abort_parameters() {
        path_range.cdnDomain = unit_thread.get().cdnDomain;
        session_ticket.register({
            instance: this,
            events: {
                TLRSRVDATA: {
                    type: "TLRSRVDATA",
                    handler: read_tier
                },
                SHOWTLADDIV: {
                    type: "SHOWTLADDIV",
                    handler: read_metro
                },
                SRVDATA: {
                    type: "SRVDATA",
                    handler: return_ticket
                },
                HIDETLAD: {
                    type: "HIDETLAD",
                    handler: write_range
                }
            },
            name: "TL"
        });
    }
    function substract_power() {
        path_range.sourceLink = null;
    }
    function substract_point() {
        if (path_range.timeoutID) {
            service_word.clearTimeout(path_range.timeoutID);
            path_range.timeoutID = null;
        }
    }
    function write_server() {
        var members_broker;
        var config_query = timeout_logic.createElement("iframe");
        config_query.setAttribute("frameborder", "0");
        config_query.setAttribute("scrolling", "no");
        config_query.setAttribute("marginwidth", "0");
        config_query.setAttribute("marginheight", "0");
        config_query.setAttribute("allowtransparency", "true");
        config_query.setAttribute("style", "border: 0px; width: 0px !important; height: 0px !important;");
        timeout_logic.body.appendChild(config_query);
        switch (arguments.length) {
          case 1:
            members_broker = config_query.contentWindow.open(arguments[0]);
            tier_parameters.send(tier_parameters.BACKGROUND, "TEXTLINK_LP_SHOWN");
            break;

          case 2:
            members_broker = config_query.contentWindow.open(arguments[0], arguments[1]);
            tier_parameters.send(tier_parameters.BACKGROUND, "TEXTLINK_LP_SHOWN");
            break;

          case 3:
            members_broker = config_query.contentWindow.open(arguments[0], arguments[1], arguments[2]);
            tier_parameters.send(tier_parameters.BACKGROUND, "TEXTLINK_LP_SHOWN");
            break;

          default:
            break;
        }
        timeout_logic.body.removeChild(config_query);
        return members_broker;
    }
    function adaptive_parameters() {
        if (path_range.adDiv) {
            path_range.adDiv.contentWindow.postMessage("ADDATA#&#" + navigate_model(metro_actor) + "#&#" + queue_theme.appName + "#&#" + verify_gate(0) + "#&#" + queue_theme.transHelpWin + "#&#" + queue_theme.network + "#&#" + queue_theme.params + "#&#" + accuracy_path.getActiveTrackingDomain() + "#&#" + queue_theme.helpURL + "#&#" + handle_access.IEVersion + "#&#" + queue_theme.cdnDomain, "*");
            test_alarm();
        } else {
            service_word.setTimeout(adaptive_parameters, 50);
        }
    }
    function abolish_project(service_values, path_counter, positive_practical) {
        return '<object id="flid" ' + (tier_queue.IEVersion > 0 && tier_queue.IEVersion < 11 ? 'classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0"' : 'data="' + service_values + '" type="application/x-shockwave-flash"') + '  width="' + path_counter + '" height="' + positive_practical + '">' + (tier_queue.IEVersion != 0 ? '<param name="movie" value="' + service_values + '" />' : "") + '<param name="quality" value="high" />' + '<param name="wmode" value="transparent" />' + '<param name="allowScriptAccess" value="always" />' + "</object>";
    }
    function send_word(tool_moduo) {
        var moduo_unit = tool_moduo.data.toString(), acceptor_server = moduo_unit.split("#&#"), list_timeout = acceptor_server[0], entry_accuracy = acceptor_server[1];
        try {
            switch (list_timeout) {
              case "TLTMPLRD":
                adaptive_parameters();
                break;

              case "SHOWTL":
                addition_handle(entry_accuracy);
                break;

              case "OPENADURL":
                view_value(entry_accuracy);
                break;

              case "HIDETL":
                write_range();
                break;

              case "TLLPOPEN":
                tier_parameters.send(tier_parameters.BACKGROUND, "TEXTLINK_LP_SHOWN");
                break;

              default:
                break;
            }
        } catch (worker_unit) {}
    }
    function read_tier(tool_moduo) {
        return_ticket(tool_moduo, true);
    }
    function move_account(server_unit) {
        var list_parameters = server_unit.id, storage_config = list_parameters.lastIndexOf("_") + 1;
        return list_parameters.slice(storage_config);
    }
    function view_value(thread_list, abstractor_range) {
        if (thread_list === "") {
            return false;
        }
        write_server(thread_list, "_blank", abstractor_range);
        write_range();
        accuracy_path.log("frd-log", thread_list);
    }
    function test_alarm(tier_gate) {
        var config_ticket = metro_actor.keywordArray, shell_parameters;
        if (typeof tier_gate !== "undefined") {
            for (shell_parameters = config_ticket.length - tier_gate; shell_parameters < config_ticket.length; shell_parameters++) {
                timeout_server[shell_parameters] = new Image();
                timeout_server[shell_parameters].src = config_ticket[shell_parameters].displayItem.logoPath;
            }
        } else {
            for (shell_parameters = 0; shell_parameters < config_ticket.length; shell_parameters++) {
                var session_index = config_ticket[shell_parameters].displayItem.logoFormat;
                if (session_index === "1") {
                    timeout_server[shell_parameters] = new Image();
                    timeout_server[shell_parameters].src = config_ticket[shell_parameters].displayItem.logoPath;
                } else if (session_index === "2") {
                    var positive_actor = document.createElement("div");
                    positive_actor.innerHTML = abolish_project(config_ticket[shell_parameters].displayItem.logoPath, 1, 1);
                    document.body.appendChild(positive_actor);
                    if (service_word.addEventListener) {
                        service_word.addEventListener("load", function() {
                            document.body.removeChild(positive_actor);
                        });
                    } else {
                        service_word.attachEvent("onload", function() {
                            document.getElementsByTagName("body")[0].removeChild(positive_actor);
                        });
                    }
                }
            }
        }
    }
    function make_theme(parameters_actor) {
        return parameters_actor.sort(function(ticket_access, moduo_material) {
            let access_ticket = parseInt(ticket_access.nodeId, 10), parameters_positive = parseInt(moduo_material.nodeId, 10), storage_text, system_accuracy, power_text, account_mutex, mutex_accuracy, point_tier;
            if (access_ticket === parameters_positive) {
                storage_text = parseInt(ticket_access.keywordId, 10);
                system_accuracy = parseInt(moduo_material.keywordId, 10);
                if (storage_text === system_accuracy) {
                    let value_thread = handle_access.nodesMap[access_ticket].node.data.substr(storage_text, handle_access.nodesMap[access_ticket].chunkPositions[storage_text]), power_configsA = new RegExp(`\\b${ticket_access.keyword.replace(/ /g, account_worker)}\\b`, "gi"), account_system = new RegExp(`\\b${moduo_material.keyword.replace(/ /g, account_worker)}\\b`, "gi"), accuracy_signal = [], text_store = [], tier_clock;
                    while (tier_clock = power_configsA.exec(value_thread)) {
                        accuracy_signal.push(tier_clock.index);
                    }
                    while (tier_clock = account_system.exec(value_thread)) {
                        text_store.push(tier_clock.index);
                    }
                    if (accuracy_signal.length > 0 && text_store.length > 0) {
                        power_text = accuracy_signal.shift();
                        account_mutex = text_store.shift();
                        mutex_accuracy = accuracy_signal.pop() || power_text;
                        point_tier = text_store.pop() || account_mutex;
                        if (power_text === account_mutex) {
                            if (mutex_accuracy === point_tier) {
                                return moduo_material.keyword.length - ticket_access.keyword.length;
                            } else {
                                return point_tier - mutex_accuracy;
                            }
                        } else {
                            return account_mutex - power_text;
                        }
                    } else {
                        return text_store.length - accuracy_signal.length;
                    }
                } else {
                    return system_accuracy - storage_text;
                }
            } else {
                return parameters_positive - access_ticket;
            }
        });
    }
    function read_metro(broker_index) {
        var notification_point = broker_index[0], notification_ticket = broker_index[1], store_account = parseInt(broker_index[2]);
        if (!path_range.showLink) {
            path_range.adDiv.style.width = "1px";
            path_range.adDiv.style.height = "1px";
            return;
        }
        var counter_acceptor = parseInt(timeout_logic.getElementsByTagName("html")[0].style.marginTop, 10), point_name = isNaN(counter_acceptor) ? 0 : counter_acceptor, positive_worker = tier_queue.getPageInfo(), word_unit = tier_queue.getStyle(timeout_logic.body, "position") !== "relative" ? point_name : 0, timetable_storage = metro_actor.keywordArray[move_account(path_range.showLink)], alarm_shell = 0, thread_configs = 0, point_theme, shell_power, access_positive;
        positive_worker.pageYOffset -= point_name;
        if (notification_point > positive_worker.innerWidth + 20 || notification_ticket > positive_worker.innerHeight + 10) {
            return;
        }
        path_range.canExpand = false;
        if (queue_theme.customTLUnit === "no") {
            alarm_shell = tier_queue.absoluteLeft(path_range.showLink);
            shell_power = positive_worker.innerWidth + positive_worker.pageXOffset - (alarm_shell + notification_point);
            if (shell_power < 10) {
                alarm_shell += shell_power;
            }
            thread_configs = tier_queue.absoluteTop(path_range.showLink) + path_range.showLink.offsetHeight;
            access_positive = positive_worker.innerHeight + positive_worker.pageYOffset - (thread_configs + notification_ticket);
            if (access_positive < 10) {
                thread_configs = tier_queue.absoluteTop(path_range.showLink) - notification_ticket;
            }
            path_range.adDiv.style.left = (alarm_shell > positive_worker.pageXOffset ? alarm_shell : positive_worker.pageXOffset) + "px";
            path_range.adDiv.style.top = (thread_configs > positive_worker.pageYOffset ? thread_configs : positive_worker.pageYOffset) + "px";
        } else if (queue_theme.customTLUnit === "v1") {
            if (timetable_storage.displayItem.type === "7" && !timetable_storage.displayItem.arrow) {
                alarm_shell = tier_queue.absoluteLeft(path_range.showLink) - store_account;
                thread_configs = tier_queue.absoluteTop(path_range.showLink) + path_range.showLink.offsetHeight + 2;
                access_positive = positive_worker.innerHeight + positive_worker.pageYOffset - (thread_configs + notification_ticket);
                point_theme = 0;
                if (access_positive < 10) {
                    thread_configs = tier_queue.absoluteTop(path_range.showLink) - notification_ticket;
                }
                if (alarm_shell + notification_point > positive_worker.innerWidth) {
                    alarm_shell = tier_queue.absoluteLeft(path_range.showLink) - notification_point + path_range.showLink.offsetWidth;
                }
                path_range.adDiv.style.left = (alarm_shell > positive_worker.pageXOffset ? alarm_shell : positive_worker.pageXOffset) + "px";
                if (thread_configs > positive_worker.pageYOffset) {
                    path_range.adDiv.style.top = thread_configs + word_unit + "px";
                } else {
                    path_range.adDiv.style.top = positive_worker.pageYOffset + word_unit + "px";
                }
                path_range.adDiv.contentWindow.postMessage("SETSTRIP" + "#&#" + point_theme, "*");
            } else {
                alarm_shell = tier_queue.absoluteLeft(path_range.showLink) + path_range.showLink.offsetWidth;
                shell_power = positive_worker.innerWidth + positive_worker.pageXOffset - (alarm_shell + notification_point);
                point_theme = 1;
                if (shell_power < 10) {
                    alarm_shell -= notification_point + path_range.showLink.offsetWidth;
                    point_theme = 2;
                }
                thread_configs = tier_queue.absoluteTop(path_range.showLink) + path_range.showLink.offsetHeight / 2 - 30;
                access_positive = positive_worker.innerHeight + positive_worker.pageYOffset - (thread_configs + notification_ticket);
                if (access_positive < 10) {
                    thread_configs = tier_queue.absoluteTop(path_range.showLink) - notification_ticket + 30 + path_range.showLink.offsetHeight / 2;
                    point_theme += 2;
                }
                path_range.adDiv.style.left = (alarm_shell > positive_worker.pageXOffset ? alarm_shell : positive_worker.pageXOffset) + "px";
                word_unit = tier_queue.getStyle(timeout_logic.body, "position") !== "relative" ? point_name : 0;
                if (thread_configs > positive_worker.pageYOffset) {
                    path_range.adDiv.style.top = thread_configs + word_unit + "px";
                } else {
                    path_range.adDiv.style.top = positive_worker.pageYOffset + word_unit + "px";
                    point_theme = 0;
                }
            }
            path_range.adDiv.contentWindow.postMessage("SETSTRIP" + "#&#" + point_theme, "*");
        }
        path_range.adDiv.style.width = notification_point + "px";
        path_range.adDiv.style.height = (timetable_storage.displayItem.type === "7" ? notification_ticket + 2 : notification_ticket) + "px";
        if (path_range.iFrame != null) {
            path_range.iFrame.style.left = path_range.adDiv.offsetLeft + "px";
            path_range.iFrame.style.top = path_range.adDiv.offsetTop + "px";
            path_range.iFrame.style.width = notification_point + "px";
            path_range.iFrame.style.height = notification_ticket + "px";
            path_range.iFrame.style.visibility = "visible";
        }
        timetable_storage.viewed = 1;
        settle_architecture();
    }
    function calcandreturn_unit(positive_signal) {
        path_range.sourceLink = tier_queue.getEventSource(positive_signal);
        var configs_notification = path_range.sourceLink.id.substring(path_range.sourceLink.id.lastIndexOf("_") + 1), gate_config = "faFAimpTracking" + configs_notification;
        if (metro_actor.keywordArray[configs_notification].displayItem.impressionUrl !== "" && !timeout_logic.getElementById(gate_config)) {
            var gate_system = timeout_logic.createElement("img");
            gate_system.id = gate_config;
            gate_system.src = metro_actor.keywordArray[configs_notification].displayItem.impressionUrl + "&o=" + path_range.impOrd++ + "&l=" + metro_actor.keywordArray.length;
            gate_system.width = 1;
            gate_system.height = 1;
            gate_system.style.width = "1px";
            gate_system.style.height = "1px";
            timeout_logic.body.appendChild(gate_system);
        }
        if (metro_actor.keywordArray[configs_notification].displayItem.logoFormat !== "5" && (metro_actor.keywordArray[configs_notification].displayItem.type > 2 || typeof metro_actor.noDisplay === "undefined" || metro_actor.noDisplay === 0 || metro_actor.keywordArray[configs_notification].displayItem.logoFormat === "4" || typeof metro_actor.keywordArray[configs_notification].ignoreNoDisplay !== "undefined")) {
            settle_architecture();
        }
        metro_actor.noDisplay = 0;
    }
    function share_point() {
        path_range.activeAd = null;
    }
    function test_metro() {
        if (typeof service_word.addEventListener !== "undefined") {
            service_word.addEventListener("message", send_word, false);
        }
    }
    function settle_architecture() {
        substract_point();
        path_range.timeoutID = service_word.setTimeout(insert_point, path_range.delay);
    }
    function exist_alarm(worker_store) {
        path_range.activeAd = tier_queue.getEventSource(worker_store);
        settle_architecture();
    }
    function addition_handle(system_server) {
        var abstractor_range = JSON.parse(system_server);
        document.getElementById("pxLeadPh").style.display = "block";
        read_metro([ abstractor_range.width, abstractor_range.height, abstractor_range.adMarginLeft ]);
    }
    return {
        run: return_ticket,
        __module: configs_text,
        init: abort_parameters
    };
}());
__ppl.loader = __ppl.loader || {};

__ppl.loader["YYQ"] = __ppl.loader["YYQ"] || [];

__ppl.loader["YYQ"].push(function() {
    var queue_theme, tier_queue, power_config, tier_parameters, accuracy_path, configs_text = {
        deps: [ "config", "util", "comm-channel", "lp-check", "logger" ],
        bind: function() {
            var shell_parameters = 0;
            queue_theme = arguments[shell_parameters++];
            tier_queue = arguments[shell_parameters++];
            tier_parameters = arguments[shell_parameters++];
            power_config = arguments[shell_parameters++];
            accuracy_path = arguments[shell_parameters++];
        },
        name: "lp-scraper"
    };
    var timeout_logic = document;
    function increment_store(abstractor_range) {
        try {
            tier_parameters.send(tier_parameters.SERVING, "LP_SEND_SCRAPE", {
                requestParams: abstractor_range
            });
        } catch (worker_unit) {
            accuracy_path.log("lp-scr-sndprm-ex", worker_unit.toString());
        }
    }
    function return_ticket() {
        let signal_gate = queue_theme.get().lplUrl;
        if (typeof signal_gate === "string") {
            increment_store({
                data: put_unit(),
                url: signal_gate
            });
        }
    }
    function put_unit() {
        var clock_session = power_config.getAdInfo();
        return {
            page_title: tier_queue.getTitleContent(),
            network: queue_theme.get().network,
            uri: timeout_logic.location.href,
            cc: clock_session !== null ? clock_session.lpDebugStr : "",
            referrer: timeout_logic.referrer,
            content: timeout_logic.location.protocol === "http:" ? timeout_logic.getElementsByTagName("html")[0].innerHTML : ""
        };
    }
    function calculate_power() {
        tier_parameters.addListener("RUN_LPSCR", return_ticket);
    }
    return {
        run: return_ticket,
        __module: configs_text,
        init: calculate_power
    };
}());
