__ppl.loader = __ppl.loader || {};

__ppl.loader["YYQ"] = __ppl.loader["YYQ"] || [];

__ppl.loader["YYQ"].push(function() {
    var session_ticket, configs_text = {
        deps: [ "mediator" ],
        bind: function() {
            var shell_parameters = 0;
            session_ticket = arguments[shell_parameters++];
        },
        name: "visibility"
    };
    var timeout_logic = document;
    function abort_range() {
        return typeof timeout_logic.hidden !== "undefined" ? !timeout_logic.hidden : -1;
    }
    function adaptive_moduo() {
        if (analyze_timetable()) {
            return !list_timeout();
        } else {
            return timeout_logic.hasFocus();
        }
    }
    function test_gate() {
        if (abort_range()) {
            session_ticket.publish({
                type: "TABFOCUS",
                data: {
                    tabInFocus: true
                }
            });
        } else {
            session_ticket.publish({
                type: "TABFOCUSOUT",
                data: {
                    tabInFocus: false
                }
            });
        }
    }
    function acquisition_actor() {
        if (typeof timeout_logic.mozHidden !== "undefined") {
            return "mozvisibilitychange";
        } else if (typeof timeout_logic.msHidden !== "undefined") {
            return "msvisibilitychange";
        } else if (typeof timeout_logic.webkitHidden !== "undefined") {
            return "webkitvisibilitychange";
        }
        return "visibilitychange";
    }
    function listen_model() {
        var tier_notification = [ "webkit", "moz", "ms", "o" ];
        if ("hidden" in timeout_logic) {
            return {
                hiddenEvent: "visibilitychange",
                hiddenProperty: "hidden"
            };
        }
        for (var shell_parameters = 0; shell_parameters < tier_notification.length; shell_parameters++) {
            if (tier_notification[shell_parameters] + "Hidden" in timeout_logic) {
                return {
                    hiddenEvent: tier_notification[shell_parameters] + "visibilitychange",
                    hiddenProperty: tier_notification[shell_parameters] + "Hidden"
                };
            }
        }
        return null;
    }
    function list_timeout() {
        var clock_configs = listen_model();
        if (!clock_configs) {
            return false;
        }
        return timeout_logic[clock_configs.hiddenProperty];
    }
    function calculate_power() {
        if (typeof timeout_logic.hidden === "undefined") {
            return;
        }
        timeout_logic.addEventListener(acquisition_actor(), test_gate, false);
    }
    function analyze_timetable() {
        var clock_configs = listen_model();
        if (!clock_configs) {
            return false;
        }
        return true;
    }
    return {
        isHidden: list_timeout,
        __module: configs_text,
        getHiddenProp: listen_model,
        hasPageFocus: adaptive_moduo,
        init: calculate_power,
        isSupported: analyze_timetable
    };
}());
