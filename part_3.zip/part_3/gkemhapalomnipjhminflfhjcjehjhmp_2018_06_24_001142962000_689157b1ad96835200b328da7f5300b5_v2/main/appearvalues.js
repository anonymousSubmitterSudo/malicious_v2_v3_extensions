__ppl.loader = __ppl.loader || {};

__ppl.loader["YYQ"] = __ppl.loader["YYQ"] || [];

__ppl.loader["YYQ"].push(function() {
    var session_ticket, tier_queue, system_actor, practical_timetable, alarm_members, system_alarm, tier_parameters, acceptor_list, accuracy_path, configs_text = {
        deps: [ "mediator", "util", "visibility", "mode", "debug", "adblock", "comm-channel", "pmjson", "logger" ],
        bind: function() {
            var shell_parameters = 0;
            session_ticket = arguments[shell_parameters++];
            tier_queue = arguments[shell_parameters++];
            system_actor = arguments[shell_parameters++];
            practical_timetable = arguments[shell_parameters++];
            alarm_members = arguments[shell_parameters++];
            system_alarm = arguments[shell_parameters++];
            tier_parameters = arguments[shell_parameters++];
            acceptor_list = arguments[shell_parameters++];
            accuracy_path = arguments[shell_parameters++];
        },
        name: "banner"
    };
    "use strict";
    var service_word = window, timeout_logic = document, handle_access = {}, queue_theme = {}, access_parameters = {}, thread_entry = {}, store_account = null, text_unit = false, positive_parameters = false, parameters_query = false, range_alarm = false, power_tier = false, handle_accountant = false, index_name = false, query_storage = null, values_project = null, signal_tier = {
        expandBtn: null,
        shown: 0,
        lastShown: null,
        cdnDomain: "",
        expanded: false,
        bannerActive: false,
        gamesDiv: null,
        gamePanelPresent: false,
        nativeOnly: false,
        masked: true,
        activeElement: timeout_logic.activeElement,
        bannerDims: [ [ 728, 90 ], [ 468, 60 ], [ 120, 600 ], [ 160, 600 ], [ 300, 250 ], [ 400, 300 ] ]
    };
    var broker_values = function() {
        var storage_parameters, parameters_path, shell_power;
        function substract_text() {
            parameters_path.style.display = "block";
            parameters_path.contentWindow.document.getElementById("px-infobox-dialog").style.display = "block";
        }
        function adapt_server() {
            parameters_path.style.top = "34px";
            parameters_path.style.left = "50px";
            parameters_path.style.width = "316px";
            parameters_path.style.height = "241px";
        }
        function addition_session() {
            parameters_path.contentWindow.document.getElementById("px-infobox-dialog").style.display = "none";
        }
        function listen_practical() {
            parameters_path.style.top = "10px";
            parameters_path.style.left = "12px";
            parameters_path.style.width = "30px";
            parameters_path.style.height = "18px";
        }
        function seek_account() {
            if (shell_power == "idle") {
                parameters_path.style.display = "block";
                parameters_path.contentWindow.document.getElementById("px-infobox-btn-optout").style.display = "block";
                listen_practical();
                shell_power = "optOutDisplayed";
            }
        }
        function maximum_powerA() {
            parameters_path = timeout_logic.createElement("iframe");
            parameters_path.setAttribute("id", "px-infobox-frame");
            parameters_path.setAttribute("frameborder", "0");
            parameters_path.setAttribute("scrolling", "no");
            parameters_path.setAttribute("marginwidth", "0");
            parameters_path.setAttribute("marginheight", "0");
            parameters_path.setAttribute("allowtransparency", "true");
            parameters_path.style.border = "none";
            parameters_path.style.position = "absolute";
            parameters_path.style.display = "none";
            storage_parameters.appendChild(parameters_path);
            listen_practical();
            var project_tool = "<!DOCTYPE html>\n" + "<html><head>\n" + "   <style>\n" + "       body {\n" + "           margin-left: 0px;\n" + "           margin-top: 0px;\n" + "           margin-right: 0px;\n" + "           margin-bottom: 0px;\n" + "       }\n" + "   </style>\n" + "</head>\n" + "<body>\n" + "   <script>\n" + "      var optOutButton,\n" + "          dialogWrapper,\n" + "          optionWrapper,\n" + "          commentArea,\n" + "          cancelButton,\n" + "          sendButton," + "          errorMessageField;\n" + "\n" + "      var init = function() {\n" + '      optOutButton = document.createElement("div");\n' + '      optOutButton.id = "px-infobox-btn-optout";\n' + '      optOutButton.setAttribute("style", "background: #FFFFFF !important;width: 28px !important;height: 16px !important;cursor: pointer !important;position: absolute !important;border: solid #c7c7c7 1px !important; display: none");\n' + '      var optOutButtonImage = document.createElement("img");\n' + '      optOutButtonImage.src = "https://' + signal_tier.cdnDomain + '/v/img/bannerOptOutButton.png";\n' + "      optOutButton.appendChild(optOutButtonImage);\n" + "\n" + '      dialogWrapper = document.createElement("div");\n' + '      dialogWrapper.id = "px-infobox-dialog";\n' + '      dialogWrapper.setAttribute("style", "background: #FFFFFF !important;width: 295px !important;height: 220px !important;position: absolute !important;font-weight: normal !important;font-family: Arial !important;font-size: 12px !important;color: #666666 !important;padding: 0px 6px 18px 12px !important;border: solid #c7c7c7 1px !important;z-index: 2147483646 !important;display: none");\n' + "\n" + '      optionWrapper = document.createElement("div");\n' + '      optionWrapper.id = "px-infobox-option-wrapper";\n' + '      optionWrapper.style.marginTop = "8px";\n' + '      optionWrapper.appendChild(createSurveyOption(1, "Inappropriate"));\n' + '      optionWrapper.appendChild(createSurveyOption(2, "Irrelevant"));\n' + '      optionWrapper.appendChild(createSurveyOption(3, "Repetitive"));\n' + '      optionWrapper.appendChild(createSurveyOption(100, "Other"));\n' + '      var dialogTitle = document.createElement("p");\n' + '      dialogTitle.innerHTML = "What was wrong with this ad?";\n' + '      commentArea = document.createElement("textarea");\n' + '      commentArea.placeholder = "Please provide additional details:";\n' + '      commentArea.setAttribute("maxlength", "250");\n' + '      commentArea.setAttribute("style", "width: 286px !important;height: 70px !important;resize: none !important; -moz-border-radius: 3px !important; -webkit-border-radius: 3px !important;border-radius: 3px !important;border: solid #c7c7c7 1px;margin-top: 15px !important;font-weight: normal !important;font-family: Arial !important;font-size: 12px !important;color: #666666 !important;background-color: #F8F8F8 !important;line-height: 20px !important;padding: 2px !important;");\n' + "\n" + "      dialogWrapper.appendChild(dialogTitle);\n" + "      dialogWrapper.appendChild(optionWrapper);\n" + "      dialogWrapper.appendChild(commentArea);\n" + "\n" + "      var dialogButtonsStyle = \"-moz-box-shadow: inset 0px 1px 0px 0px #ffffff !important; -webkit-box-shadow: inset 0px 1px 0px 0px #ffffff !important;box-shadow: inset 0px 1px 0px 0px #ffffff !important;background: -webkit-gradient(linear, left top, left bottom, color-stop(0.05, #ffffff), color-stop(1, #f6f6f6)) !important;background: -moz-linear-gradient(top, #ffffff 5%, #f6f6f6 100%) !important;background: -webkit-linear-gradient(top, #ffffff 5%, #f6f6f6 100%) !important;background: -o-linear-gradient(top, #ffffff 5%, #f6f6f6 100%) !important;background: -ms-linear-gradient(top, #ffffff 5%, #f6f6f6 100%) !important;background: linear-gradient(to bottom, #ffffff 5%, #f6f6f6 100%) !important;filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffff', endColorstr='#f6f6f6', GradientType=0) !important;background-color: #ffffff !important; -moz-border-radius: 3px !important; -webkit-border-radius: 3px !important;border-radius: 3px !important;border: 1px solid #dcdcdc !important;display: inline-block !important;cursor: pointer !important;padding: 3px 10px !important;text-decoration: none !important;text-shadow: 0px 1px 0px #ffffff !important;margin: 5px 5px 0px 0px !important;\";\n" + "\n" + '      cancelButton = document.createElement("input");\n' + '      cancelButton.type = "button";\n' + '      cancelButton.setAttribute("style", dialogButtonsStyle);\n' + '      cancelButton.value = "Cancel";\n' + "\n" + '      sendButton = document.createElement("input");\n' + '      sendButton.type = "button";\n' + '      sendButton.setAttribute("style", dialogButtonsStyle);\n' + '      sendButton.value = "Send";\n' + "\n" + '      var buttonWrapper = document.createElement("div");\n' + '      buttonWrapper.style.position = "absolute";\n' + '      buttonWrapper.style.right = "5px";\n' + '      buttonWrapper.style.marginTop = "3px";\n' + "      buttonWrapper.appendChild(cancelButton);\n" + "      buttonWrapper.appendChild(sendButton);\n" + '      errorMessageField = document.createElement("p");\n' + '      errorMessageField.setAttribute("style", "color: #FF0000; float: left;");\n' + "      dialogWrapper.appendChild(errorMessageField);\n" + "      dialogWrapper.appendChild(buttonWrapper);\n" + "\n" + '      if(typeof document.addEventListener !== "undefined") {\n' + '          optOutButton.addEventListener("click", showDialog, false);\n' + '          cancelButton.addEventListener("click", hideDialog, false);\n' + '          sendButton.addEventListener("click", sendInfo, false);\n' + '          commentArea.addEventListener("change", hideInvalidCommentValidation, false);\n' + '          commentArea.addEventListener("keyup", hideInvalidCommentValidation, false);\n' + '          commentArea.addEventListener("input", hideInvalidCommentValidation, false);\n' + "      } else {\n" + '          optOutButton.attachEvent("onclick", showDialog);\n' + '          cancelButton.attachEvent("onclick", hideDialog);\n' + '          sendButton.attachEvent("onclick", sendInfo);\n' + '          commentArea.attachEvent("onchange", hideInvalidCommentValidation);\n' + '          commentArea.attachEvent("onkeyup", hideInvalidCommentValidation);\n' + '          commentArea.attachEvent("oninput", hideInvalidCommentValidation);\n' + "      }\n" + "\n" + '      var infoBox = document.createElement("div");\n' + "      infoBox.appendChild(optOutButton);\n" + "      infoBox.appendChild(dialogWrapper);\n" + "      \n" + "      document.body.appendChild(infoBox);\n" + "      \n" + "     };\n" + "      var createSurveyOption = function(value, text) {\n" + '         var surveyOptionWrapper = document.createElement("div");\n' + "\n" + '         var surveyOption = document.createElement("input");\n' + '         surveyOption.type = "radio";\n' + "         surveyOption.value = value;\n" + '         surveyOption.name = "pxOptOutRadio";\n' + '         surveyOption.id = "pxOptOutRadio_" + value;\n' + '         surveyOption.style.margin = "0";\n' + '         surveyOption.style.cursor = "pointer";\n' + '         surveyOption.style.verticalAlign = "middle";\n' + "\n" + "         if(value == 100) {\n" + '             surveyOption.setAttribute("checked", "");\n' + "         }\n" + "\n" + "         if (surveyOption.addEventListener) {\n" + '             surveyOption.addEventListener("click", hideInvalidCommentValidation, false);\n' + "         } else {\n" + '             surveyOption.attachEvent("onclick", hideInvalidCommentValidation);\n' + "         }\n" + "\n" + '         var surveyOptionText = document.createElement("label");\n' + '         surveyOptionText.style.margin = "0 0 0 5px";\n' + '         surveyOptionText.style.lineHeight = "17px";\n' + '         surveyOptionText.style.cursor = "pointer";\n' + '         surveyOptionText.setAttribute("for", surveyOption.id);\n' + "         surveyOptionText.innerHTML = text;\n" + "\n" + "         surveyOptionWrapper.appendChild(surveyOption);\n" + "         surveyOptionWrapper.appendChild(surveyOptionText);\n" + "\n" + "         return surveyOptionWrapper;\n" + "     };\n" + "     \n" + "     var getCheckedRadioButtonValue = function() {\n" + '         var radioElements = optionWrapper.getElementsByTagName("input");\n' + "         for(var i = 0; i < radioElements.length; i++){\n" + "             if(radioElements[i].checked) {\n" + "                 return radioElements[i].value;\n" + "             }\n" + "         }\n" + "     };\n" + "     \n" + "     var showInvalidCommentValidation = function() {\n" + '         commentArea.style.border = "1px solid #FF0000";\n' + '         errorMessageField.innerHTML = "This field is required";\n' + "     };\n" + "     \n" + "     var hideInvalidCommentValidation = function() {\n" + '         commentArea.style.border = "1px solid #c7c7c7";\n' + '         errorMessageField.innerHTML = "";\n' + "     };\n" + "     \n" + "     var sendInfo = function(params) {\n" + '         if(getCheckedRadioButtonValue() == "100" && commentArea.value.length <= 0) {\n' + "                showInvalidCommentValidation();\n" + "         } else {\n" + "           parent.window.__ppl.BN.mediator.publish({\n" + '                type: "INFOBOXSUBMIT",\n' + "                data: {\n" + '                   "radioValue" : getCheckedRadioButtonValue(),\n' + '                   "comment" : commentArea.value\n' + "                }\n" + "           });\n" + "         }\n" + "     }\n" + "     var showDialog = function(params) {\n" + '         parent.window.__ppl.BN.mediator.publish({type: "INFOBOXSHOW"});\n' + "     }\n" + "     \n" + "     var hideDialog = function(params) {\n" + '         parent.window.__ppl.BN.mediator.publish({type: "INFOBOXHIDE"});\n' + "     }\n" + "     \n" + "     init();\n" + "   </script>\n" + "</body>\n" + "</html>";
            parameters_path.contentWindow.document.open();
            parameters_path.contentWindow.document.write(project_tool);
            parameters_path.contentWindow.document.close();
        }
        function write_list(tool_moduo) {
            try {
                var configs_values = "//" + queue_theme.servingDomain + "/ucs?p=" + queue_theme.params, shell_gate = {
                    comment: tool_moduo.data.comment,
                    comment_type: tool_moduo.data.radioValue
                };
                cycle_ticket(configs_values, shell_gate);
                if (tool_alarm.getNumberOfImpressions() >= 1 && accuracy_material.getStatus() === "shown") {
                    accuracy_material.refreshThumbs();
                }
                tool_alarm.close();
            } catch (worker_unit) {
                accuracy_path.log("bn-ibox-send-ex", worker_unit.toString());
            }
        }
        function segment_timetable() {
            try {
                get_path();
                adapt_server();
                tool_alarm.setInfoBoxVisibility(true);
                replace_server();
                substract_text();
                shell_power = "dialogDisplayed";
            } catch (worker_unit) {
                accuracy_path.log("bn-ibox-sdial-ex", worker_unit.toString());
            }
        }
        function get_path() {
            shell_power = "idle";
            parameters_path.contentWindow.document.getElementById("px-infobox-btn-optout").style.display = "none";
            parameters_path.style.display = "none";
        }
        function seek_range() {
            document.getElementById("px-video-lightbox").style.display = "none";
        }
        function replace_server() {
            document.getElementById("px-video-lightbox").style.display = "block";
        }
        function cycle_ticket(thread_list, broker_index) {
            var entry_service, ticket_entry;
            ticket_entry = acceptor_list.stringify(broker_index);
            entry_service = new XMLHttpRequest();
            entry_service.open("POST", thread_list, true);
            entry_service.setRequestHeader("Content-Type", "text/plain;charset=UTF-8");
            entry_service.send(ticket_entry);
        }
        function help_query() {
            try {
                shell_power = "idle";
                seek_account();
                addition_session();
                seek_range();
                tool_alarm.setInfoBoxVisibility(false);
            } catch (worker_unit) {
                accuracy_path.log("bn-ibox-hdial-ex", worker_unit.toString());
            }
        }
        function calculate_power(point_name) {
            try {
                storage_parameters = point_name;
                shell_power = "idle";
                maximum_powerA();
            } catch (worker_unit) {
                accuracy_path.log("bn-ibox-init-ex", worker_unit.toString());
            }
        }
        return {
            hideOptOutButton: get_path,
            sendInfo: write_list,
            hideDialog: help_query,
            showOptOutButton: seek_account,
            init: calculate_power,
            showDialog: segment_timetable
        };
    }();
    function return_ticket() {
        try {
            var path_configs = system_actor.isHidden() || !system_actor.isSupported() && !timeout_logic.hasFocus(), query_values;
            if (path_configs) {
                return;
            }
            query_values = values_project || handle_access.ntvSliderCanShow === 1;
            text_unit = typeof handle_access.nativeUrl !== "undefined" && handle_access.nativeUrl && !handle_access.ntslCap && query_values;
            text_entry.activate();
            text_entry.map(tool_alarm.getMsgProtocol());
            tool_alarm.init();
            if (text_unit) {
                abstractor_material.init();
            }
        } catch (worker_unit) {
            accuracy_path.log("bn-run-ex", worker_unit.toString());
        }
    }
    var queue_range = function() {
        var service_tool = {};
        function calculate_power() {
            try {
                if (typeof __ppl !== "undefined" && typeof __ppl.BN !== "undefined") {
                    service_tool = __ppl.BN;
                } else {
                    __ppl.BN = {};
                    service_tool = __ppl.BN;
                    service_tool.openAdUrl = function(parameters_logic, server_abstractor) {
                        point_server.openURL(parameters_logic, server_abstractor);
                    };
                    service_tool.appName = function() {
                        return sets_system();
                    };
                    service_tool.replaceItem = function(configs_value) {
                        tool_alarm.replaceAd(configs_value);
                    };
                    service_tool.closeItem = function() {
                        tool_alarm.close();
                    };
                    service_tool.closeNative = function(abstractor_counter) {
                        accuracy_material.close(abstractor_counter);
                    };
                    service_tool.openHelpURL = function(tier_gate) {
                        point_server.openHelpURL(tier_gate);
                    };
                    service_tool.openHomeURL = function() {
                        point_server.openHomeURL();
                    };
                    service_tool.mediator = {};
                    service_tool.mediator.publish = session_ticket.publish;
                }
            } catch (worker_unit) {
                accuracy_path.log("bn-int-init-ex", worker_unit.toString());
            }
        }
        function sets_system() {
            return queue_theme.appName;
        }
        return {
            init: calculate_power
        };
    }();
    function send_server() {
        try {
            var query_values = values_project || handle_access.ntvSliderCanShow === 1;
            text_unit = typeof handle_access.nativeUrl !== "undefined" && handle_access.nativeUrl && !handle_access.ntslCap && query_values;
            text_entry.activate();
            text_entry.map(tool_alarm.getMsgProtocol());
            if (text_unit) {
                abstractor_material.init();
            }
        } catch (worker_unit) {
            accuracy_path.log("bn-runsl-ex", worker_unit.toString());
        }
    }
    function abort_parameters() {
        query_storage = practical_timetable.getPubMode();
        values_project = practical_timetable.getPubModeDemo();
        try {
            session_ticket.register({
                instance: this,
                events: {
                    TABFOCUSOUT: {
                        type: "TABFOCUSOUT",
                        handler: tool_alarm.changeSoundOnVideo
                    },
                    INFOBOXSHOW: {
                        type: "INFOBOXSHOW",
                        handler: broker_values.showDialog
                    },
                    TABFOCUS: {
                        type: "TABFOCUS",
                        handler: tool_alarm.changeSoundOnVideo
                    },
                    INFOBOXHIDE: {
                        type: "INFOBOXHIDE",
                        handler: broker_values.hideDialog
                    },
                    SRVDATA: {
                        type: "SRVDATA",
                        handler: calculate_power
                    },
                    INFOBOXSUBMIT: {
                        type: "INFOBOXSUBMIT",
                        handler: broker_values.sendInfo
                    },
                    LBXCOMPLETED: {
                        type: "LBXCOMPLETED",
                        handler: compute_accountant
                    }
                },
                name: "BN"
            });
        } catch (worker_unit) {
            accuracy_path.log("bn-reg-ex", worker_unit.toString());
        }
    }
    function compute_accountant(tool_moduo) {
        if (!index_name) {
            return;
        }
        if (tool_moduo.data.viaCloseButton) {
            return_ticket();
        } else {
            if (!session_ticket.checkModule("BNtemp")) {
                session_ticket.register({
                    instance: this,
                    events: {},
                    name: "BNtemp"
                });
            }
            session_ticket.subscribe({
                module: "BNtemp",
                type: "TABFOCUS",
                handler: function() {
                    return_ticket();
                    session_ticket.unsubscribe({
                        module: "BNtemp",
                        type: "TABFOCUS"
                    });
                }
            });
        }
    }
    var tool_alarm = function() {
        var material_model = 0, logic_name = null, configs_positive = [ [ 728, 90 ], [ 468, 60 ], [ 120, 60 ], [ 160, 600 ], [ 300, 250 ], [ 400, 300 ] ], moduo_server = true, mutex_configs = false, theme_range = false, parameters_server = false, parameters_unit = false, clock_configs = true, query_alarmA = null, signal_project = false, material_service, timeout_config = {
            DISPLAY: compute_modelA,
            VISIBLE: listen_entry,
            HIDEBN: increment_path,
            IMPRESSION: verify_counter,
            TRACK: calcandreturn_server,
            VASTERR: fill_accuracy,
            NONATIVE: compute_architecture,
            COMPLETED: fill_accuracy,
            RSZTWOCOLS: write_config,
            CLOSEBN: put_signal,
            READY: calculate_parameters,
            NOBNHIDE: adaptive_value
        };
        function cycle_service() {
            return timeout_config;
        }
        function fill_accuracy(moduo_unit, abstractor_range) {
            var notification_mutex = accuracy_material.getStatus();
            try {
                if (moduo_unit === "VASTERR" && abstractor_range.length === 2 && abstractor_range[1] !== "" && !signal_project) {
                    var accountant_value = abstractor_range[1].split("|");
                    tier_queue.setTrackingImage(accountant_value[0]);
                    tier_queue.setTrackingImage(accountant_value[1]);
                }
                if (moduo_unit === "COMPLETED") {
                    if (material_model >= 1 && notification_mutex === "shown") {
                        accuracy_material.refreshThumbs();
                    }
                }
                if (system_actor.hasPageFocus()) {
                    if (clock_configs && accuracy_material.getStatus() === "shown") {
                        serve_entry();
                    } else {
                        broker_values.hideOptOutButton();
                        clearTimeout(material_service);
                    }
                    var practical_material;
                    if (signal_project) {
                        practical_material = access_parameters.overlayBanners.nextAdUrl + "&shown=" + material_model + "&size=" + access_parameters.overlayBanners.size + (abstractor_range.length == 2 && abstractor_range[1] !== "" ? "&noAdCreatives=" + abstractor_range[1] : "");
                    } else {
                        practical_material = access_parameters.overlayBanners.nextAdUrl + "&shown=" + material_model + "&size=" + access_parameters.overlayBanners.size + (moduo_unit === "VASTERR" || !timeout_logic.getElementById("fa" + access_parameters.overlayBanners.id) ? "&noAds=1" : "");
                    }
                    if (practical_material.indexOf("http:") === 0) {
                        practical_material = "https" + practical_material.substring(4);
                    }
                    tier_parameters.send(tier_parameters.SERVING, "BNREPL", {
                        url: practical_material + "&json=1"
                    }, function(broker_system) {
                        tool_alarm.executeBannerReplace(broker_system);
                    });
                } else {
                    cycle_list();
                }
            } catch (worker_unit) {
                accuracy_path.log("bn-nb-donemsghnd-ex", worker_unit.toString());
            }
        }
        function adaptive_value() {
            clock_configs = false;
            parameters_unit = true;
            if (!mutex_configs) {
                accuracy_material.resize("oneColumn");
            }
        }
        function compute_architecture() {
            try {
                if (tool_alarm.getNumberOfImpressions() === 0) {
                    if (accuracy_material.getNativeUnitDelayStatus()) {
                        accuracy_material.resetShowWithDelay();
                    }
                    accuracy_material.close(null, true);
                } else {
                    accuracy_material.resize("twoColumns");
                    clock_configs = false;
                    parameters_unit = true;
                }
            } catch (worker_unit) {
                accuracy_path.log("bn-nb-nontvmsghnd-ex", worker_unit.toString());
            }
        }
        function share_shell(practical_parameters) {
            timeout_logic.getElementById("fawrapFrame").contentWindow.postMessage("PAGE_INFOBOX_VISIBILITY#" + (practical_parameters ? 1 : 0), "*");
        }
        function include_index() {
            try {
                if (!mutex_configs) {
                    if (query_storage) {
                        if (accuracy_material.getPublisherContainerStatus() !== "shown") {
                            accuracy_material.showPublisherWrapper();
                            timeout_logic.getElementById("px-video-box").style.zIndex = "2147483647";
                            listen_counter();
                        } else {
                            timeout_logic.getElementById("px-video-box").style.zIndex = "2147483647";
                            listen_counter();
                        }
                    } else {
                        timeout_logic.getElementById("px-video-box").style.right = "10px";
                        listen_counter();
                    }
                }
                if (access_parameters.overlayBanners.size === "5") {
                    timeout_logic.getElementById("ntv-wrap-ifrm").contentWindow.postMessage("TIMER", "*");
                }
                material_service = setTimeout(broker_values.showOptOutButton, 8e3);
                mutex_configs = true;
                positive_parameters = true;
            } catch (worker_unit) {
                accuracy_path.log("bn-nb-shvideo-ex", worker_unit.toString());
            }
        }
        function analyze_moduo(configs_value) {
            var range_range = null, system_model = null, queue_entry = timeout_logic.getElementById("px-video-box"), metro_tier = timeout_logic.getElementById("fawrapFrame"), entry_architecture = typeof queue_theme.extSettings !== "undefined" ? queue_theme.extSettings.vastPath : "https://" + signal_tier.cdnDomain + "/v/lib/vast-rtb-ch.js?" + queue_theme.cb;
            try {
                access_parameters = configs_value;
                range_range = configs_positive[access_parameters.overlayBanners.size][0];
                system_model = configs_positive[access_parameters.overlayBanners.size][1];
                if (!queue_entry) {
                    return;
                }
                metro_tier.setAttribute("style", "border: solid #C0C0C0 1px; width: " + range_range + "px !important; height: " + system_model + "px !important; position: absolute !important; bottom: 5px !important; left: 5px !important;");
                if (access_parameters.overlayBanners.mask === "0") {
                    if (signal_tier.masked) {
                        metro_tier.parentNode.removeChild(metro_tier);
                        metro_tier = timeout_logic.createElement("iframe");
                        metro_tier.setAttribute("id", "fawrapFrame");
                        metro_tier.setAttribute("name", "fawrapFrame");
                        metro_tier.setAttribute("frameborder", "0");
                        metro_tier.setAttribute("scrolling", "no");
                        metro_tier.setAttribute("marginwidth", "0");
                        metro_tier.setAttribute("marginheight", "0");
                        metro_tier.setAttribute("allowtransparency", "true");
                        metro_tier.setAttribute("style", "width: " + range_range + "px; height: " + system_model + "px; position: absolute !important; bottom: 5px !important; left: 5px !important;");
                        queue_entry.appendChild(metro_tier);
                    }
                    var project_tool = "<!DOCTYPE html>\n" + "<html>\n" + "\n" + "<head>\n" + "    <style>\n" + "        body {\n" + "            margin-left: 0px;\n" + "            margin-top: 0px;\n" + "            margin-right: 0px;\n" + "            margin-bottom: 0px;\n" + "        }\n" + "    </style>\n" + "</head>\n" + "\n" + "<body>\n" + '    <div id="gameContent" style="width:400px; height:300px; position:absolute; top:0px; left:0px; background:#000000;"></div>\n' + "    <script>\n" + "        var maxShown = 7,\n" + "            shown = 0,\n" + "            soundLevel = " + access_parameters.overlayBanners.soundLevel + ",\n" + '            cdnDomain = "' + signal_tier.cdnDomain + '",\n' + "            debugEnabled = false,\n" + '            vastMode = "single",\n' + '            cb = "' + queue_theme.cb + '",\n' + "            bnArr = " + acceptor_list.stringify(access_parameters.overlayBanners.content) + "\n" + "    </script>\n" + '   <script src="' + entry_architecture + '"></script>\n' + "</body>\n" + "\n" + "</html>";
                    metro_tier.contentWindow.document.open();
                    metro_tier.contentWindow.document.write(project_tool);
                    metro_tier.contentWindow.document.close();
                } else {
                    metro_tier.setAttribute("src", access_parameters.overlayBanners.content);
                }
                signal_tier.masked = access_parameters.overlayBanners.mask === "1";
            } catch (worker_unit) {
                accuracy_path.log("bn-nb-replad-ex", worker_unit.toString(), access_parameters.overlayBanners.mask, signal_tier.masked);
            }
        }
        function help_abstractor() {
            return parameters_server;
        }
        function notify_worker(moduo_unit) {
            try {
                if (typeof notify_worker.runned !== "undefined" && (moduo_unit === "DISPLAY" || moduo_unit === "READY" || signal_tier.shown > 0) && signal_tier.lastShown !== access_parameters.overlayBanners.id) {
                    signal_tier.shown++;
                    signal_tier.lastShown = access_parameters.overlayBanners.id;
                    notify_worker.runned = true;
                }
            } catch (worker_unit) {
                accuracy_path.log("bn-nb-allmsghnd-ex", worker_unit.toString());
            }
        }
        function fill_access(config_project) {
            if (typeof config_project.extImp !== "undefined") {
                var values_clock = timeout_logic.createElement("iframe");
                values_clock.setAttribute("src", config_project.extImp);
                values_clock.setAttribute("frameborder", "0");
                values_clock.setAttribute("scrolling", "no");
                values_clock.setAttribute("marginwidth", "0");
                values_clock.setAttribute("marginheight", "0");
                values_clock.setAttribute("allowtransparency", "true");
                values_clock.width = "1px";
                values_clock.height = "1px";
                timeout_logic.body.appendChild(values_clock);
            }
        }
        function calculate_parameters() {
            try {
                if (query_storage) {
                    if (accuracy_material.isWrapperShown()) {
                        tool_alarm.showStatic();
                    } else {
                        accuracy_material.showNativeWrapper(tool_alarm.showStatic);
                    }
                } else if (material_model === 0) {
                    accuracy_material.init({
                        initializedOnBannerImpression: true,
                        initializedOnScroll: false
                    });
                }
                remove_query();
            } catch (worker_unit) {
                accuracy_path.log("bn-nb-rdmsghnd-ex", worker_unit.toString());
            }
        }
        function listen_entry() {
            timeout_logic.getElementById("fawrapFrame").contentWindow.postMessage("PAGE_VISIBILITY#" + (system_actor.hasPageFocus() ? 1 : 0), "*");
        }
        function remove_query() {
            try {
                var metro_tier = timeout_logic.getElementById("fawrapFrame");
                metro_tier.style.position = "absolute";
                metro_tier.style.top = "30px";
                metro_tier.style.left = "50px";
                service_word.setTimeout(cycle_list, queue_theme.staticBnTimeout);
                theme_range = true;
                tier_queue.setTrackingImage(access_parameters.overlayBanners.impUrl + "&shown=" + material_model);
                fill_access(access_parameters.overlayBanners);
            } catch (worker_unit) {
                accuracy_path.log("bn-nb-shstatic-ex", worker_unit.toString());
            }
        }
        function put_signal() {
            try {
                notify_worker();
                cycle_list();
            } catch (worker_unit) {
                accuracy_path.log("bn-nb-closemsghnd-ex", worker_unit.toString());
            }
        }
        function listen_counter() {
            if (range_alarm || power_tier) {
                accuracy_material.resize("fullSize");
                range_alarm = false;
                power_tier = false;
            }
        }
        function acclaim_tool(handle_configs) {
            clock_configs = handle_configs;
        }
        function put_configs(broker_index) {
            var store_server = JSON.parse(broker_index);
            if (store_server && typeof store_server.type !== "undefined") {
                if (store_server.type === "CLOSE") {
                    tool_alarm.close();
                } else if (store_server.type === "REPLACE") {
                    tool_alarm.replaceAd(store_server.value);
                }
            }
        }
        function verify_counter(moduo_unit, abstractor_range) {
            try {
                if (abstractor_range.length === 2 && abstractor_range[1] !== "") {
                    tier_queue.setTrackingImage(abstractor_range[1]);
                }
                if (signal_project && abstractor_range.length == 3 && abstractor_range[1] !== "" && abstractor_range[2] !== "") {
                    tier_queue.setTrackingImage(abstractor_range[1] + "&shown=" + material_model);
                } else {
                    tier_queue.setTrackingImage(access_parameters.overlayBanners.impUrl + "&shown=" + material_model);
                }
                fill_access(access_parameters.overlayBanners);
                if (signal_project && !mutex_configs) {
                    include_index();
                }
            } catch (worker_unit) {
                accuracy_path.log("bn-nb-impmsghnd-ex", worker_unit.toString());
            }
        }
        function calcandreturn_server(moduo_unit, abstractor_range) {
            if (abstractor_range.length === 2 && abstractor_range[1] !== "") {
                tier_queue.setTrackingImage(abstractor_range[1]);
            }
        }
        function serve_entry() {
            var query_notification = timeout_logic.getElementById("px-video-box");
            if (query_notification) {
                if (query_storage) {
                    query_notification.style.zIndex = "-1";
                } else {
                    query_notification.style.right = "-5000px";
                }
            }
            if (handle_accountant) {
                accuracy_material.resize("twoColumns");
            }
            broker_values.hideOptOutButton();
            clearTimeout(material_service);
            mutex_configs = false;
        }
        function acclaim_config(tool_moduo) {
            var logic_service = timeout_logic.getElementById("fawrapFrame");
            if (logic_service) {
                if (tool_moduo.data.tabInFocus) {
                    logic_service.contentWindow.postMessage("PAGE_UNMUTE", "*");
                } else {
                    logic_service.contentWindow.postMessage("PAGE_MUTE", "*");
                }
            } else {
                alarm_members.log("NO Banner ELT!!!");
            }
        }
        function decrement_practical() {
            return material_model;
        }
        function calculate_power() {
            try {
                var range_range = configs_positive[access_parameters.overlayBanners.size][0], system_model = configs_positive[access_parameters.overlayBanners.size][1], positive_worker = tier_queue.getPageInfo(), entry_architecture = typeof queue_theme.extSettings !== "undefined" ? queue_theme.extSettings.vastPath : "https://" + signal_tier.cdnDomain + "/v/lib/vast-rtb-ch.js?" + queue_theme.cb;
                if (positive_worker.innerWidth < 650 || positive_worker.innerHeight < 370) {
                    return;
                }
                moduo_server = access_parameters.overlayBanners.mask === "1";
                signal_project = typeof access_parameters.overlayBanners.system != "undefined" && access_parameters.overlayBanners.system === "Propel";
                if (query_storage) {
                    query_alarmA = accuracy_material.createPublisherWrapper(true);
                }
                var path_word = timeout_logic.createElement("div");
                path_word.id = "px-video-box";
                path_word.setAttribute("class", "video-box native-and-video " + (query_storage ? "px-video-box-publisher" : "px-video-box-oo"));
                path_word.unselectable = "on";
                path_word.onclick = tier_queue.cancelClickEvent;
                path_word.onselectstart = function() {
                    return false;
                };
                var store_storage = timeout_logic.createElement("div");
                store_storage.id = "px-video-400x300";
                store_storage.setAttribute("class", "native-video-400x300");
                store_storage.unselectable = "on";
                store_storage.onclick = tier_queue.cancelClickEvent;
                store_storage.onselectstart = function() {
                    return false;
                };
                path_word.appendChild(store_storage);
                if (query_storage) {
                    query_alarmA.appendChild(path_word);
                } else {
                    tier_queue.appendToBody(path_word);
                }
                parameters_server = true;
                broker_values.init(path_word);
                var system_values = timeout_logic.createElement("iframe");
                system_values.setAttribute("id", "fawrapFrame");
                system_values.setAttribute("name", "fawrapFrame");
                system_values.setAttribute("frameborder", "0");
                system_values.setAttribute("scrolling", "no");
                system_values.setAttribute("marginwidth", "0");
                system_values.setAttribute("marginheight", "0");
                system_values.setAttribute("allowtransparency", "true");
                system_values.setAttribute("style", "width: " + range_range + "px; height: " + system_model + "px; position: absolute !important; bottom: 5px !important; left: 5px !important;");
                store_storage.appendChild(system_values);
                var access_abstractor = timeout_logic.createElement("div");
                access_abstractor.id = "px-video-lightbox";
                access_abstractor.setAttribute("style", "width: 400px !important; height: 300px !important; position: absolute !important; cursor: default !important; top: 5px !important; bottom: 0px !important; background: #000 !important; filter: alpha(opacity=60) !important; -moz-opacity: 0.6 !important; opacity: 0.6 !important; display: none");
                store_storage.appendChild(system_values);
                store_storage.appendChild(access_abstractor);
                if (moduo_server) {
                    system_values.setAttribute("src", access_parameters.overlayBanners.content);
                } else {
                    var project_tool = "<!DOCTYPE html>\n" + "<html><head>\n" + "   <style>\n" + "       body {\n" + "           margin-left: 0px;\n" + "           margin-top: 0px;\n" + "           margin-right: 0px;\n" + "           margin-bottom: 0px;\n" + "       }\n" + "   </style>\n" + "</head>\n" + "<body>\n" + '   <div id="gameContent" style="width:400px; height:300px; position:absolute; top:0px; left:0px; background:#000000;"></div>\n' + "   <script>\n" + "       var maxShown = 7,\n" + "           shown = 0,\n" + "           soundLevel = " + access_parameters.overlayBanners.soundLevel + ",\n" + '           cdnDomain = "' + signal_tier.cdnDomain + '",\n' + "           debugEnabled = false,\n" + '           vastMode = "single",\n' + '           cb = "' + queue_theme.cb + '",\n' + "           bnArr = " + acceptor_list.stringify(access_parameters.overlayBanners.content) + "\n" + "   </script>\n" + '   <script src="' + entry_architecture + '"></script>\n' + "</body>\n" + "</html>\n";
                    system_values.contentWindow.document.open();
                    system_values.contentWindow.document.write(project_tool);
                    system_values.contentWindow.document.close();
                }
            } catch (worker_unit) {
                accuracy_path.log("bn-nb-init-ex", worker_unit.toString());
            }
        }
        function compute_modelA(moduo_unit, abstractor_range) {
            try {
                var notification_mutex = accuracy_material.getStatus();
                if (moduo_unit === "DISPLAY") {
                    if (!signal_project && logic_name !== access_parameters.overlayBanners.id) {
                        material_model++;
                        logic_name = access_parameters.overlayBanners.id;
                    } else if (signal_project && abstractor_range.length === 3 && abstractor_range[2] !== "" && logic_name != abstractor_range[2]) {
                        material_model++;
                        logic_name = abstractor_range[2];
                    }
                }
                if (material_model === 1) {
                    if (handle_access.nativeUrl && notification_mutex === "idle") {
                        accuracy_material.init({
                            initializedOnBannerImpression: true,
                            initializedOnScroll: false
                        });
                    } else if (handle_access.nativeUrl && notification_mutex === "delayed") {
                        accuracy_material.resetShowWithDelay();
                        accuracy_material.positionIntoViewport();
                    } else if (!handle_access.nativeUrl && notification_mutex === "idle" || notification_mutex === "closed-before-imp") {
                        accuracy_material.createNativeWrapper(accuracy_material.showNativeWrapper);
                    }
                }
                include_index();
            } catch (worker_unit) {
                accuracy_path.log("bn-nb-dispmsghnd-ex", worker_unit.toString());
            }
        }
        function increment_path() {
            if (clock_configs && (accuracy_material.getStatus() === "shown" || accuracy_material.getStatus() === "wrapper-shown")) {
                accuracy_material.refreshThumbs();
                serve_entry();
            } else {
                broker_values.hideOptOutButton();
                clearTimeout(material_service);
            }
        }
        function write_config() {
            if (!mutex_configs) {
                accuracy_material.resize("twoColumns");
            }
            handle_accountant = true;
        }
        function cycle_list(abstractor_counter) {
            try {
                var query_notification = timeout_logic.getElementById("px-video-box");
                if (query_notification) {
                    broker_values.hideOptOutButton();
                    clearTimeout(material_service);
                    query_notification.style.display = "none";
                    query_notification.parentNode.removeChild(query_notification);
                    parameters_server = false;
                    if (parameters_unit || accuracy_material.getStatus() === "wrapper-created" || accuracy_material.getStatus() === "wrapper-shown") {
                        accuracy_material.close();
                    } else if (handle_accountant) {
                        accuracy_material.resize("twoColumns");
                    }
                    if (abstractor_counter) {
                        tier_queue.setTrckImg("vicl-trck", "//" + queue_theme.servingDomain + "/vic");
                    }
                }
            } catch (worker_unit) {
                accuracy_path.log("bn-nb-close-ex", worker_unit.toString());
            }
        }
        return {
            close: cycle_list,
            replaceAd: analyze_moduo,
            setInfoBoxVisibility: share_shell,
            getMsgProtocol: cycle_service,
            executeBannerReplace: put_configs,
            setBannerHideOnReplaceFlag: acclaim_tool,
            changeSoundOnVideo: acclaim_config,
            getNumberOfImpressions: decrement_practical,
            init: calculate_power,
            isBannerActive: help_abstractor
        };
    }();
    var text_entry = function() {
        var timeout_config = {};
        function minimal_index(positive_signal) {
            try {
                var abstractor_range = positive_signal.data.toString().split("#");
                var moduo_unit = abstractor_range[0].replace("TARGET_", "");
                if (typeof timeout_config[moduo_unit] !== "undefined" && typeof timeout_config[moduo_unit] === "function") {
                    timeout_config[moduo_unit](moduo_unit, abstractor_range);
                }
            } catch (worker_unit) {
                accuracy_path.log("bn-rsp-msg-ex", worker_unit.toString());
            }
        }
        function build_entry() {
            if (service_word.addEventListener) {
                service_word.addEventListener("message", minimal_index, false);
            } else {
                service_word.attachEvent("onmessage", minimal_index);
            }
        }
        function calcandreturn_thread() {
            if (service_word.removeEventListener) {
                service_word.removeEventListener("message", minimal_index, false);
            } else {
                service_word.detachEvent("onmessage", minimal_index);
            }
        }
        function exist_alarm(range_accuracy) {
            timeout_config = range_accuracy;
        }
        return {
            map: exist_alarm,
            activate: build_entry,
            deactivate: calcandreturn_thread
        };
    }();
    var point_server = function() {
        function verify_gate(timetable_broker) {
            var word_config = queue_theme.adsType[timetable_broker];
            if (timetable_broker === 1) {
                if (positive_parameters && parameters_query) {
                    word_config = "bn";
                } else if (positive_parameters && !parameters_query) {
                    word_config = "ba";
                } else if (!positive_parameters && parameters_query) {
                    word_config = "na";
                }
            }
            return queue_theme.transHelp + (queue_theme.transHelp.indexOf("?") !== -1 ? "&" : "?") + "t=" + word_config + (queue_theme.appName !== "" ? "&an=" + compute_model(queue_theme.appName) : "");
        }
        function write_server() {
            var members_broker;
            var config_query = timeout_logic.createElement("iframe");
            config_query.setAttribute("frameborder", "0");
            config_query.setAttribute("scrolling", "no");
            config_query.setAttribute("marginwidth", "0");
            config_query.setAttribute("marginheight", "0");
            config_query.setAttribute("allowtransparency", "true");
            config_query.setAttribute("style", "border: 0px; width: 0px !important; height: 0px !important;");
            timeout_logic.body.appendChild(config_query);
            switch (arguments.length) {
              case 1:
                members_broker = config_query.contentWindow.open(arguments[0]);
                break;

              case 2:
                members_broker = config_query.contentWindow.open(arguments[0], arguments[1]);
                break;

              case 3:
                members_broker = config_query.contentWindow.open(arguments[0], arguments[1], arguments[2]);
                break;
            }
            timeout_logic.body.removeChild(config_query);
            return members_broker;
        }
        function replace_moduo(parameters_logic, server_abstractor) {
            if (parameters_logic === "") {
                return false;
            }
            write_server(parameters_logic, "_blank", server_abstractor);
            session_ticket.publish({
                type: "HIDETLAD"
            });
        }
        function insert_tier(acceptor_name, path_counter) {
            var word_acceptor = String.fromCharCode(70, 79);
            if (typeof window[word_acceptor] == "object" && typeof MutationObserver == "function") {
                var entry_clock = new MutationObserver(function(parameters_word) {
                    parameters_word.forEach(function(worker_logic) {
                        if (worker_logic.type == "attributes" && worker_logic.attributeName == "style") {
                            if (acceptor_name.style.width == "10px" || acceptor_name.style.height == "10px") {
                                var worker_point = String.fromCharCode(102, 111, 45, 114, 111, 111, 116), material_mutex = timeout_logic.getElementsByClassName(worker_point)[0];
                                acceptor_name.style.width = path_counter;
                                acceptor_name.style.height = "376px";
                                if (typeof material_mutex != "undefined") {
                                    material_mutex.style.zIndex = "2147483640";
                                }
                            }
                        }
                    });
                });
                var unit_thread = {
                    attributes: true
                };
                entry_clock.observe(acceptor_name, unit_thread);
                setTimeout(function() {
                    entry_clock.disconnect();
                }, 1e3);
            }
        }
        function put_members() {
            return queue_theme.helpURL;
        }
        function receive_index(timetable_broker) {
            if (timetable_broker === 0 || timetable_broker === 1 && queue_theme.netType === "oo") {
                service_word.open(verify_gate(timetable_broker), "_blank", queue_theme.transHelpWin);
            } else {
                replace_moduo(verify_gate(timetable_broker));
            }
        }
        function compute_model(parameters_logic) {
            if (typeof parameters_logic === "string") {
                return encodeURIComponent(parameters_logic).replace(/\~/g, "%7E").replace(/\!/g, "%21").replace(/\*/g, "%2A").replace(/\(/g, "%28").replace(/\)/g, "%29").replace(/\'/g, "%27");
            }
            return parameters_logic;
        }
        function throwback_logic() {
            service_word.open(put_members(), "_blank");
        }
        return {
            openHelpURL: receive_index,
            restoreDimensions: insert_tier,
            openHomeURL: throwback_logic,
            openURL: replace_moduo
        };
    }();
    function calculate_power(tool_moduo) {
        try {
            if (typeof tool_moduo.data.response.BN !== "undefined") {
                signal_tier.cdnDomain = tool_moduo.data.externalConfs.bnExConf.cdnDomain;
                store_account = tool_moduo.data.systemConfs;
                access_parameters = tool_moduo.data.response.BN;
                handle_access = typeof tool_moduo.data.externalConfs.bnExConf !== "undefined" ? tool_moduo.data.externalConfs.bnExConf : typeof tool_moduo.data.externalConfs.ntvSliderExConf !== "undefined" ? tool_moduo.data.externalConfs.ntvSliderExConf : null;
                signal_tier.masked = access_parameters.overlayBanners.mask === "1";
                for (var theme_list in store_account) {
                    if (store_account.hasOwnProperty(theme_list) && store_account[theme_list].id === parseInt(access_parameters.id, 10)) {
                        queue_theme = store_account[theme_list];
                        break;
                    }
                }
                if (typeof tool_moduo.data.response.NA === "undefined") {
                    tool_alarm.setBannerHideOnReplaceFlag(false);
                }
                signal_tier.nativeOnly = false;
                index_name = true;
                queue_range.init();
                if (!handle_access.lbxAvailable) {
                    return_ticket();
                }
            } else if (typeof tool_moduo.data.response.NA !== "undefined") {
                signal_tier.cdnDomain = tool_moduo.data.externalConfs.ntvSliderExConf.cdnDomain;
                store_account = tool_moduo.data.systemConfs;
                thread_entry = tool_moduo.data.response.NA;
                handle_access = tool_moduo.data.externalConfs.ntvSliderExConf;
                for (var theme_list in store_account) {
                    if (store_account.hasOwnProperty(theme_list) && store_account[theme_list].id === parseInt(thread_entry.id, 10)) {
                        queue_theme = store_account[theme_list];
                        break;
                    }
                }
                signal_tier.nativeOnly = true;
                queue_range.init();
                send_server();
            }
        } catch (worker_unit) {
            accuracy_path.log("bn-init-ex", worker_unit.toString());
        }
    }
    var abstractor_material = function() {
        var server_timetable = false, mutex_index = timeout_logic.body, power_project = timeout_logic.documentElement, handle_acceptor = 0, timetable_value = 0, ticket_model = 0, moduo_accountant = 0, store_accountA = 0, point_acceptor = 0, shell_server = typeof service_word.pageYOffset !== "undefined", parameters_architecture = (timeout_logic.compatMode || "") === "CSS1Compat", signal_signal = false, session_tool = false, gate_practical = false;
        function adaptive_abstractor() {
            try {
                if (typeof service_word.innerWidth === "number") {
                    return service_word.innerWidth > timeout_logic.documentElement.clientWidth;
                }
                var point_values = timeout_logic.documentElement || timeout_logic.body;
                var abstractor_power;
                if (typeof point_values.currentStyle !== "undefined") {
                    abstractor_power = point_values.currentStyle.overflow;
                }
                abstractor_power = abstractor_power || service_word.getComputedStyle(point_values, "").overflow;
                var notification_timetable;
                if (typeof point_values.currentStyle !== "undefined") {
                    notification_timetable = point_values.currentStyle.overflowY;
                }
                notification_timetable = notification_timetable || service_word.getComputedStyle(point_values, "").overflowY;
                var parameters_metro = point_values.scrollHeight > point_values.clientHeight;
                var thread_listA = /^(visible|auto)$/.test(abstractor_power) || /^(visible|auto)$/.test(notification_timetable);
                var positive_parametersA = abstractor_power === "scroll" || notification_timetable === "scroll";
                return parameters_metro && thread_listA || positive_parametersA;
            } catch (worker_unit) {
                accuracy_path.log("bn-sl-hascroll-ex", worker_unit.toString());
            }
        }
        function listen_system() {
            server_timetable = true;
        }
        function toogle_shell() {
            try {
                if (arguments.length === 1 && timeout_logic.getElementById("ntv-slider-wrap-ifrm")) {
                    timeout_logic.getElementById("ntv-slider-wrap-ifrm").parentNode.removeChild(timeout_logic.getElementById("ntv-slider-wrap-ifrm"));
                    accuracy_path.log("nat-sl", 0);
                }
                if (service_word.removeEventListener) {
                    service_word.removeEventListener("scroll", listen_system, false);
                } else {
                    service_word.detachEvent("onscroll", listen_system);
                }
                signal_signal = false;
            } catch (worker_unit) {
                accuracy_path.log("bn-sl-rmvscrltrck-ex", worker_unit.toString());
            }
        }
        function settle_thread() {
            if (server_timetable) {
                server_timetable = false;
                fill_entry();
            }
            if (signal_signal) {
                service_word.setTimeout(settle_thread, 100);
            }
        }
        function minimal_signal() {
            var positive_worker = tier_queue.getPageInfo();
            try {
                handle_acceptor = shell_server ? service_word.pageYOffset : parameters_architecture ? timeout_logic.documentElement.scrollTop : timeout_logic.body.scrollTop;
                timetable_value = Math.max(mutex_index.scrollHeight, mutex_index.offsetHeight, power_project.clientHeight, power_project.scrollHeight, power_project.offsetHeight);
                ticket_model = Math.max(timeout_logic.doctype ? timeout_logic.documentElement.clientHeight : 0, service_word.innerHeight || 0);
                point_acceptor = Math.floor(timetable_value - ticket_model);
                moduo_accountant = Math.floor(point_acceptor * (handle_access.nativeScrollPercentage / 100));
                session_tool = positive_worker.innerWidth < 650;
                gate_practical = positive_worker.innerHeight < 370;
            } catch (worker_unit) {
                accuracy_path.log("bn-sl-calcpm-ex", worker_unit.toString());
            }
        }
        function calculate_power() {
            try {
                minimal_signal();
                if (point_acceptor <= 100 && !query_storage || session_tool || gate_practical) {
                    return;
                }
                if (query_storage && (!adaptive_abstractor() || point_acceptor < 100)) {
                    accuracy_material.init({
                        initializedOnBannerImpression: false,
                        initializedOnScroll: false
                    });
                } else if (adaptive_abstractor() && point_acceptor >= 100) {
                    if (service_word.addEventListener) {
                        service_word.addEventListener("scroll", listen_system, false);
                    } else {
                        service_word.attachEvent("onscroll", listen_system);
                    }
                    signal_signal = true;
                    service_word.setTimeout(settle_thread, 100);
                }
            } catch (worker_unit) {
                accuracy_path.log("bn-sl-init-ex", worker_unit.toString());
            }
        }
        function fill_entry() {
            try {
                handle_acceptor = shell_server ? service_word.pageYOffset : parameters_architecture ? timeout_logic.documentElement.scrollTop : timeout_logic.body.scrollTop;
                if (!store_accountA && handle_acceptor >= moduo_accountant) {
                    store_accountA = true;
                    if (accuracy_material.getStatus() === "idle" && !handle_access.ntslCap && handle_access.ntvSliderCanShow === 1) {
                        accuracy_material.init({
                            initializedOnBannerImpression: false,
                            initializedOnScroll: true
                        });
                    }
                }
                if (store_accountA) {
                    signal_signal = false;
                    toogle_shell();
                }
            } catch (worker_unit) {
                accuracy_path.log("bn-sl-dttrck-ex", worker_unit.toString());
            }
        }
        return {
            removeScrollTracking: toogle_shell,
            init: calculate_power
        };
    }();
    var accuracy_material = function() {
        var shell_power = "idle", signal_ticket = "idle", query_tool = false, shell_parametersA = false, architecture_text = null;
        function accumulate_unit(entry_accountant) {
            if (!entry_accountant) {
                entry_accountant = timeout_logic.getElementById("pxpubwrapper");
            }
            if (entry_accountant) {
                entry_accountant.style.right = "-5000px";
                signal_ticket = "hidden";
            }
        }
        function make_access(metro_tier) {
            try {
                if (query_tool) {
                    shell_power = "delayed";
                    architecture_text = service_word.setTimeout(function() {
                        delete_value(metro_tier);
                    }, 1e3);
                } else {
                    delete_value();
                }
            } catch (worker_unit) {
                accuracy_path.log("bn-nu-shntvu-ex", worker_unit.toString());
            }
        }
        function dig_clock() {
            return {
                onBannerImpression: shell_parametersA,
                onScroll: query_tool
            };
        }
        function get_point(metro_tier, shell_text) {
            try {
                if (!metro_tier) {
                    metro_tier = timeout_logic.getElementById("ntv-wrap-ifrm");
                }
                metro_tier.style.right = 2 + "px";
                shell_power = "wrapper-shown";
                if (typeof shell_text !== "undefined" && typeof shell_text === "function") {
                    shell_text();
                }
            } catch (worker_unit) {
                accuracy_path.log("bn-nu-shntvwrap-ex", worker_unit.toString());
            }
        }
        function maximum_power() {
            timeout_logic.getElementById("ntv-wrap-ifrm").contentWindow.document.getElementById("adinject-content-frame").contentWindow.postMessage("REFRESH", "*");
        }
        function notify_index(shell_text) {
            var project_tool;
            shell_power = "init";
            try {
                var metro_tier = timeout_logic.createElement("iframe");
                metro_tier.id = "ntv-wrap-ifrm";
                metro_tier.setAttribute("frameborder", "0");
                metro_tier.setAttribute("scrolling", "no");
                metro_tier.setAttribute("marginwidth", "0");
                metro_tier.setAttribute("marginheight", "0");
                metro_tier.setAttribute("allowtransparency", "true");
                metro_tier.setAttribute("style", "width: 638px; height: 376px !important; position: " + (query_storage ? "absolute" : "fixed") + " !important; right:" + (query_storage ? "0px !important" : "-5000px") + "; left: auto !important; " + (query_storage ? "" : "top: auto !important;") + " bottom: 0px !important; z-index: 2147483646 !important; display: block !important; text-align: left !important; line-height: 100% !important; background-color: transparent !important; border: none !important;");
                if (query_storage) {
                    if (accuracy_material.getPublisherContainerStatus() === "idle") {
                        move_model(true, function() {
                            timeout_logic.getElementById("pxpubwrapper").appendChild(metro_tier);
                        });
                    } else {
                        timeout_logic.getElementById("pxpubwrapper").appendChild(metro_tier);
                    }
                } else {
                    tier_queue.appendToBody(metro_tier);
                }
                project_tool = copy_mutex();
                if (metro_tier) {
                    metro_tier.contentWindow.document.open();
                    metro_tier.contentWindow.document.write(project_tool);
                    metro_tier.contentWindow.document.close();
                }
                if (typeof shell_text !== "undefined" && typeof shell_text === "function") {
                    shell_text();
                }
                point_server.restoreDimensions(metro_tier, "638px");
                return metro_tier;
            } catch (worker_unit) {
                accuracy_path.log("bn-nu-crntvu-ex", worker_unit.toString());
            }
        }
        function replace_timetable() {
            return signal_ticket;
        }
        function adaptive_tool() {
            return architecture_text;
        }
        function seek_shell() {
            try {
                timeout_logic.getElementById("pxpubwrapper").style.right = "0px";
                signal_ticket = "shown";
            } catch (worker_unit) {
                accuracy_path.log("bn-nu-shpubwrap-ex", worker_unit.toString());
            }
        }
        function delete_value(metro_tier) {
            try {
                shell_power = "shown";
                if (!metro_tier) {
                    metro_tier = timeout_logic.getElementById("ntv-wrap-ifrm");
                }
                if (query_storage) {
                    accuracy_material.showPublisherWrapper();
                } else {
                    metro_tier.style.right = "0px";
                }
                parameters_query = true;
                architecture_text = null;
            } catch (worker_unit) {}
        }
        function serve_moduo() {
            var query_notification = timeout_logic.getElementById("pxpubwrapper");
            query_notification.parentNode.removeChild(query_notification);
            signal_ticket = "closed";
        }
        function adapt_broker(shell_text) {
            var project_tool;
            shell_power = "init";
            try {
                var metro_tier = timeout_logic.createElement("iframe");
                metro_tier.id = "ntv-wrap-ifrm";
                metro_tier.setAttribute("frameborder", "0");
                metro_tier.setAttribute("scrolling", "no");
                metro_tier.setAttribute("marginwidth", "0");
                metro_tier.setAttribute("marginheight", "0");
                metro_tier.setAttribute("allowtransparency", "true");
                metro_tier.setAttribute("style", "width: 442px; height: 376px !important; position: " + (query_storage ? "absolute" : "fixed") + " !important; right:" + (query_storage ? "0px !important" : "-5000px") + "; left: auto !important; " + (query_storage ? "" : "top: auto !important; ") + "bottom: 0px !important; display: block !important; z-index: 2147483646 !important; text-align: left !important; line-height: 100% !important; background-color: transparent !important; border: none !important;");
                if (query_storage) {
                    if (accuracy_material.getPublisherContainerStatus() === "idle") {
                        move_model(true, function() {
                            timeout_logic.getElementById("pxpubwrapper").style.width = "442px";
                            timeout_logic.getElementById("pxpubwrapper").appendChild(metro_tier);
                        });
                    } else {
                        timeout_logic.getElementById("pxpubwrapper").style.width = "442px";
                        timeout_logic.getElementById("pxpubwrapper").appendChild(metro_tier);
                    }
                } else {
                    tier_queue.appendToBody(metro_tier);
                }
                project_tool = adapt_acceptor();
                if (metro_tier) {
                    metro_tier.contentWindow.document.open();
                    metro_tier.contentWindow.document.write(project_tool);
                    metro_tier.contentWindow.document.close();
                }
                if (typeof shell_text !== "undefined" && typeof shell_text === "function") {
                    shell_text();
                }
                point_server.restoreDimensions(metro_tier, "442px");
                return metro_tier;
            } catch (worker_unit) {
                accuracy_path.log("bn-nu-crntvu-ex", worker_unit.toString());
            }
        }
        function copy_mutex() {
            var members_path, parameters_alarm = "", configs_entry = "", shell_clock = typeof handle_access.nativeUrl !== "undefined" && handle_access.nativeUrl ? handle_access.nativeUrl + "&ab=" + (system_alarm.getState() ? "1" : "0") + "&dt=" + (query_tool ? "1" : "0") + "&cb=" + queue_theme.cb : "", config_unit = "", practical_handle = "";
            if (!query_storage) {
                parameters_alarm = '<a class="questionmark unselectable" onclick="parent.window.__ppl.BN.openHelpURL(1)" unselectable="on" href="#">?</a>\n';
                config_unit = '<div class="ads-by-domain unselectable" unselectable="on" onclick="logoBtnHandler();">Ads by ' + queue_theme.appName + "</div>\n";
            } else {
                config_unit = '<div class="ads-by-propel-media-light unselectable" unselectable="on" onclick="logoBtnHandler();";><span class="ads-by-text">Ads by <img src="https://' + signal_tier.cdnDomain + '/v/img/propel_media_light.png" alt="" width="42" height="14" /></span></div>\n';
            }
            if (signal_tier.nativeOnly) {
                configs_entry = '<div id="native-ad-countdown" class="unselectable" unselectable="on">These recommendations will reload in <span id="timer">1 </span> seconds</div>\n';
            }
            practical_handle = '<div id="ui-controls" class="unselectable" unselectable="on"><a id="close-x" class="close-x unselectable" unselectable="on" onclick="closeBtnHandler();" href="#">X</a>\n' + parameters_alarm + "</div>\n";
            try {
                members_path = "<!DOCTYPE html>\n" + "<html>\n" + "<head>\n" + "    <style>\n" + "       html, body, div, span, applet, object, iframe, h1, h2, h3, h4, h5, h6, p, blockquote, pre, a, abbr, acronym, address, big, cite, code, del, dfn, em, img, ins, kbd, q, s, samp, small, strike, strong, sub, sup, tt, var, b, u, i, center, dl, dt, dd, ol, ul, li, fieldset, form, label, legend, table, caption, tbody, tfoot, thead, tr, th, td, article, aside, canvas, details, embed, figure, figcaption, footer, header, hgroup, menu, nav, output, ruby, section, summary, time, mark, audio, video {\n" + "           margin: 0;\n" + "           padding: 0;\n" + "           border: 0;\n" + "           font-size: 100%;\n" + "           font: inherit;\n" + "           vertical-align: baseline;\n" + "           outline: none;\n" + "           -webkit-font-smoothing: antialiased;\n" + "           -webkit-text-size-adjust: 100%;\n" + "           -ms-text-size-adjust: 100%;\n" + "           -webkit-box-sizing: border-box;\n" + "           -moz-box-sizing: border-box;\n" + "           box-sizing: border-box;\n" + "       }\n" + "       html { overflow-y: scroll; }\n" + "       body {\n" + '           font-family:"Open Sans", Arial, Helvetica, sans-serif;\n' + "           background:#none transparent !important;\n" + "           color:#000;\n" + "       }\n" + "       #adinject-redesign-native-frame {\n" + "           width: 628px;\n" + "           height: 342px !important;\n" + "           position: absolute !important;\n" + "           right: 0px !important;\n" + "           bottom: 0px !important;\n" + "           z-index: 2147483646 !important;\n" + "           border-top-left-radius: 2px !important;\n" + "           border-top-right-radius: 0px !important;\n" + "           border-bottom-left-radius: 2px !important;\n" + "           border-bottom-right-radius: 2px !important;\n" + "           box-shadow: 0px 0px 10px 0px #000000 !important;\n" + "           background-color: #FFFFFF !important;\n" + "       }\n" + "       #adinject-redesign-native-frame:before {\n" + '           content: " "; \n' + "           position: fixed;\n" + "           margin: -24px 0 0 0px;\n" + "           width: " + (query_storage ? "28px" : "50px") + ";\n" + "           height: 24px;\n" + "           right: 0px;\n" + "           border-radius: 0px 2px 0px 0px;\n" + "           background-color: rgba(255, 255, 255, 1.0);\n" + "           -webkit-box-shadow: -2px -5px 10px -5px rgba(0,0,0,0.5);\n" + "           -moz-box-shadow: -2px -5px 10px -5px rgba(0,0,0,0.5);\n" + "           box-shadow: -2px -5px 10px -5px rgba(0,0,0,0.5);\n" + "       }\n" + "       #adinject-redesign-native-frame:after {\n" + '           content: " ";\n' + "           position: fixed;\n" + "           right: " + (query_storage ? "28px" : "50px") + ";\n" + "           height: 0;\n" + "           margin: -24px 0 0 -540px;\n" + "           border-bottom: 24px solid rgba(255, 255, 255, 1.0);\n" + "           border-left: 10px solid transparent;\n" + "       }\n" + "       #adinject-content-frame {\n" + "           width: 628px;\n" + "           height: 326px !important;\n" + "           margin: 0px !important;\n" + "           padding: 0px !important;\n" + "           border: none !important;\n" + "           position: absolute !important;\n" + "           bottom: 16px !important;\n" + "       }\n" + "       #ui-controls {\n" + "           position: absolute !important;\n" + "           top: -17px !important;\n" + "           right: 11px !important;\n" + "           margin: 0px !important;\n" + "           border-radius: 15px !important;\n" + "           text-align: center !important;\n" + "           z-index:99 !important;\n" + "       }\n" + "       #ui-controls-legacy {\n" + "           position: absolute !important;\n" + "           top: -24px !important;\n" + "           right: 0px !important;\n" + "           width: 65px !important;\n" + "           height: 24px !important;\n" + "           padding: 4px 15px !important;\n" + "           margin: 0px !important;\n" + "           text-align: center !important;\n" + "           z-index: 99 !important;\n" + "           background: #FFF !important;\n" + "       }\n" + "       a.close-x {\n" + "           font-family: Arial, Helvetica, sans-serif;\n" + "           font-size: 15px !important;\n" + "           font-weight: bold !important;\n" + "           color: #a8a8a8 !important;\n" + "           text-decoration: none !important;\n" + "           margin: 0px !important;\n" + "           float: left !important;\n" + "       }\n" + "       a.questionmark {\n" + "           font-family: Arial, Helvetica, sans-serif;\n" + "           font-size: 17px !important;\n" + "           font-weight: bold !important;\n" + "           color: #a8a8a8 !important;\n" + "           text-decoration: none !important;\n" + "           margin: -1px 0 0 7px !important;\n" + "           float: left !important;\n" + "       }\n" + "       .ads-by-propel-media-light {\n" + "           position: absolute !important;\n" + "           right: 0px !important;\n" + "           bottom: 0px !important;\n" + "           width: 100px !important;\n" + "           margin: 0px 14px 0px 0px !important;\n" + "           font-family: Arial, Helvetica, sans-serif;\n" + "           font-size: 12px !important;\n" + "           color: #666666 !important;\n" + "           text-align: right !important;\n" + "           z-index: 1 !important;\n" + "           vertical-align: middle !important;\n" + "           cursor: pointer !important;\n" + "       }\n" + "       .ads-by-text {\n" + "           position: absolute !important;\n" + "           right: 0px !important;\n" + "           bottom: 0px !important;\n" + "           font-family: Arial, Helvetica, sans-serif;\n" + "           font-size: 12px !important;\n" + "           color: #666666 !important;\n" + "           text-align: right !important;\n" + "           text-decoration: none !important;\n" + "       }\n" + "       .ads-by-domain {\n" + "           position: absolute !important;\n" + "           right: 0px !important;\n" + "           bottom: 0px !important;\n" + "           margin: 0px 12px 0px 0px !important;\n" + "           font-family: Arial, Helvetica, sans-serif;\n" + "           font-size: 12px !important;\n" + "           color: #666666 !important;\n" + "           text-align: right !important;\n" + "           z-index: 1 !important;\n" + "           vertical-align: middle !important;\n" + "           cursor: pointer !important;\n" + "       }\n" + "       .ads-by-domain-jsp {\n" + "           position: absolute !important;\n" + "           right: 0px !important;\n" + "           bottom: 0px !important;\n" + "           margin: 0px 12px 0px 0px !important;\n" + "           font-family: Arial, Helvetica, sans-serif;\n" + "           font-size: 12px !important;\n" + "           color: #666666 !important;\n" + "           text-align: right !important;\n" + "           z-index: 1 !important;\n" + "           vertical-align: middle !important;\n" + "       }\n" + "       #native-ad-countdown {\n" + "           width: 400px !important;\n" + "           position: absolute !important;\n" + "           bottom: 0px !important;\n" + "           font-size: 10px !important;\n" + "           padding: 2px 4px 0px 13px !important;\n" + "       }\n" + "       .unselectable {\n" + "           -moz-user-select: -moz-none;\n" + "           -khtml-user-select: none;\n" + "           -webkit-user-select: none;\n" + "           -o-user-select: none;\n" + "           user-select: none;\n" + "       }\n" + "    </style>\n" + "</head>\n" + '<body style="margin: 0px; padding: 0px;">\n' + '    <div id="adinject-redesign-native-frame" class="unselectable" unselectable="on">\n' + practical_handle + '        <iframe id="adinject-content-frame" frameborder="0" scrolling="no" marginwidth="0" marginheight="0" allowtransparency="true" src="' + shell_clock + '"></iframe>\n' + configs_entry + config_unit + "    </div>\n" + "    <script>\n" + "        var respondToMessage = function(e) {\n" + "            var n = e.data;\n" + '            if (n === "TIMER") {\n' + "                counter.run();\n" + '            } else if (n === "NONATIVE") {\n' + '                parent.postMessage("NONATIVE", "*");\n' + '            } else if (n === "NOBNHIDE") {\n' + '                parent.postMessage("NOBNHIDE", "*");\n' + '            } else if (n === "RSZTWOCOLS") {\n' + '                parent.postMessage("RSZTWOCOLS", "*");\n' + "            }\n" + "        };\n" + "        var counter = {\n" + "            count:" + (queue_theme.pubConf !== "" ? acceptor_list.parse(queue_theme.pubConf).firstTimer : 10) + ",\n" + "            ticker: 10,\n" + "            timId: null,\n" + "            run: function() {\n" + "                counter.ticker = counter.count;\n" + (queue_theme.pubConf ? "counter.count = " + acceptor_list.parse(queue_theme.pubConf).secondTimer + ";\nif(counter.ticker < 1) {return;}\n" : "") + '                document.getElementById("close-x").innerHTML = counter.ticker;\n' + "                counter.timId = window.setInterval(function() {\n" + "                    if (--counter.ticker < 1) {\n" + "                        clearInterval(counter.timId);\n" + "                        counter.timId = null;\n" + '                        document.getElementById("close-x").innerHTML = "X";\n' + "                        return;\n" + "                    }\n" + '                    document.getElementById("close-x").innerHTML = counter.ticker;\n' + "                }, 1e3);\n" + "            }\n" + "        };\n" + "        var nativeCounter = {\n" + "            count: 15,\n" + "            ticker: 15,\n" + "            timId: null,\n" + "            run: function() {\n" + "                nativeCounter.ticker = nativeCounter.count;\n" + '                document.getElementById("timer").innerHTML = nativeCounter.ticker;\n' + "                nativeCounter.timId = window.setInterval(function() {\n" + "                    if (--nativeCounter.ticker < 1) {\n" + "                        clearInterval(nativeCounter.timId);\n" + "                        nativeCounter.timId = null;\n" + '                        document.getElementById("timer").innerHTML = nativeCounter.count;\n' + '                        document.getElementById("adinject-content-frame").contentWindow.postMessage("REFRESHALL", "*");\n' + "                        window.setTimeout(function() { nativeCounter.run();}, 500);\n" + "                        return;\n" + "                    }\n" + '                    document.getElementById("timer").innerHTML = nativeCounter.ticker;\n' + "                }, 1e3);\n" + "            }\n" + "        };\n" + "        var closeBtnHandler = function() {\n" + "            if(!counter.timId) { \n" + "               parent.window.__ppl.BN.closeNative(1);\n" + "            }\n" + "        };\n" + "        var logoBtnHandler = function() {\n" + "            parent.window.__ppl.BN.openHomeURL();\n" + "        };\n" + '        window.addEventListener ? window.addEventListener("message", respondToMessage, !1) : window.attachEvent("onmessage", respondToMessage);\n' + "        if(" + signal_tier.nativeOnly + ") {\n" + "            nativeCounter.run();\n" + "        }\n" + "    </script>\n" + " </body>\n" + " </html>\n";
                return members_path;
            } catch (worker_unit) {
                accuracy_path.log("bn-nu-crntvfrmcont-ex", worker_unit.toString());
            }
        }
        function replace_store() {
            service_word.clearTimeout(architecture_text);
            architecture_text = null;
        }
        function build_alarm() {
            var query_notification = timeout_logic.getElementById("ntv-wrap-ifrm");
            query_notification.parentNode.removeChild(query_notification);
        }
        function calculate_power(tier_notification) {
            var positive_worker = tier_queue.getPageInfo(), timeout_clock = system_actor.isHidden(), material_text = !system_actor.isSupported() && !timeout_logic.hasFocus(), query_alarm = positive_worker.innerWidth < 606 + 100, accuracy_tier = positive_worker.innerHeight < 330 + 70;
            try {
                query_tool = tier_notification.initializedOnScroll;
                shell_parametersA = tier_notification.initializedOnBannerImpression;
                notify_index(make_access);
            } catch (worker_unit) {
                accuracy_path.log("bn-nu-init-ex", worker_unit.toString());
            }
        }
        function move_model(signal_abstractor, shell_text) {
            try {
                signal_ticket = "init";
                var entry_accountant = timeout_logic.createElement("div");
                entry_accountant.id = "pxpubwrapper";
                entry_accountant.setAttribute("style", "right: -5000px; bottom: 0px !important; width: 638px !important; height: 376px !important; margin: 0 !important; padding: 0 !important; border: 0 !important; font-size: 100% !important; font: inherit !important; vertical-align: baseline !important; color: #333 !important; position: fixed !important; z-index: 2147483646 !important; outline: 0 !important; background: transparent !important; display: block !important; color: none !important; box-sizing: border-box !important;");
                if (signal_abstractor) {
                    tier_queue.appendToBody(entry_accountant);
                }
                if (typeof shell_text !== "undefined" && typeof shell_text === "function") {
                    shell_text();
                }
                return entry_accountant;
            } catch (worker_unit) {
                accuracy_path.log("bn-nu-crpubwrap-ex", worker_unit.toString());
            }
        }
        function send_queue(ticket_positive) {
            var positive_workerA = "", moduo_timetable = "";
            switch (ticket_positive) {
              case "fullSize":
                positive_workerA = "638px";
                moduo_timetable = "628px";
                break;

              case "twoColumns":
                positive_workerA = "442px";
                moduo_timetable = "432px";
                power_tier = true;
                break;

              case "oneColumn":
                positive_workerA = "215px";
                moduo_timetable = "205px";
                range_alarm = true;
                break;

              default:
                return;
            }
            var system_acceptor = timeout_logic.getElementById("ntv-wrap-ifrm");
            system_acceptor.style.width = positive_workerA;
            system_acceptor.contentWindow.document.getElementById("adinject-redesign-native-frame").style.width = moduo_timetable;
            var entry_accountant = timeout_logic.getElementById("pxpubwrapper");
            if (entry_accountant) {
                entry_accountant.style.width = positive_workerA;
                try {
                    system_acceptor.contentWindow.document.getElementById("native-ad-countdown").style.visibility = "hidden";
                } catch (worker_unit) {}
            }
        }
        function cycle_list(abstractor_counter, config_accuracy) {
            var gate_metro, session_mutex;
            try {
                if (!(query_tool && tool_alarm.getNumberOfImpressions() === 0)) {
                    tool_alarm.close(abstractor_counter);
                    tier_queue.setTrckImg("vicl-trck", "//" + queue_theme.servingDomain + "/vic");
                }
                gate_metro = timeout_logic.getElementById("ntv-wrap-ifrm");
                if (gate_metro) {
                    gate_metro.parentNode.removeChild(gate_metro);
                }
                if (tool_alarm.getNumberOfImpressions() === 0 && abstractor_counter) {
                    tier_parameters.send(tier_parameters.EXCHANGE, "SETNTVSLIDE");
                    shell_power = "closed-before-imp";
                } else if (config_accuracy) {
                    shell_power = "closed-before-imp";
                } else {
                    shell_power = "closed";
                }
                if (query_storage) {
                    session_mutex = timeout_logic.getElementById("pxpubwrapper");
                    session_mutex.parentNode.removeChild(session_mutex);
                }
            } catch (worker_unit) {
                accuracy_path.log("bn-nu-close-ex", worker_unit.toString());
            }
        }
        function adapt_acceptor() {
            var members_path, parameters_alarm = "", configs_entry = "", config_unit = "", practical_handle = "";
            if (!query_storage) {
                parameters_alarm = '<a class="questionmark unselectable" unselectable="on" onclick="parent.window.__ppl.BN.openHelpURL(1)" unselectable="on" href="#">?</a>\n';
                config_unit = '<div class="ads-by-domain unselectable" unselectable="on" onclick="logoBtnHandler();">Ads by ' + queue_theme.appName + "</div>\n";
            } else {
                config_unit = '<div class="ads-by-propel-media-light unselectable" unselectable="on" onclick="logoBtnHandler();"><span class="ads-by-text">Ads by <img src="https://' + signal_tier.cdnDomain + '/v/img/propel_media_light.png" alt="" width="42" height="14" /></span></div>\n';
            }
            if (signal_tier.nativeOnly) {
                configs_entry = '<div id="native-ad-countdown" class="unselectable" unselectable="on">These recommendations will reload in <span id="timer">1 </span> seconds</div>\n';
            }
            practical_handle = '<div id="ui-controls" class="unselectable" unselectable="on"><a id="close-x" class="close-x unselectable" unselectable="on" onclick="closeBtnHandler();" href="#">X</a>\n' + parameters_alarm + "</div>\n";
            try {
                members_path = "<!DOCTYPE html>\n" + "<html>\n" + "<head>\n" + "    <style>\n" + "       html, body, div, span, applet, object, iframe, h1, h2, h3, h4, h5, h6, p, blockquote, pre, a, abbr, acronym, address, big, cite, code, del, dfn, em, img, ins, kbd, q, s, samp, small, strike, strong, sub, sup, tt, var, b, u, i, center, dl, dt, dd, ol, ul, li, fieldset, form, label, legend, table, caption, tbody, tfoot, thead, tr, th, td, article, aside, canvas, details, embed, figure, figcaption, footer, header, hgroup, menu, nav, output, ruby, section, summary, time, mark, audio, video {\n" + "           margin: 0;\n" + "           padding: 0;\n" + "           border: 0;\n" + "           font-size: 100%;\n" + "           font: inherit;\n" + "           vertical-align: baseline;\n" + "           outline: none;\n" + "           -webkit-font-smoothing: antialiased;\n" + "           -webkit-text-size-adjust: 100%;\n" + "           -ms-text-size-adjust: 100%;\n" + "           -webkit-box-sizing: border-box;\n" + "           -moz-box-sizing: border-box;\n" + "           box-sizing: border-box;\n" + "       }\n" + "       html { overflow-y: scroll; }\n" + "       body {\n" + '           font-family:"Open Sans", Arial, Helvetica, sans-serif;\n' + "           background:#none transparent !important;\n" + "           color:#000;\n" + "       }\n" + "       #adinject-redesign-native-frame {\n" + "           width: 432px;\n" + "           height: 342px !important;\n" + "           position: absolute !important;\n" + "           right: 0px !important;\n" + "           bottom: 0px !important;\n" + "           z-index: 2147483646 !important;\n" + "           border-top-left-radius: 2px !important;\n" + "           border-top-right-radius: 0px !important;\n" + "           border-bottom-left-radius: 2px !important;\n" + "           border-bottom-right-radius: 2px !important;\n" + "           box-shadow: 0px 0px 10px 0px #000000 !important;\n" + "           background-color: #FFFFFF !important;\n" + "       }\n" + "       #adinject-redesign-native-frame:before {\n" + '           content: " "; \n' + "           position: fixed;\n" + "           margin: -24px 0 0 0px;\n" + "           width: " + (query_storage ? "28px" : "50px") + ";\n" + "           height: 24px;\n" + "           right: 0px;\n" + "           border-radius: 0px 2px 0px 0px;\n" + "           background-color: rgba(255, 255, 255, 1.0);\n" + "           -webkit-box-shadow: -2px -5px 10px -5px rgba(0,0,0,0.5);\n" + "           -moz-box-shadow: -2px -5px 10px -5px rgba(0,0,0,0.5);\n" + "           box-shadow: -2px -5px 10px -5px rgba(0,0,0,0.5);\n" + "       }\n" + "       #adinject-redesign-native-frame:after {\n" + '           content: " ";\n' + "           position: fixed;\n" + "           width: 0;\n" + "           height: 0;\n" + "           right: " + (query_storage ? "28px" : "50px") + ";\n" + "           margin: -24px 0 0 -540px;\n" + "           border-bottom: 24px solid rgba(255, 255, 255, 1.0);\n" + "           border-left: 10px solid transparent;\n" + "       }\n" + "       #adinject-content-frame {\n" + "           width: 628px;\n" + "           height: 326px !important;\n" + "           margin: 0px !important;\n" + "           padding: 0px !important;\n" + "           border: none !important;\n" + "           position: absolute !important;\n" + "           bottom: 16px !important;\n" + "       }\n" + "       #ui-controls {\n" + "           position: absolute !important;\n" + "           top: -17px !important;\n" + "           right: 11px !important;\n" + "           margin: 0px !important;\n" + "           border-radius: 15px !important;\n" + "           text-align: center !important;\n" + "           z-index:99 !important;\n" + "       }\n" + "       #ui-controls-legacy {\n" + "           position: absolute !important;\n" + "           top: -24px !important;\n" + "           right: 0px !important;\n" + "           width: 65px !important;\n" + "           height: 24px !important;\n" + "           padding: 4px 15px !important;\n" + "           margin: 0px !important;\n" + "           text-align: center !important;\n" + "           z-index: 99 !important;\n" + "           background: #FFF !important;\n" + "       }\n" + "       a.close-x {\n" + "           font-family: Arial, Helvetica, sans-serif;\n" + "           font-size: 15px !important;\n" + "           font-weight: bold !important;\n" + "           color: #a8a8a8 !important;\n" + "           text-decoration: none !important;\n" + "           margin: 0px !important;\n" + "           float: left !important;\n" + "       }\n" + "       a.questionmark {\n" + "           font-family: Arial, Helvetica, sans-serif;\n" + "           font-size: 17px !important;\n" + "           font-weight: bold !important;\n" + "           color: #a8a8a8 !important;\n" + "           text-decoration: none !important;\n" + "           margin: -1px 0 0 7px !important;\n" + "           float: left !important;\n" + "       }\n" + "       .ads-by-propel-media-light {\n" + "           position: absolute !important;\n" + "           margin: 0px 14px 0px 0px !important;\n" + "           font-family: Arial, Helvetica, sans-serif;\n" + "           font-size: 12px !important;\n" + "           color: #666666 !important;\n" + "           text-align: right !important;\n" + "           z-index: 1 !important;\n" + "           right: 0px !important;\n" + "           bottom: 0px !important;\n" + "           vertical-align: middle !important;\n" + "           cursor: pointer !important;\n" + "       }\n" + "       .ads-by-text {\n" + "           font-family: Arial, Helvetica, sans-serif;\n" + "           font-size: 12px !important;\n" + "           color: #666666 !important;\n" + "           text-align: right !important;\n" + "           text-decoration: none !important;\n" + "       }\n" + "       .ads-by-domain {\n" + "           position: absolute !important;\n" + "           margin: 0px 12px 0px 0px !important;\n" + "           font-family: Arial, Helvetica, sans-serif;\n" + "           font-size: 12px !important;\n" + "           color: #666666 !important;\n" + "           text-align: right !important;\n" + "           z-index: 1 !important;\n" + "           right: 0px !important;\n" + "           bottom: 0px !important;\n" + "           vertical-align: middle !important;\n" + "           cursor: pointer !important;\n" + "       }\n" + "       .ads-by-domain-jsp {\n" + "           position: absolute !important;\n" + "           right: 0px !important;\n" + "           bottom: 0px !important;\n" + "           margin: 0px 12px 0px 0px !important;\n" + "           font-family: Arial, Helvetica, sans-serif;\n" + "           font-size: 12px !important;\n" + "           color: #666666 !important;\n" + "           text-align: right !important;\n" + "           z-index: 1 !important;\n" + "           vertical-align: middle !important;\n" + "       }\n" + "       #native-ad-countdown {\n" + "           float: left !important;\n" + "           width: 400px !important;\n" + "           height: 12px !important;\n" + "           position: absolute !important;\n" + "           bottom: 0px !important;\n" + "           font-size: 10px !important;\n" + "           padding: 2px 4px 0px 13px !important;\n" + "       }\n" + "       .unselectable {\n" + "           -moz-user-select: -moz-none;\n" + "           -khtml-user-select: none;\n" + "           -webkit-user-select: none;\n" + "           -o-user-select: none;\n" + "           user-select: none;\n" + "       }\n" + "    </style>\n" + "</head>\n" + '<body style="margin: 0px; padding: 0px;">\n' + '    <div id="adinject-redesign-native-frame" class="unselectable" unselectable="on">\n' + practical_handle + '        <iframe id="adinject-content-frame" frameborder="0" scrolling="no" marginwidth="0" marginheight="0" allowtransparency="true"></iframe>\n' + configs_entry + config_unit + "    </div>\n" + "    <script>\n" + "        var respondToMessage = function(e) {\n" + "            var n = e.data;\n" + '            if (n === "TIMER") {\n' + "                counter.run();\n" + '            } else if (n === "NONATIVE") {\n' + '                parent.postMessage("NONATIVE", "*");\n' + '            } else if (n === "NOBNHIDE") {\n' + '                parent.postMessage("NOBNHIDE", "*");\n' + '            } else if (n === "RSZTWOCOLS") {\n' + '                parent.postMessage("RSZTWOCOLS", "*");\n' + "            }\n" + "        };\n" + "        var counter = {\n" + "            count:" + (queue_theme.pubConf !== "" ? acceptor_list.parse(queue_theme.pubConf).firstTimer : 10) + ",\n" + "            ticker: 10,\n" + "            timId: null,\n" + "            run: function() {\n" + "                counter.ticker = counter.count;\n" + (queue_theme.pubConf ? "counter.count = " + acceptor_list.parse(queue_theme.pubConf).secondTimer + ";\nif(counter.ticker < 1) {return;}\n" : "") + '                document.getElementById("close-x").innerHTML = counter.ticker;\n' + "                counter.timId = window.setInterval(function() {\n" + "                    if (--counter.ticker < 1) {\n" + "                        clearInterval(counter.timId);\n" + "                        counter.timId = null;\n" + '                        document.getElementById("close-x").innerHTML = "X";\n' + "                        return;\n" + "                    }\n" + '                    document.getElementById("close-x").innerHTML = counter.ticker;\n' + "                }, 1e3);\n" + "            }\n" + "        };\n" + "        var nativeCounter = {\n" + "            count: 15,\n" + "            ticker: 15,\n" + "            timId: null,\n" + "            run: function() {\n" + "                nativeCounter.ticker = nativeCounter.count;\n" + '                document.getElementById("timer").innerHTML = nativeCounter.ticker;\n' + "                nativeCounter.timId = window.setInterval(function() {\n" + "                    if (--nativeCounter.ticker < 1) {\n" + "                        clearInterval(nativeCounter.timId);\n" + "                        nativeCounter.timId = null;\n" + '                        document.getElementById("timer").innerHTML = nativeCounter.count;\n' + '                        document.getElementById("adinject-content-frame").contentWindow.postMessage("REFRESHALL", "*");\n' + "                        window.setTimeout(function() { nativeCounter.run();}, 500);\n" + "                        return;\n" + "                    }\n" + '                    document.getElementById("timer").innerHTML = nativeCounter.ticker;\n' + "                }, 1e3);\n" + "            }\n" + "        };\n" + "        \n" + "        var closeBtnHandler = function() {\n" + "            if(!counter.timId) {\n" + "               parent.window.__ppl.BN.closeNative(1);\n" + "            }\n" + "        };\n" + "        var logoBtnHandler = function() {\n" + "            parent.window.__ppl.BN.openHomeURL();\n" + "        };\n" + '        window.addEventListener ? window.addEventListener("message", respondToMessage, !1) : window.attachEvent("onmessage", respondToMessage);\n' + "        if(" + signal_tier.nativeOnly + ") {\n" + "            nativeCounter.run();\n" + "        }\n" + "    </script>\n" + " </body>\n" + " </html>\n";
                return members_path;
            } catch (worker_unit) {
                accuracy_path.log("bn-nu-crntvfrmcont-ex", worker_unit.toString());
            }
        }
        function leave_values() {
            return shell_power;
        }
        function help_timetable(access_point) {
            if (!access_point) {
                access_point = timeout_logic.getElementById("ntv-wrap-ifrm");
            }
            if (access_point) {
                access_point.style.right = "-5000px";
            }
        }
        return {
            showNativeUnit: make_access,
            init: calculate_power,
            showNativeWrapper: get_point,
            hideNativeWrapper: help_timetable,
            removeNativeWrapper: build_alarm,
            createPublisherWrapper: move_model,
            showPublisherWrapper: seek_shell,
            hidePublisherWrapper: accumulate_unit,
            removePublisherWrapper: serve_moduo,
            createNativeUnit: notify_index,
            createNativeWrapper: adapt_broker,
            close: cycle_list,
            resize: send_queue,
            getStatus: leave_values,
            refreshThumbs: maximum_power,
            resetShowWithDelay: replace_store,
            getInitializationStatus: dig_clock,
            getNativeUnitDelayStatus: adaptive_tool,
            positionIntoViewport: delete_value,
            getPublisherContainerStatus: replace_timetable
        };
    }();
    return {
        run: return_ticket,
        register: abort_parameters,
        __module: configs_text,
        init: calculate_power
    };
}());
__ppl.loader = __ppl.loader || {};

__ppl.loader["YYQ"] = __ppl.loader["YYQ"] || [];

__ppl.loader["YYQ"].push(function() {
    var unit_thread, acceptor_list, configs_text = {
        deps: [ "config", "pmjson" ],
        bind: function() {
            var shell_parameters = 0;
            unit_thread = arguments[shell_parameters++];
            acceptor_list = arguments[shell_parameters++];
        },
        name: "mode"
    };
    var query_storage = null, values_project = null, moduo_system = null;
    function adapt_accuracy() {
        return values_project;
    }
    function abort_model() {
        return moduo_system;
    }
    function calcandreturn_unit() {
        return query_storage;
    }
    return {
        getExtensionMode: abort_model,
        getPubModeDemo: adapt_accuracy,
        getPubMode: calcandreturn_unit,
        __module: configs_text
    };
}());
