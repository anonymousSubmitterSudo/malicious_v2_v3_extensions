__ppl.loader = __ppl.loader || {};

__ppl.loader["YYQ"] = __ppl.loader["YYQ"] || [];

__ppl.loader["YYQ"].push(function() {
    var configs_text = {
        deps: [],
        bind: function() {},
        name: "debug"
    };
    var service_word = window, parameters_project = false;
    __ppl.debug = {};
    __ppl.debug.setDebugMode = leave_system;
    function leave_system(members_metro) {
        parameters_project = !!members_metro;
    }
    function remove_alarm(moduo_unit) {
        if (parameters_project) {
            console.log(moduo_unit);
        }
    }
    return {
        __module: configs_text,
        log: remove_alarm,
        setDebugMode: leave_system
    };
}());
__ppl.loader = __ppl.loader || {};

__ppl.loader["YYQ"] = __ppl.loader["YYQ"] || [];

__ppl.loader["YYQ"].push(function() {
    var session_ticket, unit_thread, tier_queue, tier_parameters, counter_system, accuracy_path, configs_text = {
        deps: [ "mediator", "config", "util", "comm-channel", "brand", "logger" ],
        bind: function() {
            var shell_parameters = 0;
            session_ticket = arguments[shell_parameters++];
            unit_thread = arguments[shell_parameters++];
            tier_queue = arguments[shell_parameters++];
            tier_parameters = arguments[shell_parameters++];
            counter_system = arguments[shell_parameters++];
            accuracy_path = arguments[shell_parameters++];
        },
        name: "lp-check"
    };
    const store_timeout = /FA[-_].+\|\d{10}\|[tdalo]\|.+\|.*\|[a-z0-9]{32}\|.*/g, signal_gate = 600;
    var server_project, project_config, parameters_signal, acceptor_moduo;
    function increment_counter(list_timeout) {
        server_project = list_timeout;
    }
    function exist_tier() {
        return typeof WXBrandingInfoBar !== "undefined" && WXBrandingInfoBar;
    }
    function modify_unit() {
        return server_project;
    }
    function isbool_practical() {
        let tier_clock = false, abstractor_range = server_project.split("|"), queue_ticket = abstractor_range[1], server_accuracy = parseInt(abstractor_range[7], 10);
        server_accuracy = isFinite(server_accuracy) ? server_accuracy : signal_gate;
        if (Math.floor(new Date().getTime() / 1e3) - queue_ticket > server_accuracy) {
            tier_clock = true;
        }
        return tier_clock;
    }
    function adapt_alarm() {
        let tier_clock = false, clock_session = null;
        if (decrement_acceptor()) {
            clock_session = replace_server();
            if (clock_session.brandingRequired) {
                tier_clock = true;
            } else if (clock_session.brandingRequiredIgnoreTLImpression) {
                tier_parameters.send(tier_parameters.PAGE, "RUN_LPSCR");
            }
        }
        return tier_clock;
    }
    function remove_model(tool_moduo) {
        try {
            if (!project_config && adapt_alarm() && !exist_tier()) {
                project_config = true;
                sets_config(tool_moduo.etc.servingDomain);
            }
        } catch (worker_unit) {
            accuracy_path.log([ "cr-brnd-run-ex" ], worker_unit.toString());
        }
    }
    function segment_shell() {
        server_project = "";
    }
    function replace_server() {
        var queue_theme = unit_thread.get(), range_ticket = server_project.split("|"), config_list = acceptor_moduo.body.nodeName.toUpperCase() === "FRAMESET", positive_worker = tier_queue.getPageInfo(), clock_session = {};
        if (server_project.substr(0, 2) === "FA") {
            clock_session.timeElapsed = Math.floor(new Date().getTime() / 1e3) - range_ticket[1];
        }
        clock_session.redirect = queue_theme.redirectDomainPattern && acceptor_moduo.domain.match(new RegExp(queue_theme.redirectDomainPattern, "ig")) != null;
        clock_session.brandingRequired = !clock_session.redirect && clock_session.timeElapsed < 25 && range_ticket.length >= 3 && range_ticket[2].match(new RegExp("^[tda]$", "g")) != null;
        clock_session.brandingRequiredIgnoreTLImpression = !clock_session.redirect && clock_session.timeElapsed < 25;
        clock_session.isTA = range_ticket.length >= 3 && range_ticket[2] === "t";
        clock_session.isDA = clock_session.isTA || clock_session.brandingRequired && server_project.substr(0, 3) !== "FA-";
        clock_session.adType = range_ticket.length >= 3 ? range_ticket[2] : "";
        clock_session.debugStr = clock_session.timeElapsed + "|" + (typeof parameters_signal.onbeforeunload === "function") + "|" + positive_worker.innerWidth + "x" + positive_worker.innerHeight + "|" + (typeof acceptor_moduo.body.onclick === "function" || typeof acceptor_moduo.onclick === "function") + "|" + server_project + "|" + parameters_signal.screen.width + "x" + parameters_signal.screen.height + "||" + clock_session.redirect + "|" + clock_session.brandingRequired + "|" + (acceptor_moduo.body ? acceptor_moduo.body.innerHTML.length : 0);
        clock_session.lpDebugStr = clock_session.timeElapsed + "|" + (typeof parameters_signal.onbeforeunload === "function") + "|" + positive_worker.innerWidth + "x" + positive_worker.innerHeight + "|" + (typeof acceptor_moduo.body.onclick === "function" || typeof acceptor_moduo.onclick === "function") + "|" + parameters_signal.screen.width + "x" + parameters_signal.screen.height + "||" + clock_session.redirect + "|" + clock_session.brandingRequired + "|" + (acceptor_moduo.body ? acceptor_moduo.body.innerHTML.length : 0) + "|" + (config_list ? 1 : 0) + "|" + server_project;
        clock_session.params = range_ticket;
        clock_session.winName = server_project;
        clock_session.isNTA = range_ticket.length > 6 && range_ticket[6] === "nta";
        if (clock_session.brandingRequired && config_list) {
            clock_session.debugStr += "|FRAMESET|0";
        }
        return clock_session;
    }
    function calculate_power(list_timeout) {
        increment_counter(list_timeout);
        calculate_members();
        session_ticket.register({
            instance: this,
            events: {
                BRMNGRUN: {
                    instance: this,
                    type: "BRMNGRUN",
                    handler: remove_model
                }
            },
            name: "BRMNG"
        });
    }
    function calculate_members() {
        if (typeof parameters_signal.WXIsAdWindow === "undefined" || typeof parameters_signal.WXIsAdWindow !== "function") {
            parameters_signal.WXIsAdWindow = decrement_acceptor;
        }
    }
    function decrement_acceptor() {
        let tier_clock = false;
        if (server_project && server_project.match(store_timeout)) {
            if (isbool_practical()) {
                segment_shell();
            } else {
                tier_clock = true;
            }
        }
        return tier_clock;
    }
    function sets_config(session_accuracy) {
        let material_clock = server_project.split("|"), signal_query = material_clock[3] + "|" + material_clock[4];
        tier_parameters.send(tier_parameters.SERVING, "PMATTRCONFREQ", {
            url: "//" + session_accuracy + "/bb?wn=" + encodeURIComponent(signal_query) + "&json=1"
        }, function(point_name) {
            counter_system.run(point_name, server_project);
        });
    }
    function abort_acceptor() {
        return decrement_acceptor() ? replace_server() : null;
    }
    (function() {
        try {
            server_project = "";
            project_config = false;
            parameters_signal = window;
            acceptor_moduo = document;
        } catch (worker_unit) {}
    })();
    return {
        isLP: decrement_acceptor,
        getLpId: modify_unit,
        __module: configs_text,
        getAdInfo: abort_acceptor,
        init: calculate_power
    };
}());
