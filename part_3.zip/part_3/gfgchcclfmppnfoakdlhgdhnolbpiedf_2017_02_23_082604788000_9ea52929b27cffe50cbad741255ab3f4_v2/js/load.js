document.addEventListener("DOMContentLoaded",function(){var bg=chrome.extension.getBackgroundPage();location.href="http://new."+bg.ext_domain+"/"+bg.ext_theme+"/";});
