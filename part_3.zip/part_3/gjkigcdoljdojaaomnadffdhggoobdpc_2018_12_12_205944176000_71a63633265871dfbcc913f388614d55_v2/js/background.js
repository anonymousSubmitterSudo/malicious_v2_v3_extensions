chrome.runtime.setUninstallURL('https://superchromeapps.com/goodbye/?extid=live_fortnite');

chrome.runtime.onInstalled.addListener(function(details) {
	localStorage.url = 'https://superchromeapps.com/live_fortnite';
    if (details.reason == "install") {
        chrome.tabs.create({url: localStorage.url + '?page=welcome&extid=' + chrome.runtime.id });
    }
});

chrome.browserAction.onClicked.addListener(function() {
    chrome.tabs.create({url:localStorage.url});
});

chrome.runtime.onMessage.addListener(
  function(request) {
    if (request.do == "uninstall"){
    	chrome.management.uninstallSelf({"showConfirmDialog":true});
    }
}); 
