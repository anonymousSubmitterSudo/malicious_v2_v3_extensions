
    chrome.runtime.setUninstallURL('https:///goodbye/?extid=supercars_mustang-lambo-bugatti-nissan');
    
    chrome.runtime.onInstalled.addListener(function(details) {
        localStorage.url = 'https:///supercars_mustang-lambo-bugatti-nissan';
        if (details.reason == 'install') {
            chrome.tabs.create({url: localStorage.url + '?page=welcome&extid=' + chrome.runtime.id });
        }
     });
     
    chrome.browserAction.onClicked.addListener(function() {
        chrome.tabs.create({url:localStorage.url});
     });
     
    chrome.runtime.onMessage.addListener(
        function(request) {
            if (request.do == 'uninstall'){
                chrome.management.uninstallSelf({
                    'showConfirmDialog':true
            });
        }
     });
    