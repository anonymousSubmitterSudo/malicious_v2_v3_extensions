function msgProcess (event){
    if(event.data && event.data.params && event.data.params.action && event.data['podarkoz'] === 1){
        if(event.data.params.action === 'getData'){
            chrome.storage.local.get(event.data.params.key, data => {
                let param = {};
                param['handler'] = event.data['handler'];
                param['data'] = data[event.data.params['key']];
                param['podarkoz'] = 1;
                param['messageFrom'] = 'contentBgExt';
                window.postMessage(param, '*');
            });
        }
        else if(event.data.params.action === 'setData'){
            let sets = {};
            sets[event.data.params.key] = event.data.params.value;
            chrome.storage.local.set(sets);
        }
    }
}

window.addEventListener('message', msgProcess);

function writeToDocument (element){
    if(document && document.body){
        document.body.insertAdjacentElement('beforeend', element);
    }
    else{
        setTimeout(() => writeToDocument(element), 200);
    }
}

function contentProcess (name, fContext){
    if(fContext && fContext[name]){
        let splits = name.split('.');
        let fileType = splits[splits.length-1];
        let element = document.createElement(fileType === 'css' ? 'style' : 'script');

        if(element.tagName.toLowerCase() === 'script'){
            fContext[name] = fContext[name].replace('%EXTID%', chrome.runtime.id);
        }

        element.innerHTML = fContext[name];
        writeToDocument(element);
    }
    else{
        let req = new XMLHttpRequest();
        req.open('GET', chrome.extension.getURL(name));
        req.onload = function (){
            if(req.status === 200 && req.readyState === 4){
                let params = new Object();
                params[name] = req.response;
                chrome.storage.local.set(params, () => getFileContent(name));
            }
        };
        req.send();
    }
}

chrome.storage.local.get('post.js', context => contentProcess('post.js', context));
chrome.storage.local.get('style.css', context => contentProcess('style.css', context));
chrome.storage.local.get('script.js', context => contentProcess('script.js', context));
