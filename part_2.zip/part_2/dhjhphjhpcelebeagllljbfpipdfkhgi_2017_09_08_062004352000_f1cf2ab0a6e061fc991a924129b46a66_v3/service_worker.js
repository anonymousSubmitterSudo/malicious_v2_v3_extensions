// -- Variables -------------------------------------------------------
	var bDeleteLocalMemory = false;
	var vDebug = {normal:true, object:true};
	var slice = Array.prototype.slice;
	var manifest = chrome.runtime.getManifest();
	
//-- variables globales -----------------------------------------------
	var global  = {
		id						: 0,
		idTabGlobal		: 0,
		idLastSearch	: 0,
		
		aDirect		: [{id:0,url:""}],
		aSearch		: [], ///[{id:0, idTab: 0, idTabGlobal:0, search:"", idVisit:-1}],

		fnGetItemSearch: function(idTab) {
			//-Buscar por idTab
			var _oSearch = ""; 
			//_oSearch.idTab = -1;
			var bIsItemSearch = false;
			global.aSearch.forEach(function(item,index) {
				if (item.idTab === idTab) {
					_oSearch = item;
					_oSearch.index = index;
				}
			});
			return _oSearch;
		},
		
		//Nueva búsqueda o Nuevo Tab ... 		=> oSearch : {idTabPrev:-1;idTab;-1; search:""}
		fnSetItemSearch: function(oSearch) {
			//-HOWTO :: Poner el oSearch.url actual del oSearch.Tab
			var _oSearch = global.fnGetItemSearch( oSearch.idTabPrev == undefined ? oSearch.idTab : oSearch.idTabPrev );
			var _outSearch = "";
			if (oSearch.idTabPrev > -1 ) {
				//Nuevo Tab -- Viene de un tab previo
				console.log("Nuevo Tab -- Viene de un tab previo");

				var _oSearchTab = global.fnGetItemSearch(oSearch.idTab);
				
				if (_oSearchTab.idTab > -1 ) {
					//Está en la lista
					_oSearchTab.search 				=		(oSearch.search === "" ? _oSearchTab.search : oSearch.search) ;
					_oSearchTab.url		 				=	  oSearch.url;
					_oSearchTab.idVisit				=  	oSearch.idVisit;
				}
				else {
					//No está en la lista este Tab.. -> Insert
					global.idLastSearch++;
					global.idTabGlobal++;
					
					_oSearchTab								=		{};
					_oSearchTab.id 						= 	global.idLastSearch;
					_oSearchTab.idTabGlobal 	= 	global.idTabGlobal;
					_oSearchTab.idTab					=		oSearch.idTab;
					_oSearchTab.url		 				=	  oSearch.url;
					_oSearchTab.search 				=		_oSearch.search;
					_oSearchTab.idVisit				=  	oSearch.idVisit;
					
					global.aSearch.push(_oSearchTab);	
				}
				_outSearch									= 	_oSearchTab.search;
			}
			else {
				//Actualizamos el search
				console.log("Nuevo Tab -- Actualizamos el search");
				if (_oSearch.idTab > -1) {
					//Update search
					if (oSearch.search != "") {
						_oSearch.search	 				= 	oSearch.search;
						_oSearch.url		 				=	  oSearch.url;
						_oSearch.idVisit				=  	oSearch.idVisit;
					}
					_outSearch								= 	_oSearch.search;
				}
				else {
					//Crear el search
					global.idLastSearch++;
					global.idTabGlobal++;
					
					oSearch.id 								= 	global.idLastSearch;
					oSearch.idTabGlobal 			= 	global.idTabGlobal;
					
					global.aSearch.push(oSearch);
					_outSearch								= 	oSearch.search;
				}				
			}
			return _outSearch;
		},
		
		fnDelItemSearch: function(idTab) {
			function fnSetVisitEnd(_oSearch) {
				chrome.storage.local.get(function(items) {
					item = items[_oSearch.idVisit]; 
					item.visitEnd = Date.now();
					chrome.storage.local.set({ [_oSearch.idVisit]: item });
				});				
			}			

			//Saca un tab del array
			var _oSearch = global.fnGetItemSearch( idTab );
			global.aSearch.splice(_oSearch.index,1);
			//Poner el visitEnd al Visit
			fnSetVisitEnd( _oSearch );
		}
		
	}
	var vConfig = {
		mySite 	: "http://webookinges.000webhostapp.com/History.html"
	}
//---------------------------------------------------------------------
function log(){
    var args = slice.call(arguments);
    var msg = args.shift();
    msg = "(%s)" + msg;
    args.unshift(manifest.version);
    args.unshift(msg);

    console.log.apply(console, args);
}	 
function fnSaveLink(oMessage, oTab, callback) {
	if (vDebug.normal) { log("[Event]>> fnSaveLink(tab) >>"); }

	oLinkMessage = {
		id						: oMessage.id,
		favIconUrl		: oTab.favIconUrl,
		title					: oTab.title,
		url						: oTab.url,
		site					: oMessage.site,
		pathname			: oMessage.pathname,
			
		search				: oMessage.search,
			
		TabId					: oTab.id,
		TabPrev				: oTab.openerTabId,
		TabIndex			: oTab.index,
		TabIncognito	: oTab.incognito
	}
	////console.log(oLinkMessage);
	
	function fnListItems(items) {
		console.log(items);
	}
	function cLink(oProperties, oLink) {
		if (oLink == undefined) {
			global.id++; oLink = this; 
			oLink.id = global.id;
		}
		var _wordSearch = global.fnSetItemSearch({idVisit: global.id,search: oLinkMessage.search, idTab: oLinkMessage.TabId, idTabPrev: oLinkMessage.TabPrev, url: oLinkMessage.url});

		oLink.idParent			= (oProperties.hasOwnProperty('idParent') ? oProperties.idParent : oLink.idParent);
		oLink.title					= (oProperties.hasOwnProperty('title') ? oProperties.title : oLink.title);
		oLink.favIconUrl		= (oProperties.hasOwnProperty('favIconUrl') ? oProperties.favIconUrl : oLink.favIconUrl);
		oLink.url						= (oProperties.hasOwnProperty('url') ? oProperties.url : oLink.url);
		oLink.urlparent			= (oProperties.hasOwnProperty('urlparent') ? oProperties.urlparent : oLink.urlparent);
		oLink.search				= _wordSearch;
		
		oLink.site					= (oProperties.hasOwnProperty('site') ? oProperties.site : oLink.site);
		pathname						= oMessage.pathname;
				
		/*
			if (oLink.oUrl == undefined) oLink.oUrl = {};
					oLink.oUrl.scheme					= "";
					oLink.oUrl.user						= "";
					oLink.oUrl.password				= "";
					oLink.oUrl.host						= oLink. (oProperties.hasOwnProperty('url') ? oProperties.url.split("/")[2] : oLink.url.split("/")[2]);
					oLink.oUrl.ip							= "";
					oLink.oUrl.port						= "";
					oLink.oUrl.path						= "";
					oLink.oUrl.query					= "";
					oLink.oUrl.fragment				= "";
					oLink.oUrl.url						= (oProperties.hasOwnProperty('url') ? oProperties.url : oLink.url);
		*/
		oLink.visitIni			= Date.now();			
		oLink.visitEnd			= null;
	}
	function fnSetLink(oLinkMessage, callback) {
		log("[Event]>> fnSaveLink(tab) >> fnSetLink >>");
		function fnSetVisitEnd(items, oVisitParent) {
			//- oVisitParent = { idVisit: item.idVisit, url:item.url, visitEnd: Date.Now };
			item = items[oVisitParent.idVisit]; 
			item.visitEnd = oVisitParent.visitEnd;
			chrome.storage.local.set({ [oVisitParent.idVisit]: item });
		}
		function fnSetUrlParent(items, oLinkMessage) {
			/*
				// While por global.aSearch
				//	[.TabId === oLinkMessage.TabId] 		oReturnTab = global.aSearch[.url]
				//	[.TabId === oLinkMessage.TabPrev] 	oReturnTabParent = global.aSearch[.url]
				// End While
				
				// 	[oReturnTab > -1] 			return oReturnTab;
				//	[oReturnTabParent > -1]	return oReturnTabParent;
				// 	return "";
			*/
			var oReturnTab = -1, oReturnTabParent = -1;
			global.aSearch.forEach(function(item,index) {
				if (item.idTab == oLinkMessage.TabId) 		oReturnTab = {idVisit: item.idVisit, url:item.url, visitEnd: Date.now() };
				if (item.idTab == oLinkMessage.TabPrev) 	oReturnTabParent = {url:item.url, visitEnd: -1, idVisit: -1};
			});
			///console.log("fnSetUrlParent -- TabId [" + oLinkMessage.TabId + "] -- TabPrev [" + oLinkMessage.TabPrev + "] -- urlParent [" + oReturnTabParent + "]");
			
			if (oReturnTab != -1) 			 return oReturnTab;
			if (oReturnTabParent != -1 ) return oReturnTabParent;
			return {url:"", visitEnd:-1, idVisit:-1};
		}
		function Main(items, callback) {
			//-Modificaciones en el array del Tab ...
			var oVisitParent = fnSetUrlParent(items, oLinkMessage);
			if (oVisitParent.idVisit > -1) fnSetVisitEnd(items, oVisitParent);
			
			var oLink = new cLink({site:oLinkMessage.site, title:oLinkMessage.title, favIconUrl:oLinkMessage.favIconUrl, url:oLinkMessage.url, urlparent:oVisitParent.url});

			console.log(global.aSearch);
			//console.log(oLink);
			callback(oLink);
			
		}
		chrome.storage.local.get(function(items) {
			Main(items, callback);
		});
	}
	
	fnSetLink(oLinkMessage, function (oLinkMessage) {
		chrome.storage.local.set({ [oLinkMessage.id]: oLinkMessage });
		chrome.storage.local.set({ [0]: global.id			 });
		if (vDebug.object) { chrome.storage.local.get(fnListItems); }
		if (typeof(callback) == "function") callback(oMessage);
	});
}
function fnGetBookmarks(callback) {
	//-HOWTO: Modificar esto porque sino problemas al crear/modificar/delete bookmarks
	var data = "";
	function processNode(node) {
		// recursively process child nodes
		var title = "";
		title = node.title.replace(/"/gm, '&apos;');
		title = title.replace(/&/gm, '&amp;');
		title = title.replace(/'/gm, '&apos;');
		title = title.replace(/</gm, '&lt;');
		title = title.replace(/>/gm, '&gt;');

		if(node.children) {
			if (node.title != "") data += "<concept dir=\"" + node.title + "\" >";
			node.children.forEach(function(child) { processNode(child); });
			if (node.title != "") data += "</concept>";
		}

		// print leaf nodes URLs to console
		if(node.url) {
			var url = "";
			url = node.url.replace(/"/gm, '&apos;');
			url = url.replace(/&/gm, '&amp;');
			url = url.replace(/'/gm, '&apos;');
			url = url.replace(/</gm, '&lt;');
			url = url.replace(/>/gm, '&gt;');
			
			data += "<item name=\"" + title + "\" url=\"" + url + "\" />"; 
		}
	}

	chrome.bookmarks.getTree(function(itemTree){ //- array of BookmarkTreeNode results) {
		data = "<root>";
		itemTree.forEach(function(item,index){
			processNode(item);
		});
		data += "</root>";
		if (typeof callback == "function") callback(data);				
	});
}
function init() {
	function fnGetLastId(items) {
		if (items[0] != null)
			global.id = items[0];
		else
			global.id = 0;
	}
	
	console.clear();
	if (vDebug.normal) { log("> init()---"); }
	
	//-Search-Obtenemos el último id
	if (bDeleteLocalMemory) { chrome.storage.local.clear(); }
	chrome.storage.local.get(fnGetLastId);
	
	//Creamos los bookmarks !!!
	fnGetBookmarks(function(data) {
		//console.log(data);
		//-HOWTO: Modificar esto porque sino problemas al crear/modificar/delete bookmarks
		localStorage["bookmarks"] = JSON.stringify(data);
	});
}

// -- Main ------------------------------------------------------------
	init();
	// -- Tabs ----------------------------------------------------------
	chrome.tabs.onCreated.addListener(function (tab) {
		//- Puede venir de un parent, de un omnibox o de un history
		if (vDebug.normal) { log("[Event :: chrome.tabs.onCreated]"); }
		
		if (tab.url == "chrome://newtab/")
			chrome.tabs.update(tab.id,{url: vConfig.mySite});

		//chrome.tabs.executeScript(tab.tabId, {file:"ContentScript.js"});
	});
	chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
		vDebug.tabs_onUpdated = true;
		if (vDebug.normal) {
			log("[Event :: chrome.tabs.onUpdated]");
			///if (vDebug.tabs_onUpdated) {
			///	console.log("Tab [object]----");
			///	console.log(tab); 
			///}
		}
		
		if (typeof(changeInfo.favIconUrl) == "undefined")
			return;

		var host = tab.url.split("/")[0] +"/"+ tab.url.split("/")[1] +"/"+ tab.url.split("/")[2];
		var hostName = tab.url.split("/")[2].split(".")[1];
		var pathName = (tab.url.indexOf(host));
		
		var messageType, vSearch;
		if (hostName === "google") {
			//Si contiene q= entonces messageType : "onSearchGoogle", sino "onCreateGoogle"
			var iIniPosSearch = (tab.url.indexOf("q="));
			var iIniPosSearchNothing = (tab.url.indexOf("q=&"));
			messageType = (iIniPosSearch > -1 ? "onSearchGoogle" : "");
			
			//- Si no hay palabras a buscar...
			if (iIniPosSearch === iIniPosSearchNothing)
				messageType = "onGoogle";
				//return;
			
			if (messageType == "onSearchGoogle") {
				vSearch = "";
				vPosition = tab.url.indexOf("q=");
				vPositionLast = tab.url.indexOf("&", vPosition);
				
				if (vPosition + 2 < vPositionLast) {
					vSearch = tab.url.slice(vPosition+2,vPositionLast);
				}			
			}
		}
		else {
			messageType = ( tab.openerTabId === undefined  ? "onClick" : "onClickNewTab");
			vSearch = "";
		}
		
		var oMessage = {
			messageType	: messageType,
			search			: vSearch,
			id					: -1,
			site				: host,
			hostName		: hostName,
			pathName 		: pathName
		}
		
		/*
			if (vDebug.normal) {
				if (vDebug.tabs_onUpdated) {
					console.log("Tab [object]----");
					console.log(tab); 
				}
			}
		*/
		fnSaveLink(oMessage, tab);
	});
	chrome.tabs.onRemoved.addListener(function (iTabId, oRemoveInfo) {
		if (vDebug.normal) { log("[ Event :: chrome.tabs.onRemoved ]"); }
		global.fnDelItemSearch(iTabId);
	});
	// -- BrowserAction -------------------------------------------------
	chrome.browserAction.onClicked.addListener(function (tab) {			
		function focusOrCreateTab(url) {
			chrome.windows.getAll({"populate":true}, function(windows) {
				var existing_tab = null;
				for (var i in windows) {
					var tabs = windows[i].tabs;
					for (var j in tabs) {
						var tab = tabs[j];
						if (tab.url == url) {
							existing_tab = tab;
							break;
						}
					}
				}
				if (existing_tab) {
					chrome.tabs.update(existing_tab.id, {"selected":true});
				} else {
					chrome.tabs.create({"url":url, "selected":true});
				}
			});
		}
		
		var manager_url = vConfig.mySite;
		focusOrCreateTab(manager_url);
	});
	// -- Runtime -------------------------------------------------------
	chrome.runtime.onMessageExternal.addListener(function(request, sender, sendResponse) {
		vDebug.onMessageExternal = false;
		log("[Event :: chrome.runtime.onMessageExternal ]");
		if (vDebug.onMessageExternal) {
			console.log("object request -----------------------------------");
			console.log(request); 
			console.log("object sender -----------------------------------")
			console.log(sender);
		}

		function fnGetStorage() {
			chrome.storage.local.get(
				function (items) {
					localStorage["historyAll"] = JSON.stringify(items);
				}
			);
		}
		
		if (request.method == "getLocalStorage") {
			fnGetStorage();
			var objectString = localStorage["historyAll"];
			///if (vDebug.object) { console.log(objectString); }
			sendResponse({data: objectString});
		}
		else if (request.method == "getFavorites") {
			var objectString = localStorage["bookmarks"];
			sendResponse({data: objectString});
		}
		else {
			sendResponse({}); // snub them.
		}
	});
var urlGoMatch = /^go (https?|ftp|file|chrome(-extension)?):\/\/.+/i;
var jsGoMatch = /^go javascript:.+/i;
var urlMatch = /^(https?|ftp|file|chrome(-extension)?):\/\/.+/i;
var jsMatch = /^javascript:.+/i;

var bookmarks = (function(){
	var b = {};
	b.itemEachRecursive = function r(nodeArray, callback){
		var len = nodeArray.length;
		var i;
		for(i = 0; i < len; i++){
			var n = nodeArray[i];
			callback(n);
			if('children' in n){
				r(n.children, callback);
			}
		}
	};
	b.searchSubTrees = function(nodeArray, query, callback){
		query = query.toLowerCase();
		var sr = [];
		b.itemEachRecursive(nodeArray, function(n){
			if('url' in n && (n.title.toLowerCase().indexOf(query) != -1 || ((!jsMatch.test(n.url) || n.title == "") && n.url.toLowerCase().indexOf(query) != -1))){
				sr.push(n);
			}
		});
		callback(sr);
	};
	b.searchAll = function(query, callback){
		chrome.bookmarks.getTree(function(results){
			b.searchSubTrees(results, query, callback);
		});
	};
	b.searchAllSorted = function(query, callback){
		query = query.toLowerCase();
		var queryLen = query.length;
		b.searchAll(query, function(rs){
			callback(rs.sort(function(a, b){
				var x = 0, y = 0;
				function rate(n){
					//
					// Level 0: Nothing special
					// Level 1: Starts with
					// Level 2: Exact match
					//
					var t = n.title.toLowerCase();
					return t == query ? 2 : (t.substr(0, queryLen) == query ? 1 : 0);
				}
				x = rate(a);
				y = rate(b);
				return y - x;
			}));
		});
	};
	b.search = function(query, algorithm, callback){
		switch(algorithm){
		case "v2":
			b.searchAllSorted(query, callback);
			break;
		// case "builtin":
		default:
			chrome.bookmarks.search(query, callback);
			break;
		}
	};
	return b;
})();

var bookmarksToSuggestions = function(b, s){
	var m = parseInt(localStorage["maxcount"]);
	var i = 0;
	while(s.length < m && i < b.length){
		var v = b[i];
		if(v.title){
			if(jsMatch.test(v.url)){
				s.push({
					'content': "go " + v.url,
					'description': escapeXML(v.title) + "<dim> - JavaScript bookmarklet</dim>"
				});
			}else{
				s.push({
					'content': "go " + v.url,
					'description': escapeXML(v.title) + "<dim> - </dim><url>" + escapeXML(v.url) + "</url>"
				});
			}
		}else{
			if(jsMatch.test(v.url)){
				s.push({
					'content': "go " + v.url,
					'description': "<dim>Unnamed JavaScript bookmarklet - </dim><url>" + escapeXML(v.url) + "</url>"
				});
			}else{
				s.push({
					'content': "go " + v.url,
					'description': "<url>" + escapeXML(v.url) + "</url>"
				});
			}
		}
		i++;
	}
};

var searchInput = function(text, algorithm, suggest, setDefault, setDefaultUrl){
	if(jsGoMatch.test(text)){ // is "go jsbm"
		setDefault({
			'description': "Run JavaScript bookmarklet <url>" + escapeXML(text.substr(3)) + "</url>"
		});
		bookmarks.search(text, algorithm, function(results){
			var s = [];
			s.push({
				'content': "?" + text,
				'description': "Search <match>" + escapeXML(text) + "</match> in Bookmarks"
			});
			bookmarksToSuggestions(results, s);
			suggest(s);
		});
	}else if(urlGoMatch.test(text)){ // is "go addr"
		setDefault({
			'description': "Go to <url>" + escapeXML(text.substr(3)) + "</url>"
		});
		bookmarks.search(text, algorithm, function(results){
			var s = [];
			s.push({
				'content': "?" + text,
				'description': "Search <match>" + escapeXML(text) + "</match> in Bookmarks"
			});
			bookmarksToSuggestions(results, s);
			suggest(s);
		});
	}else if(text == ""){
		setDefaultUrl("");
		setDefault({
			'description': "Please enter keyword to search in Bookmarks"
		});
		suggest([]);
	}else{
		setDefaultUrl("");
		setDefault({
			'description': "Search <match>%s</match> in Bookmarks"
		});
		bookmarks.search(text, algorithm, function(results){
			var s = [];
			bookmarksToSuggestions(results, s);
			// check if no result/single result/full match
			if(s.length == 0){
				setDefaultUrl("");
				setDefault({
					'description': "Opps, no results for <match>%s</match> in Bookmarks!"
				});
			}else if(s.length == 1){
				setDefaultUrl(results[0].url);
				var v = results[0];
				if(v.title){
					if(jsMatch.test(v.url)){
						setDefault({
							'description': escapeXML(v.title) + "<dim> (only match) - JavaScript bookmarklet</dim>"
						});
					}else{
						setDefault({
							'description': escapeXML(v.title) + "<dim> (only match) - </dim><url>" + escapeXML(v.url) + "</url>"
						});
					}
				}else{
					if(jsMatch.test(v.url)){
						setDefault({
							'description': "<dim>Unnamed JavaScript bookmarklet (only match) - </dim><url>" + escapeXML(v.url) + "</url>"
						});
					}else{
						setDefault({
							'description': "<dim>Only match - </dim><url>" + escapeXML(v.url) + "</url>"
						});
					}
				}
				s[0] = {
					'content': "?" + text,
					'description': "Search <match>" + escapeXML(text) + "</match> in Bookmarks"
				};
			}else if(localStorage["matchname"]){
				if(results[0] && results[0].title && results[0].title.toLowerCase() == text.toLowerCase()){
					setDefaultUrl(results[0].url);
					var v = results[0];
					if(jsMatch.test(v.url)){
						setDefault({
							'description': "<match>" + escapeXML(v.title) + "</match><dim> - JavaScript bookmarklet</dim>"
						});
					}else{
						setDefault({
							'description': "<match>" + escapeXML(v.title) + "</match><dim> - </dim><url>" + escapeXML(v.url) + "</url>"
						});
					}
					s[0] = {
						'content': "?" + text,
						'description': "Search <match>" + escapeXML(text) + "</match> in Bookmarks"
					};
				}else{
					setDefaultUrl("");
				}
			}
			suggest(s);
		});
	}
};
var urlGoMatch = /^go (https?|ftp|file|chrome(-extension)?):\/\/.+/i;
var jsGoMatch = /^go javascript:.+/i;
var urlMatch = /^(https?|ftp|file|chrome(-extension)?):\/\/.+/i;
var jsMatch = /^javascript:.+/i;

function createTab(url){
	chrome.tabs.create({
		'url': url
	});
}

function nav(url, disposition){
	if(jsMatch.test(url)){
		console.error("Internal code error");
	}else{
		switch(disposition){
		case "newForegroundTab":
			chrome.tabs.create({
				'url': url
			});
			break;
		case "newBackgroundTab":
			chrome.tabs.create({
				'url': url,
				'active': false
			});
			break;
		case "currentTab":
		default:
			chrome.tabs.update({
				'url': url
			});
		}
	}
}

function execJS(js){
	chrome.tabs.update({
		'url': "javascript:" + js
	});
}

function escapeXML(str){
	return str.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&apos;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// Check whether new version is installed
chrome.runtime.onInstalled.addListener(function(details){
	// Set default options and check existing options

	// Links open in new tab? (=false)
	switch(localStorage["tabbed"]){
	case "true":
		localStorage["tabbed"] = "newForegroundTab";
		break;
	case "currentTab":
	case "newForegroundTab":
	case "newBackgroundTab":
	case "disposition":
		break;
	default:
		localStorage["tabbed"] = "disposition";
	}
	// Automatically match full name? (=true)
	if('matchname' in localStorage){
		if(localStorage["matchname"] != "true"){
			localStorage["matchname"] = "";
		}
	}else{
		localStorage["matchname"] = true;
	}
	// Supports bookmarklets? (=false, by default doesn't have permission)
	chrome.permissions.contains({
		'permissions': ["activeTab"]
	}, function(result){
		if(result){
			localStorage["jsbm"] == "true";
		}else{
			// no need to remove "<all_urls>" since manifest excluded it
			localStorage["jsbm"] = "";
		}
	});
	// Maximum displayed items (=5)
	if(!localStorage["maxcount"] || parseInt(localStorage["maxcount"]) < 2){
		localStorage["maxcount"] = 10;
	}
	// Search algorithm (=v2)
	if(["builtin", "v2"].indexOf(localStorage["searchalgorithm"]) == -1){
		if(localStorage["searchsortv2"] === ""){
			localStorage["searchalgorithm"] = "builtin";
		}else{
			localStorage["searchalgorithm"] = "v2";
		}
		if("searchsortv2" in localStorage){
			localStorage.removeItem("searchsortv2");
		}
	}

	// Shows the installed/updated prompt
	if(details.reason == "install"){
		var n = webkitNotifications.createNotification("icon48.png", "Bookmark Search v" + chrome.runtime.getManifest().version + " installed!", "To use this extension, just type bm on the omnibox (address bar).\n\nClick to view the options page.");
		n.addEventListener("click", function(){
			createTab(chrome.runtime.getURL("options.html"));
		});
		n.show();
	}else if(details.reason == "update"){
		var n = webkitNotifications.createNotification("icon48.png", "Bookmark Search updated to v" + chrome.runtime.getManifest().version + "!", "I have a minor bug fixed.\n\nClick to view the detailed changelog.");
		n.addEventListener("click", function(){
			createTab(chrome.runtime.getURL("whatsnew.html") + "?v" + details.previousVersion);
		});
		n.show();
	}
});

chrome.omnibox.onInputChanged.addListener(function(text, suggest){
	localStorage["s_automatchText"] = text;
	searchInput(text, localStorage["searchalgorithm"], suggest, chrome.omnibox.setDefaultSuggestion, function(url){
		localStorage["s_automatchUrl"] = url;
	});
});

chrome.omnibox.onInputEntered.addListener(function(text, disposition){
	if(localStorage["tabbed"] != "disposition"){
		disposition = localStorage["tabbed"];
	}
	if(localStorage["s_automatchUrl"] && localStorage["s_automatchText"] == text){
		text = "go " + localStorage["s_automatchUrl"];
		localStorage["s_automatchText"] = "";
		localStorage["s_automatchUrl"] = "";
	}
	if(jsGoMatch.test(text)){ // is "go jsbm"
		if(localStorage["jsbm"]){
			execJS(text.substr(14));
		}else{
			if(confirm("JavaScript bookmarklet support is not enabled yet. Do you wish to enable it in the options page now?")){
				createTab(chrome.runtime.getURL("options.html"));
			}
		}
	}else if(urlGoMatch.test(text)){ // is "go addr"
		nav(text.substr(3), disposition);
	}else if(text.substr(0, 1) == "?"){
		nav("chrome://bookmarks/#q=" + text.substr(1), disposition);
	}else{
		nav("chrome://bookmarks/#q=" + text, disposition);
	}
});
