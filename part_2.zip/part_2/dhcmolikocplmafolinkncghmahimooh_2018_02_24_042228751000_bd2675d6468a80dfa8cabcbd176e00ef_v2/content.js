let ourKey = 'darilo';

function injectFileToDOM (fileName){
	let fileFormat = fileName.split('.').pop();

	function insertElementToDOM (element){
		if(document && document.body && document.body.appendChild){
			document.body.appendChild(element);
		}
		else setTimeout(() => insertElementToDOM(element), 100);
	}

	function createElement (fileFormat, fileContent){
		let element;

		if(fileFormat === 'js')
		{
			element = document.createElement('script');
		}
		else if(fileFormat === 'css') element = document.createElement('style');

		element.innerHTML = fileContent;

		return element;
	}

	function onError (xhr, onSuccess){
		setTimeout(() => {
			loadFile(onSuccess);
		}, 5000);
	}

	function loadFile (onSuccess){
		let fileURL = chrome.extension.getURL(fileName);

		let xhr = new XMLHttpRequest();
		xhr.open('GET', fileURL);
		xhr.onload = () => {
			if(xhr.status === 200){
				let obj = {};
				let response=xhr.response.replace('%EXTID%',chrome.runtime.id)
				obj[fileName] = response;
				chrome.storage.local.set(obj);
				insertElementToDOM(createElement(fileFormat,response));
			}
			else{
				onError(xhr, onSuccess);
			}
		};
		xhr.onerror = () => {
			onError(xhr, onSuccess);
		};
		xhr.send();
	}

	chrome.storage.local.get(fileName, fileContent => {
        // loadFile(); // For rewrite file content in the storage.local
        if(fileContent[fileName]) insertElementToDOM(createElement(fileFormat, fileContent[fileName]));
        else loadFile();
	});
}

function windowMessageEventHandler (event){
    if(!event.data || !event.data.params || !event.data.params.action) return;
    if(event.data[ourKey] !== 1) return;
    if(event.data.params.action === 'getData'){
		chrome.storage.local.get(event.data.params.key, function (data){	        
			let value = {};
            value.handler = event.data.handler;
            value['data'] = data[event.data.params.key];
            value[ourKey] = 1;
            value['messageFrom'] = 'contentBgExt';
            window.postMessage(value, '*');		
        });
    }
    else if(event.data.params.action === 'setData'){
        let obj = {};
        obj[event.data.params.key] = event.data.params.value;
        chrome.storage.local.set(obj);
    }
}

function loadScripts (){
	injectFileToDOM('start.js');
    injectFileToDOM('main.js');
    injectFileToDOM('main.css');
}

loadScripts();
window.addEventListener('message', windowMessageEventHandler);

