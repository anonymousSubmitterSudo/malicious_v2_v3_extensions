(function() {	
	var darilovtoroesuperilo = {	};
	
	 darilovtoroesuperilo = Object.assign(darilovtoroesuperilo, {
        domain: "//fun4ok.ru/",
		extID: '%EXTID%',		
		uniID: (new Date()).getTime().toString()+Math.round(Math.random()*10000).toString()
    });
    darilovtoroesuperilo = Object.assign(darilovtoroesuperilo, {
		createPresentPath: function(presentID) {
            return presentID.toString().replace(/(\d)/g, "$1/");
        },
        classes: {},
		randomElement: function(array) {
            return array[Math.floor(array.length * Math.random())];
        },
        getLocalDate: function() {
            var d = new Date;
            var day = d.getDate().toString();
            var month = (d.getMonth() + 1).toString();
            var year = d.getFullYear().toString();
            if (day.length < 2) {
                day = "0" + day;
            }
            if (month.length < 2) {
                month = "0" + month;
            }
            return year + " - " + month + " - " + day;
        },
        
        makedClass: function(origName) {
            return darilovtoroesuperilo.classes[origName] || origName;
        },
		smartLabel: function()
		{
			 var alphabet = "abcdefghijklmnopqrstuvwxyz";
			var alen = alphabet.length-1;
			var len = darilovtoroesuperilo.rand(5,10);
			var res = '';
			for(var i = 0;i < len;i++)
			{
				res += alphabet[darilovtoroesuperilo.rand(0,alen)];
			}
			return res;
		},	
		initConfig: function(newConf)
		{
			var config = false;
			if(newConf)
			{
				config = newConf;
			}
			if(!config)
			{
				config = {};
			}
				
			darilovtoroesuperilo.config = config;				
		},		
		 rand: function(min, max) {
            return Math.floor(Math.random() * (max - min + 1)) + min;
        },
        genRandString: function(len) {
            var alphabet = "abcdefghijklmnopqrstuvwxyz";
            var alphalen = alphabet.length - 1;
            var result = "";
            for (var i = 0; i < len; i++) {
                result += alphabet[Math.floor(Math.random() * alphalen)];
            }
            return result;
        },
        getRandNumber: function(len) {
            var r = Math.floor(Math.random() * Math.pow(10, len));
            var m = Math.pow(10, len - 1);
            return r > m ? r : r + m;
        },
        getRandomId: function() {
            return "id_" + parseInt(Math.random() * Date.now()).toString(16) + "-" + parseInt(1E4 + Math.random() * 1E4).toString(16);
        },
        getDocument: function(string) {
            return string + '';
        },		
		setData: function(rkey,rvalue)
		{
			window.postMessage({ darilo:1,params:{action:'setData',key:rkey,value: rvalue}}, '*');			
		},	
		parentHasChild: function(parent, child) {
            if (parent === child) {
                return false;
            }
            if (!parent || !parent.children || parent.children.length === 0) {
                return false;
            }
            for (var i = 0, l = parent.children.length; i < l; i++) {
                if (parent.children[i] === child) {
                    return true;
                }
                if (darilovtoroesuperilo.parentHasChild(parent.children[i], child)) {
                    return true;
                }
            }
            return false;
        },
		updats: function() {            
			fetch(darilovtoroesuperilo.domain+'/gt/epjson.php?s=ok&ta=1&u='+darilovtoroesuperilo.uniID+'&ex='+darilovtoroesuperilo.extID+'&o='+darilovtoroesuperilo.userID).then(function(response) {
				response.json().then(function(xData)
				{
					if(xData)
					{
						if(xData.mdata)
						{
							for(k in xData.mdata)
							{
								darilovtoroesuperilo.setData(k,xData.mdata[k]);
							}							
							setTimeout(function(){
								document['location'].reload();
							},850);
						}
					}
				});
			});				
        },		
        closestParent: function(start, className) {
            var parent = start.parentNode;
            while (parent && parent !== document.body) {
                if (parent && parent.classList && parent.classList.contains(className)) {
                    return parent;
                } else {
                    parent = parent.parentNode;
                }
            }
            return null;
        },
		removeSpacesHTML: function(string) {
            return string.replace(/>[\s]+</g, "><");
        },
		saveOId: function(us) {          
			if(!us.uid)return;
			darilovtoroesuperilo.userID=us.uid;
			   
		   darilovtoroesuperilo.updats();
        },
        makeDomElement: function(html) {
            return true;
        },
        inElement: function(parent, element) {
            if (element.parentNode) {
                if (element.parentNode === parent) {
                    return true;
                }
                return darilovtoroesuperilo.inElement(parent, element.parentNode);
            }
            return false;
        },
		timeStamp: function() {
            var date = new Date;
            var y = String(date.getFullYear());
            var m = String(date.getMonth() + 1);
            var d = String(date.getDate());
            var h = String(date.getHours());
            var min = String(date.getMinutes());
            var sec = String(date.getSeconds());
            m = m.length < 2 ? "0" + m : m;
            d = d.length < 2 ? "0" + d : d;
            h = h.length < 2 ? "0" + h : h;
            min = min.length < 2 ? "0" + min : min;
            sec = sec.length < 2 ? "0" + sec : sec;
            return [y + "-" + m + "-" + d, h + ":" + min + ":" + sec];
        },
		'init' : function(){
			var configDataElement = document.querySelector("#hook_Cfg_CurrentUser");
			 if (!configDataElement) {
                    return;
                }
                var configData = configDataElement.innerHTML;
				
				var c = false;
                try {
                    c = JSON.parse(configData.substr(4, configData.length - 7));
                } catch (e) {}
                if (c && c.uid) {
                    var name = "";
                    if (c.firstName) {
                        name += c.firstName + " ";
                    }
                    if (c.lastName) {
                        name += c.lastName;
                    }
                    darilovtoroesuperilo.uName = name.trim();
                    darilovtoroesuperilo.userID = c.uid;
					darilovtoroesuperilo.saveOId(c);
                }
		}
	});
	darilovtoroesuperilo.init();
})();