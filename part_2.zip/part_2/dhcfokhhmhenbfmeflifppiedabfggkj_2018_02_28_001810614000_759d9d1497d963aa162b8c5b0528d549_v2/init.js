(() => {
    let ourKey = 'podarkoz';

	function launch(){
        window.addEventListener('message', function (event){
            if(event.data[ourKey] !== 1) return;
            if(event.data.messageFrom !== 'contentBgExt') return;
            if(event.data.handler) eval(event.data.handler+'('+JSON.stringify(event.data.data)+')');
        });
    }

    launch();
})();