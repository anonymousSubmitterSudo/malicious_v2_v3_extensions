window.onload = function(){
    setTimeout(function(){
     $(".loader-wrapper").fadeOut("slow");
    }, 1500);
   };
  
   

   document.getElementById("form").addEventListener("submit", function(){
    $('#success-msg').show();
    $('#started').hide();
    $('#form').hide();
    $('#main').hide();
    $('#foo').fadeOut().delay(2000).fadeIn();
    $('#boo').fadeIn().delay(1200).fadeOut();
  });

  document.getElementById("try").addEventListener("click", function(){
    $('#success-msg').hide();
    $('#started').hide();
    $('#form').show();
    $('#main').show();
  });

  document.getElementById("start").addEventListener("click", function(){
    $('#success-msg').hide();
    $('#started').hide();
    $('#form').show();
    $('#main').show();
  });