/*****************************************************************
 * onMessage from the extension or tab (a content script)
 *****************************************************************/

// Send message from active tab to background: 
chrome.runtime.onMessageExternal.addListener(
  function(request, sender, sendResponse) {
	

	if (request.modo=="dameToken"){
		chrome.storage.sync.get("token", function (obj) {
		var retorno="";
		if (obj.token){
			retorno=obj.token;
		}
		sendResponse({token: retorno});
		});
	}else if(request.modo=="guardaToken"){
		if (request.token!=""){
			chrome.storage.sync.set({"token": request.token});	
		}
		if (request.nombreEmp!=""){
			chrome.storage.sync.set({"empresaNom": request.nombreEmp});	
		}
		
	}else if (request.modo=="borrarToken"){
		chrome.storage.sync.remove("token", function(Items) {
			
		}); 
		chrome.storage.sync.remove("centro", function(Items) {
			
		}); 
		chrome.storage.sync.remove("centroNom", function(Items) {
			
		}); 
		
		chrome.storage.sync.remove("empresaNom", function(Items) {
			
		}); 
		sendResponse({token: "borrado"});
	}else if(request.modo=="guardarCentro"){
		if (request.centro!=""){
			chrome.storage.sync.set({"centro": request.centro});	
		}
		if (request.nombreCentro!=""){
			chrome.storage.sync.set({"centroNom": request.nombreCentro});	
		}
	}else if(request.modo=="dameCentro"){
		chrome.storage.sync.get("centro", function (obj) {
		var retorno="";
		if (obj.centro){
			retorno=obj.centro;
		}
		sendResponse({centro: retorno});
		});
	}else if(request.modo=="instalada"){
		sendResponse(true);
		
	}
	return true;
  });
  
chrome.runtime.onMessage.addListener(function(message,sender,sendResponse){
  if(message.method == "obtenerDatosParaPintar")
    sendResponse(obtenerDatosParaPintar());
});
function obtenerDatosParaPintar(){
  return "yay!";
}
