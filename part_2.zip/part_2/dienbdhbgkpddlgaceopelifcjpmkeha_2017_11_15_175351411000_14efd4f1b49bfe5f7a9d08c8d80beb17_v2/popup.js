$(function() {
  chrome.runtime.sendMessage({method:"obtenerDatosParaPintar"},function(reply){
	  
	  chrome.storage.sync.get("empresaNom", function (obj) {
		var retorno="";
		if (obj.empresaNom){
			retorno=obj.empresaNom;
		}
		document.getElementById('textoResi').innerHTML = retorno;
		});
	  
		chrome.storage.sync.get("centroNom", function (obj) {
		var retorno="";
		if (obj.centroNom){
			retorno=obj.centroNom;
		}
		document.getElementById('centroResi').innerHTML = retorno;
		});
  });
});